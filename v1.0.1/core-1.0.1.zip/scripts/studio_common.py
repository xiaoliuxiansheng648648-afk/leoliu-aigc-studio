"""Standard-library project IO; canvas.json is intentionally absent."""

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE if (PACKAGE / "workflows").is_dir() else PACKAGE.parent
WORKFLOWS = ROOT / "workflows"
SCHEMAS = ROOT / "contract/schemas"
VERSION = (
    json.loads((PACKAGE / "version.json").read_text(encoding="utf-8"))["version"]
    if (PACKAGE / "version.json").is_file()
    else "1.0.1"
)


class StudioError(Exception):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024**2), b""):
            result.update(chunk)
    return result.hexdigest()


def read_json(path, default=None):
    path = Path(path)
    if not path.exists() and default is not None:
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError) as error:
        raise StudioError("无法读取项目文件：" + path.name) from error


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix="." + path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def safe_relative(root, relative):
    if not isinstance(relative, str) or not re.fullmatch(
        r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*", relative
    ):
        raise StudioError("文件路径须使用项目内的 ASCII 相对路径。")
    if any(part in (".", "..") for part in relative.split("/")):
        raise StudioError("文件路径不能离开项目目录。")
    root = Path(root).resolve()
    result = (root / relative).resolve()
    try:
        result.relative_to(root)
    except ValueError as error:
        raise StudioError("文件路径不能离开项目目录。") from error
    return result


def load_project(folder):
    folder = Path(folder).resolve()
    project = {"path": folder}
    for name in ("studio", "assets", "brief", "storyboard", "review", "results"):
        fallback = {"schemaVersion": 1, "items": []} if name == "results" else None
        project[name] = read_json(folder / (name + ".json"), fallback)
    return project


def manifest(workflow_id):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", workflow_id):
        raise StudioError("工作流编号不合法。")
    path = WORKFLOWS / workflow_id / "manifest.json"
    if not path.is_file():
        raise StudioError("工作流未安装，请更新工作台：" + workflow_id)
    result = read_json(path)
    if result["id"] != workflow_id:
        raise StudioError("工作流目录与 manifest 编号不一致。")
    return result


def registry():
    return sorted(
        [manifest(path.parent.name) for path in WORKFLOWS.glob("*/manifest.json")],
        key=lambda row: row["order"],
    )
