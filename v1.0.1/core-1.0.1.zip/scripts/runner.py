from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from studio_common import (
    StudioError,
    load_project,
    read_json,
    write_json,
    digest,
    safe_relative,
    now,
    manifest,
)
from compiler import compile_project, adapter
from auto_reroll import effective
from workflow_tools import shot_hash


def running_projects(root):
    return list(Path(root).glob("*/runs/*/RUNNING"))


def assert_approved(folder, job):
    project = effective(load_project(folder), folder)
    if digest(Path(folder) / "storyboard.json") != job["storyboardSha256"]:
        raise StudioError("分镜在编译后发生变化，未提交；请核对页面后重新编译。")
    shots = project["storyboard"]["workflows"].get(job["workflowId"], {}).get("shots", [])
    shot = next((shot for shot in shots if shot["id"] == job["shotId"]), None)
    if not shot or shot["status"] != "approved" or shot_hash(shot) != job["shotSha256"]:
        raise StudioError("镜头未通过或内容已经改变，未提交。")


def execute(folder, defer_shutdown=False, resume_id=None, remote_factory=None):
    import engine_bridge as bridge

    folder = Path(folder)
    # The original OS lock serializes all cloud operations, including the legacy engine.
    with bridge.h3.lease():
        active = list(folder.glob("runs/*/RUNNING"))
        if active and not resume_id:
            raise StudioError("项目已有未结束任务，请用 wait 恢复；禁止重复提交。")
        if resume_id:
            run_folder = safe_relative(folder, "runs/" + resume_id)
            run = read_json(run_folder / "run.json")
            defer_shutdown = read_json(run_folder / "execution.json")["deferShutdown"]
        else:
            previous = {}
            for record in folder.glob("runs/*/run.json"):
                for job in read_json(record)["jobs"]:
                    if job["status"] in ("complete", "failed", "unknown", "running", "submitting"):
                        previous[(job["workflowId"], job["shotId"], job["shotSha256"])] = job[
                            "status"
                        ]
            run = compile_project(folder, approved_only=True)
            run["jobs"] = [
                job
                for job in run["jobs"]
                if (job["workflowId"], job["shotId"], job["shotSha256"]) not in previous
            ]
            run_folder = folder / "runs" / run["id"]
            write_json(run_folder / "run.json", run)
            if not run["jobs"]:
                raise StudioError(
                    "已通过镜头已有执行记录。需要重抽时，请先让助手更新草稿并在页面重新通过；"
                    "页面打开了“授权 AI 自动重抽”时，助手改好草稿后用 auto-reroll 登记。"
                )
            write_json(run_folder / "execution.json", {"deferShutdown": defer_shutdown})
        marker = run_folder / "RUNNING"
        marker.touch(exist_ok=True)
        remote = None
        preparation = ThreadPoolExecutor(max_workers=1)
        results = read_json(folder / "results.json", {"schemaVersion": 1, "items": []})
        try:
            for job in run["jobs"]:
                if job["status"] == "prepared":
                    assert_approved(folder, job)
            remote = (remote_factory or bridge.StudioRemote)()
            remote.sync()
            models = {
                model["path"]: model
                for job in run["jobs"]
                for model in manifest(job["workflowId"])["models"]
            }
            needs_models = any(
                job["status"] != "complete" and not (run_folder / (job["id"] + ".engine.json")).exists()
                for job in run["jobs"]
            )
            models_ready = (
                preparation.submit(remote.task, "studio-models", {"models": list(models.values())})
                if needs_models else None
            )
            for job in run["jobs"]:
                if job["status"] == "complete":
                    continue

                def state(status, error="", current=job):
                    current["status"] = status
                    item = {
                        "id": current["id"],
                        "shotId": current["shotId"],
                        "runId": run["id"],
                        "workflowId": current["workflowId"],
                        "status": status,
                        "updatedAt": now(),
                    }
                    if error:
                        item["error"] = error
                    results["items"] = [
                        row for row in results["items"] if row["id"] != current["id"]
                    ] + [item]
                    write_json(folder / "results.json", results)
                    write_json(run_folder / "run.json", run)

                record_exists = (run_folder / (job["id"] + ".engine.json")).exists()
                if not record_exists:
                    assert_approved(folder, job)
                    state("queued")
                try:
                    outputs = bridge.run_job(
                        remote,
                        folder,
                        run,
                        job,
                        state,
                        resume=record_exists,
                        before_submit=lambda: assert_approved(folder, job),
                        models_ready=models_ready,
                    )
                except Exception as error:
                    record = read_json(
                        run_folder / (job["id"] + ".engine.json"), {"status": "prepared"}
                    )
                    uncertain = record["status"] in ("submitting", "running", "complete")
                    state("unknown" if uncertain else "failed", str(error))
                    raise
                collected = adapter(job["workflowId"]).collect(dict(job, runId=run["id"]), outputs)
                results["items"] = [row for row in results["items"] if row["id"] != job["id"]]
                results["items"] += collected
                job["status"] = "complete"
                write_json(folder / "results.json", results)
                write_json(run_folder / "run.json", run)
            if not defer_shutdown:
                message = bridge.h3.shutdown(remote)
                write_json(run_folder / "shutdown.json", {"message": message, "checkedAt": now()})
            marker.unlink(missing_ok=True)
            return run
        except Exception:
            # Uncertainty or shutdown failure keeps RUNNING. Never make update/re-run look safe.
            if all(job["status"] in ("failed", "prepared") for job in run["jobs"]):
                marker.unlink(missing_ok=True)
            raise
        finally:
            preparation.shutdown(wait=True)
