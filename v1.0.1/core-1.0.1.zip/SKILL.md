---
name: leoliu-studio
description: 打开 LeoLiu 本地视频工作台；读取同一个项目文件夹，按剧情写分镜草稿、编译参考编号、在用户通过后生成视频，处理选片与重抽，自动检查签名更新。
---

# LeoLiu 工作台

© 2026 LeoLiu（微信 LeoLiu_AI）保留所有权利；仅限个人非商业使用，非开源，详见 LICENSE。

面向零基础创作者。按“素材 → 剧情 → 分镜 → 成片”推进，用中文讲清下一步。
只通过本机项目文件夹交换数据；网页不发网络请求，也不能启动生成。

## 每次开始先查更新

1. 用本 Skill 安装位置运行 `python scripts/studio.py update --check`。Python 命令按本机可用的 `python3` / `python` 选择。
2. 未配置通道或 3 秒内查不到时静默继续。签名/散列错误时保留旧版，简短告知更新失败，仍可使用通过自检的旧版。
3. 有新版时此命令自动应用；存在 `runs/*/RUNNING` 就推迟。更新完成后把 `notes` 告诉用户。
4. Windows 返回 `scheduled` 时，等返回的 resultFile 出现，读取并确认 updated；失败说明保留/恢复旧版，不把排队替换当作更新成功。
5. 1.0.1 起支持签名更新通道；发行前必须由用户配置正式公钥并签名。未配置时保持旧版，不使用测试公钥代替。

## 打开工作台

用户说“打开工作台”：运行 `python scripts/studio.py open`，或加 `--project 项目名`。
默认项目根目录：macOS `~/LeoLiuStudio/`，Windows `%USERPROFILE%\LeoLiuStudio\`。
网页里选择这一个根文件夹。项目列表和新建项目入口在“项目与文件夹”。
重开浏览器后如需授权，点“一键重新授权”；Safari / Firefox 改用 ZIP。
可运行 `python scripts/studio.py new "项目名" --workflow h3-multiref` 初始化空项目。
目录可以中文；内部 ID 和文件名用 ASCII。测试或用户明确选了别处时，在命令前加 `--root 绝对根目录`。

## 按剧情写分镜

只用两条命令，不读 schema、manifest，也不打开素材原图：

1. `python scripts/studio.py draft-kit 项目名`：一次给出剧情、设置、素材（ID、时长、512 像素预览图路径）、下一个草稿版本和填好绑定的镜头模板。
2. 要看图就只看“预览”里的小图。绝不查看素材原图，原图会让对话变得很大很慢。
3. 按剧情和“要点”写好每镜的 summary、dialogue 和六段 prompt。不确定写法时再读 `workflows/<id>/prompt-guide.md`。
4. 把镜头列表存成临时 JSON 文件（`{"shots": [...]}`），运行 `python scripts/studio.py write-draft 项目名 --file 文件`。它补齐版本号、时间和状态，按编译规则检查，通过后才写入 `storyboard.draft.json`；不通过就照提示改了再跑。
5. 助手绝不改页面负责的 `storyboard.json`。每次草稿包含该工作流的完整镜头列表，不要遗漏用户已有镜头。
6. 页面无修改时自动采用；已有修改时用户选择“采用新草稿”或“保留我的修改”。告知用户回到页面核对并通过。

草稿状态不表示批准；compile/run 只读页面采用的版本。

## 用户通过后开跑

用户在页面通过分镜后说“开跑”：

1. `status 项目名`、`validate 项目名`，再 `compile 项目名 --dry-run`。这只写本机 runs，不连接实例。
2. 没有凭据时使用 `engine save-ssh` 的系统私密窗口，不在聊天里索取或输出密码。凭据沿用 Mac 钥匙串 / Windows 凭据管理器。
3. 已有安装时直接执行 `run 项目名`，不另写 SSH 预检脚本、不先重跑 `setup`。首次安装或明确缺失环境时才执行 `setup 项目名`；重复 setup 会复用版本匹配的现有环境。不自动开机、注册、购买、扩盘或更换模型。
4. `run 项目名` 先接收已通过且没有同内容执行记录的镜头并排队；模型核验、CUDA 检查和素材上传并行，全部通过后才提交生成。模型按 manifest 下载，空间不足即停；音频有 ffmpeg 就转成 32 kHz 立体声 WAV。
5. 状态不明或中断：只用 `wait 项目名 --run-id <id>` 恢复已有任务；没有明确任务编号时核对队列/历史，禁止重发。
6. OOM 沿用原引擎：原参数清理后重试一次，再降低一档分辨率最后一次，最多三次。降档记录在 engine.json，向用户说明。
7. 默认全部下载且散列一致后尝试关机。只有 SSH 连续两次不可达才报告断连，并请用户到控制台确认“已关机”。
8. `--defer-shutdown` 仅用于明确的连续批次。整批完成后显式 `engine shutdown`，不能遗忘仍在计费的实例。

SSH 启动器会在同一次连接内查找 PATH 与常见 Conda 位置，不依赖交互终端激活环境，不补系统 `python3` 链接。SSH 已连通但命令失败时按命令错误处理，不让用户重复输入凭据。排障自定义 Python 命令用 `remote.python_command(...)` 构造。

首次核对大文件计算完整 SHA-256；后续仅在路径、预期散列、设备、inode、大小、mtime/ctime 均未变时复用远端 `~/.local/share/leoliu-h3-cloud/verified-files/` 的结果。变化、缓存丢失或损坏会重算；需排查损坏时用 `common.valid(path, row, force_hash=True)`。视频下载仍逐个计算完整 SHA-256。不要在付费开机后另做重复全量散列；`wait` 恢复已有任务不重新准备模型。

## 选片和重抽

页面选用、重抽原因与备注写入 review.json。助手只读。
重抽先按原因修订草稿，用户重新通过后才 run。不可把“标记重抽”直接当作新提示词批准。

### 授权 AI 自动重抽

页面“剧情”里打开“授权 AI 自动重抽”（`brief.json` 的 `settings.autoReroll`）后，助手可以不经页面重新通过就重抽：

1. 每镜下载后马上审片，GPU 同时跑下一镜。只有明显问题才重抽：多说或漏说台词、画面多出别人、脸换了人、明显崩坏、违反尺度、没声音。小瑕疵记下来，不重抽。
2. 种子固定，原样再跑结果一样。按问题改这一镜的提示词，写进 `storyboard.draft.json`（新 draftRevision）。
3. 运行 `auto-reroll 项目名 --shots <镜头> --reason "<原因>"` 登记。只有已经跑过的、页面已通过的镜头可以登记；每镜次数不超过页面设的上限（1–3）；提示词没改会被拒绝。
4. 当前任务结束后立刻 `run 项目名`（需要连续跑就加 `--defer-shutdown`），GPU 不空等。只有最后一轮审片可以让 GPU 等。
5. 登记写在 `auto-rerolls.json`，助手不改 `storyboard.json`。页面开关关掉，或用户在页面改了这一镜，登记就不再生效。把每次重抽的原因告诉用户。
最终由页面“导出成片清单”，视频原件在项目 runs 下。

## 保护边界

- 不自动上传用户素材到除其明确提供的生成实例以外的服务；网页完全离线。
- 删除素材移入 .trash。不要清空项目或覆盖未知文件。
- 不更改来源 Skill。所有引擎源码都随本包在 engine/，原有安全规则保留。
- 原生 Windows、GPU、正式云端地址与正式签名需要相应环境验收；本地测试不能冒充这些验证。
