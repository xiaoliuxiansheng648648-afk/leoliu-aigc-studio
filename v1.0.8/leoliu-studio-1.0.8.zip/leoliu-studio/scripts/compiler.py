import importlib.util
import uuid
from pathlib import Path
from studio_common import WORKFLOWS, StudioError, load_project, write_json, digest, now, manifest, workflow_folder
from validation import validate_project
from workflow_tools import shot_hash
from auto_reroll import effective
from ai_review import enabled as ai_review_enabled
import licensing


def adapter(workflow_id):
    manifest(workflow_id)
    path = workflow_folder(workflow_id) / "adapter.py"
    spec = importlib.util.spec_from_file_location(
        "studio_workflow_" + workflow_id.replace("-", "_"), path
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for function in ("plan", "compile", "collect"):
        if not callable(getattr(module, function, None)):
            raise StudioError("工作流适配器缺少接口：" + function)
    return module


def compile_project(folder, shots=None, approved_only=False, ready_only=False):
    project = load_project(folder)
    errors = validate_project(project)
    if errors:
        raise StudioError("\n".join(errors))
    page_shots = {
        (workflow_id, shot["id"]): shot
        for workflow_id, board in project["storyboard"]["workflows"].items()
        for shot in board["shots"]
    }
    # Approved shots the assistant rerolled under the page's switch compile in their new form.
    project = effective(project, folder)
    selected = set(shots or [])
    run_id = "run-" + uuid.uuid4().hex
    board_hash = digest(Path(folder) / "storyboard.json")
    jobs = []
    prepared = []
    found = set()
    licensed = set()
    for workflow_id in project["storyboard"]["workflows"]:
        plugin = adapter(workflow_id)
        for task in plugin.plan(project):
            shot = task["shot"]
            if selected and shot["id"] not in selected:
                continue
            found.add(shot["id"])
            if approved_only and shot["status"] != "approved":
                continue
            if workflow_id not in licensed:
                # Paid extensions compile only with a valid licence; other workflows in the project are unaffected.
                licensing.require(workflow_id, manifest(workflow_id))
                licensed.add(workflow_id)
            job_id = "job-" + uuid.uuid4().hex
            task["id"] = job_id
            if shot.get("firstFrame") and (approved_only or ready_only or ai_review_enabled(project, workflow_id)):
                from hybrid import dependency_issue

                issue = dependency_issue(project, workflow_id, shot)
                if issue:
                    if selected:
                        raise StudioError(issue)
                    continue
            compiled = plugin.compile(task)
            job = job_record(project, workflow_id, task, compiled, board_hash, run_id, page_shots)
            jobs.append(job)
            prepared.append((job, compiled))
    if selected - found:
        raise StudioError("没有找到指定镜头：" + ", ".join(sorted(selected - found)))
    if not jobs:
        raise StudioError("没有可编译的镜头。请在页面采用草稿；开跑前还需要通过分镜。")
    return publish(folder, run_id, prepared)


def job_record(project, workflow_id, task, compiled, board_hash, run_id, page_shots):
    shot, job_id = task["shot"], task["id"]
    job = {
        "id": job_id,
        "projectId": project["studio"]["projectId"],
        "workflowId": workflow_id,
        "workflowVersion": task["workflow"]["version"],
        "shotId": shot["id"],
        "storyboardSha256": board_hash,
        "shotSha256": shot_hash(shot),
        "status": "prepared",
        "graphPath": f"runs/{run_id}/{job_id}.api.json",
        "promptPath": f"runs/{run_id}/{job_id}.prompt.txt",
        "uploads": compiled["uploads"],
    }
    if compiled.get("turbo"):
        # Recorded per job: the instance downloads the turbo LoRA only for runs that use it.
        job["turbo"] = True
    if workflow_id == "h3-hybrid":
        # The page compares its own approved content, including after an authorized overlay reroll.
        job["shotSnapshot"] = page_shots[(workflow_id, shot["id"])]
    return job


def publish(folder, run_id, prepared, execution=None):
    # No partially compiled run is published if any earlier job failed validation.
    run_folder = Path(folder) / "runs" / run_id
    run_folder.mkdir(parents=True)
    for job, compiled in prepared:
        write_json(Path(folder) / job["graphPath"], compiled["graph"])
        (Path(folder) / job["promptPath"]).write_text(compiled["prompt"] + "\n", encoding="utf-8")
    run = {"schemaVersion": 1, "id": run_id, "createdAt": now(), "jobs": [job for job, _ in prepared]}
    if execution is not None:
        write_json(run_folder / "execution.json", execution)
    write_json(run_folder / "run.json", run)
    return run


def compile_draw(folder, workflow_id, shot_id, seeds):
    """抽卡: the same approved shot compiled once per seed, as one run the runner resumes without shutdown."""
    import copy

    project = effective(load_project(folder), folder)
    errors = validate_project(project)
    if errors:
        raise StudioError("\n".join(errors))
    if workflow_id == "h3-hybrid":
        raise StudioError("首帧＋多参考一镜接一镜，抽一镜会牵动后面所有镜头，暂不支持抽卡。")
    plugin = adapter(workflow_id)
    task = next((row for row in plugin.plan(project) if row["shot"]["id"] == shot_id), None)
    if task is None:
        raise StudioError("没有找到要抽卡的镜头：" + shot_id)
    if task["shot"]["status"] != "approved":
        raise StudioError(shot_id + " 还没通过，未抽卡。")
    licensing.require(workflow_id, manifest(workflow_id))
    board_hash = digest(Path(folder) / "storyboard.json")
    run_id = "run-" + uuid.uuid4().hex
    prepared = []
    # Built-in graphs take the seed at their RandomNoise node 10. An extension with its own graph
    # (e.g. two-pass sampling) reads job["seed"] itself and says so with SEEDABLE = True.
    seedable = getattr(plugin, "SEEDABLE", False)
    for seed in seeds:
        take = copy.deepcopy(task)
        take["id"] = "job-" + uuid.uuid4().hex
        take["seed"] = seed
        compiled = plugin.compile(take)
        if not seedable:
            noise = compiled["graph"].get("10", {})
            if noise.get("class_type") != "RandomNoise":
                raise StudioError(manifest(workflow_id)["name"] + " 暂不支持抽卡。")
            noise["inputs"]["noise_seed"] = seed
        job = job_record(project, workflow_id, take, compiled, board_hash, run_id, {})
        job.update(draw=True, seed=seed)
        prepared.append((job, compiled))
    return publish(folder, run_id, prepared, {"deferShutdown": True, "draw": True})
