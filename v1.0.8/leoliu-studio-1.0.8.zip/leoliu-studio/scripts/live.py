"""抽卡：页面把抽卡请求记进 review.json，这个常驻程序逐个生成，GPU 不关机。

页面点“抽卡”时已经替用户通过了那一镜；这里只认已通过、内容没变的镜头。
每张换一个随机种子，交给 runner 现有的开跑流程（模型核对、上传、下载、散列）。
进度写进 live.json，页面据此显示“抽卡在线 / 排队 N 张”。关机仍由助手在对话里做。
"""

import os
import secrets
import signal
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from studio_common import StudioError, load_project, read_json, write_json, now

LIVE = "live.json"
HEARTBEAT_SECONDS = 3
# A heartbeat older than this means the earlier program is gone; the page uses the same window.
STALE_SECONDS = 15
KEEP_HANDLED = 500


def requests(project):
    rows = [
        dict(row, workflowId=workflow_id)
        for workflow_id, workflow in project["review"]["workflows"].items()
        for row in workflow.get("draws", [])
    ]
    return sorted(rows, key=lambda row: (row["createdAt"], row["id"]))


def age(stamp):
    try:
        moment = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    except (AttributeError, ValueError):
        return float("inf")
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - moment).total_seconds()


def say(message):
    print("抽卡：" + message, flush=True)


class Live:
    def __init__(self, folder, interval=2.0, remote_factory=None, seed=None):
        self.folder = Path(folder)
        self.interval = interval
        self.remote_factory = remote_factory
        self.seed = seed or (lambda: secrets.randbelow(2**31))
        self.lock = threading.Lock()
        self.stop = threading.Event()
        path = self.folder / LIVE
        previous = read_json(path) if path.exists() else None
        from schema_check import document_errors

        if previous is not None and document_errors("live", previous):
            raise StudioError("live.json 格式不对，先移开它再开抽。")
        if previous and previous["state"] != "stopped" and age(previous["heartbeatAt"]) < STALE_SECONDS:
            raise StudioError("这个项目的抽卡程序已经在运行，不要再开一个。")
        self.status = {
            "schemaVersion": 1,
            "pid": os.getpid(),
            "startedAt": now(),
            "heartbeatAt": now(),
            "state": "starting",
            "message": "",
            "handled": (previous or {}).get("handled", []),
        }

    def write(self, **changes):
        with self.lock:
            self.status.update(changes, heartbeatAt=now())
            self.status["handled"] = self.status["handled"][-KEEP_HANDLED:]
            write_json(self.folder / LIVE, self.status)

    def finish(self, request, status, note="", run_id=""):
        row = {
            "id": request["id"],
            "workflowId": request["workflowId"],
            "shotId": request["shotId"],
            "status": status,
            "at": now(),
        }
        if note:
            row["note"] = note
        if run_id:
            row["runId"] = run_id
        with self.lock:
            self.status["handled"].append(row)
            self.status.pop("current", None)
        self.write(state="idle")
        say(f"{request['shotId']} {dict(done='完成', skipped='跳过', failed='失败')[status]}" + (f"：{note}" if note else ""))

    def pending(self):
        done = {row["id"] for row in self.status["handled"]}
        return [row for row in requests(load_project(self.folder)) if row["id"] not in done]

    def handle(self, request):
        from compiler import compile_draw
        from runner import execute

        project = load_project(self.folder)
        shots = project["storyboard"]["workflows"].get(request["workflowId"], {}).get("shots", [])
        shot = next((row for row in shots if row["id"] == request["shotId"]), None)
        if shot is None:
            return self.finish(request, "skipped", "镜头已经删掉")
        if shot["status"] != "approved":
            return self.finish(request, "skipped", "点抽卡之后这一镜又改过，还没重新通过")
        try:
            run = compile_draw(self.folder, request["workflowId"], request["shotId"],
                               [self.seed() for _ in range(request["count"])])
        except StudioError as error:
            return self.finish(request, "failed", str(error))
        current = dict(requestId=request["id"], workflowId=request["workflowId"],
                       shotId=request["shotId"], runId=run["id"], count=request["count"])
        self.write(state="working", current=current)
        say(f"{request['shotId']} 抽 {request['count']} 张开始（{run['id']}）")
        try:
            execute(self.folder, True, run["id"], self.remote_factory)
        except Exception as error:
            done = read_json(self.folder / "runs" / run["id"] / "run.json", run)
            if any(job["status"] in ("unknown", "submitting", "running") for job in done["jobs"]):
                # Never queue more takes on top of a task whose state is unknown.
                note = f"有一张状态待核对，请让助手用 wait --run-id {run['id']} 恢复，不要重抽"
                self.finish(request, "failed", note, run["id"])
                self.write(state="stopped", message=note)
                raise StudioError(note) from error
            return self.finish(request, "failed", str(error), run["id"])
        return self.finish(request, "done", run_id=run["id"])

    def beat(self):
        while not self.stop.wait(HEARTBEAT_SECONDS):
            self.write()

    def serve(self, once=False):
        def terminate(*_):
            raise KeyboardInterrupt

        try:
            signal.signal(signal.SIGTERM, terminate)
        except ValueError:
            pass  # Not the main thread (tests): Ctrl-C and the stop event still work.
        self.write(state="idle", message="")
        say("已开始，等页面上的抽卡请求。GPU 计费中，不用时请在对话里说“关机”。")
        heart = threading.Thread(target=self.beat, daemon=True)
        heart.start()
        handled = 0
        try:
            while not self.stop.is_set():
                for request in self.pending():
                    self.handle(request)
                    handled += 1
                if once:
                    break
                self.stop.wait(self.interval)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop.set()
            heart.join(timeout=HEARTBEAT_SECONDS + 1)
            if self.status["state"] != "stopped":
                self.write(state="stopped")
            say("已停止。")
        return {"抽卡": "已停止", "处理请求": handled, "说明": "GPU 没有关机；不用了请运行 engine shutdown。"}


def serve(folder, interval=2.0, once=False, remote_factory=None, seed=None):
    return Live(folder, interval, remote_factory, seed).serve(once)
