"""Storyboard drafting in two commands, so the assistant never reads schemas or original images.

`draft-kit` prints everything a draft needs: story, settings, assets with small preview images,
the next draft revision and a filled shot skeleton. `write-draft` takes the assistant's shots,
adds the bookkeeping fields, checks them like compile would and writes storyboard.draft.json.
"""

import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from studio_common import (PACKAGE, StudioError, read_json, write_json, now, load_project, manifest,
                           workflow_folder, workflow_resources)
from schema_check import document_errors
from validation import binding_errors, compile_prompt

PURPOSE = {"person": "identity", "prop": "prop", "scene": "scene", "voice": "voice"}
METHOD = PACKAGE / "references" / "storyboard-method.md"
# H3 talks fast: the presenter measured about 6.5 characters a second. 6 keeps the estimate a little safe.
SPOKEN_PER_SECOND = 6
# A 10-second shot with 33 characters left about 4.5 silent seconds, and the model filled them with made-up speech.
SILENT_GAP_SECONDS = 4
RULES = [
    "写镜头前先读“分镜方法”：一镜一件事，大动作单独成镜，只写看得见、听得见的东西，每镜写清结束状态。",
    "台词长度要对上镜头：说不完就拆镜或加时长；台词短、镜头长，模型会自己编话填满，空出来的时间写成具体无声动作。",
    "只看“预览”里的小图，绝不打开素材原图：原图会让对话变得很大、很慢。",
    "台词原样写进 dialogue，并在 overall_soundscape 里逐字写成 <d>[Chinese] 台词</d>，说完紧跟收嘴句。",
    "提示词只用 {{subject:ID}} {{picture:ID}} {{audio:ID}}；人物在 subject_definitions 同一行绑定自己的 picture。",
    "每个绑定的素材都要在 subject_definitions 说明用途，并在正文里至少引用一次；detailed_description 以 [Shot 1] 开头。",
    "声音只提供音色；场景图只管空间和光，不带人。只描写画面里看得到的衣着。",
    "镜头时长只能 5、10、15 秒。写完把 shots 存成 JSON 文件，运行 write-draft 项目名 --file 文件。",
]


def previews(folder, assets):
    """Small JPEG copies outside the project; None when this system cannot make them."""
    if sys.platform != "darwin" or not shutil.which("sips"):
        return {}
    target = Path(tempfile.gettempdir()) / "leoliu-studio-previews" / Path(folder).name
    target.mkdir(parents=True, exist_ok=True)
    result = {}
    for asset in assets:
        if asset["category"] == "voice":
            continue
        source = Path(folder) / asset["files"][0]["path"]
        preview = target / (asset["id"] + ".jpg")
        if not preview.is_file() or preview.stat().st_mtime < source.stat().st_mtime:
            subprocess.run(
                ["sips", "-s", "format", "jpeg", "-Z", "512", str(source), "--out", str(preview)],
                capture_output=True,
                check=False,
            )
        if preview.is_file():
            result[asset["id"]] = str(preview)
    return result


def next_revision(folder, project):
    draft = read_json(Path(folder) / "storyboard.draft.json", {}) or {}
    board = project["storyboard"]
    return (
        max(
            draft.get("draftRevision", 0),
            board.get("acceptedDraftRevision", 0),
            board.get("dismissedDraftRevision", 0),
        )
        + 1
    )


def kit(folder, workflow_id=None):
    project = load_project(folder)
    workflow_id = workflow_id or project["studio"]["currentWorkflow"]
    workflow = manifest(workflow_id)
    brief = project["brief"]["workflows"][workflow_id]
    assets = project["assets"]["items"]
    mentioned = re.findall(r"\(asset:([^)]+)\)", brief["text"])
    used = [a for a in assets if a["id"] in mentioned] or assets
    # People first, then props, scenes and voices: binding order sets the reference numbers.
    used = sorted(used, key=lambda a: list(PURPOSE).index(a["category"]))
    small = previews(folder, used)
    rows = []
    for asset in used:
        file = asset["files"][0]
        rows.append(
            {
                "名字": asset["name"],
                "类别": asset["category"],
                "说明": asset.get("description", ""),
                "assetId": asset["id"],
                "fileId": file["id"],
                **({"时长秒": round(file["durationSeconds"], 2)} if "durationSeconds" in file else {}),
                **({"预览": small[asset["id"]]} if asset["id"] in small else {}),
            }
        )
    settings = brief["settings"]
    seconds = settings.get("secondsPerShot", 5)
    seconds = seconds if seconds in workflow["limits"]["durations"] else 5
    skeleton = {
        "id": "shot-001",
        "order": 0,
        "durationSeconds": seconds,
        "summary": "中文一句话画面摘要",
        "dialogue": "原定中文台词，没有就写空字符串",
        "bindings": [
            {"assetId": a["id"], "fileId": a["files"][0]["id"], "purpose": PURPOSE[a["category"]]}
            for a in used
        ],
        "prompt": {key: "" for key in workflow["promptSections"]},
    }
    page = project["storyboard"]["workflows"].get(workflow_id, {}).get("shots", [])
    return {
        "工作流": workflow_id,
        "剧情": re.sub(r"@\[([^\]]*)\]\(asset:[^)]*\)", r"@\1", brief["text"]),
        "设置": settings,
        "素材": rows,
        "页面现有镜头数": len(page),
        "下一个草稿版本": next_revision(folder, project),
        "镜头模板": skeleton,
        "要点": RULES,
        "分镜方法": str(METHOD),
        "提示词写法": str(prompt_guide(workflow_id)) + " 有完整示例和这个工作流的不同之处，需要时再读。",
    }


def prompt_guide(workflow_id):
    """The workflow's own guide (extensions keep theirs beside the adapter), else its editor workflow's."""
    own = workflow_folder(workflow_id) / "prompt-guide.md"
    return own if own.is_file() else workflow_resources(workflow_id) / "prompt-guide.md"


def spoken_seconds(text):
    """Rough speaking time: letters, digits and Chinese characters count, punctuation does not."""
    return len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fffA-Za-z0-9]", text or "")) / SPOKEN_PER_SECOND


def timing_notes(shot, durations):
    """Advice when the line and the shot length do not match; never blocks the draft."""
    if not (shot.get("dialogue") or "").strip():
        return []
    length = shot["durationSeconds"]
    speech = spoken_seconds(shot["dialogue"])
    fits = [d for d in sorted(durations) if speech <= d - 0.5]
    if speech > length - 0.5:
        change = f"改成 {fits[0]} 秒或拆成两镜" if fits else "拆成两镜"
        return [f"台词约 {speech:.1f} 秒，{length} 秒镜头大概率说不完：{change}，不删用户的台词。"]
    if length - speech >= SILENT_GAP_SECONDS:
        shorter = f"改成 {fits[0]} 秒，或" if fits and fits[0] < length else ""
        return [
            f"台词约 {speech:.1f} 秒，{length} 秒镜头空出约 {int(length - speech + 0.5)} 秒，模型可能自己编话填满："
            f"{shorter}把空出来的时间写成具体的无声动作，台词说完写闭嘴。"
        ]
    return []


def write(folder, source, workflow_id=None):
    folder = Path(folder)
    project = load_project(folder)
    workflow_id = workflow_id or project["studio"]["currentWorkflow"]
    workflow = manifest(workflow_id)
    value = read_json(Path(source))
    shots = value.get("shots") if isinstance(value, dict) else value
    if not isinstance(shots, list) or not shots:
        raise StudioError("文件里要有 shots 列表，或者直接是镜头列表。")
    assets = {a["id"]: a for a in project["assets"]["items"]}
    errors = []
    for index, shot in enumerate(shots):
        shot["status"] = "draft"
        shot.setdefault("order", index)
        label = shot.get("id", f"第 {index + 1} 镜")
        problems = document_errors("shot", shot)
        if not problems:
            problems = binding_errors(shot, assets, workflow)
        if not problems:
            try:
                compile_prompt(shot, assets, workflow)
            except StudioError as error:
                problems = [str(error)]
        errors += [f"{label}：{problem}" for problem in problems]
    if errors:
        raise StudioError("草稿没写入，请改好再运行：\n" + "\n".join(errors))
    draft = read_json(folder / "storyboard.draft.json", {}) or {}
    revision = next_revision(folder, project)
    others = {k: v for k, v in draft.get("workflows", {}).items() if k != workflow_id}
    result = {
        "schemaVersion": 1,
        "draftRevision": revision,
        "updatedAt": now(),
        "workflows": {**others, workflow_id: {"shots": shots}},
    }
    problems = document_errors("storyboardDraft", result)
    if problems:
        raise StudioError("\n".join(problems))
    write_json(folder / "storyboard.draft.json", result)
    durations = workflow["limits"]["durations"]
    notes = [
        f"{shot.get('id', f'第 {index + 1} 镜')}：{note}"
        for index, shot in enumerate(shots)
        for note in timing_notes(shot, durations)
    ]
    return {
        "已写入": f"草稿版本 {revision}，{len(shots)} 个镜头",
        **({"提醒": notes} if notes else {}),
        "下一步": ("先看提醒要不要改，改了再写一版；然后" if notes else "")
        + "请用户回到工作台核对，点“采用新草稿”再通过。",
    }
