"""Extra commands a local extension workflow brings, for example installing its own environment on the instance.

The studio only dispatches: the workflow must be a local extension whose adapter defines
command(arguments, remote_factory); a paid extension needs a valid licence; the cloud operation lock is held
for the whole command, so it never overlaps a run. The extension gets the studio's own SSH connection.
"""
import studio_common as common
from studio_common import StudioError, manifest, workflow_folder
import licensing


def run(workflow_id, arguments, remote_factory=None):
    import engine_bridge as bridge
    from compiler import adapter

    value = manifest(workflow_id)
    name = value.get("name") or workflow_id
    if workflow_folder(workflow_id).resolve().parent != common.extension_workflows().resolve():
        raise StudioError("「" + name + "」是内置工作流，没有附加命令。")
    command = getattr(adapter(workflow_id), "command", None)
    if not callable(command):
        raise StudioError("「" + name + "」没有附加命令。")
    licensing.require(workflow_id, value)
    with bridge.h3.lease():
        result = command(list(arguments or []), remote_factory or bridge.StudioRemote)
    return result if result is not None else {"完成": name}
