"""Offline, device-bound licences for paid local extension workflows; standard library only.

A licence is a JSON document signed with ssh-keygen (namespace ``leoliu-studio-license``). It names one
extension workflow, the devices it may run on, when it expires and the SHA-256 of every file of the
extension it unlocks. The trust anchor is ``license-signers.txt`` in the signed core package. It is
deliberately not under ``keys/``: updates never replace ``keys/``, and the licence key has to reach
existing installations through a normal signed update.

Nothing here contacts a server. This keeps honest users honest and makes a leaked package traceable;
it cannot stop someone who edits the local Python, and the documentation says so.
"""

import base64
import hashlib
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import studio_common
from studio_common import PACKAGE, VERSION, StudioError, digest, read_json, write_json

NAMESPACE = "leoliu-studio-license"
IDENTITY = "leoliu-license"
SIGNERS = PACKAGE / "license-signers.txt"
REQUEST_PREFIX = "LEOREQ1."
CONTACT = "LeoLiu（微信 LeoLiu_AI）"
CLOCK_SLACK = timedelta(minutes=10)
MAX_PACKAGE_BYTES = 256 * 1024**2
MAX_MEMBERS = 4000
WORKFLOW_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]*")
LICENSE_ID = re.compile(r"L-[0-9]{8}-[0-9]{4}")
FILE_PATH = re.compile(r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*")
SHA256 = re.compile(r"[0-9a-f]{64}")
PLANS = {"trial": "试用", "month": "月付", "quarter": "季付", "year": "年付", "custom": "授权", "permanent": "永久"}
VALID = ("trial", "active")


def utcnow():
    return datetime.now(timezone.utc)


def licenses_dir():
    return studio_common.extension_workflows().parent / "licenses"


def hardware_id():
    """Stable machine identifier, or None. Only its salted hash ever leaves this function's caller."""
    try:
        if sys.platform == "darwin":
            output = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True, text=True, timeout=5
            ).stdout
            found = re.search(r'"IOPlatformUUID"\s*=\s*"([0-9A-Fa-f-]{36})"', output)
            return found.group(1).upper() if found else None
        if sys.platform == "win32":
            import winreg

            access = winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0, access) as key:
                return str(winreg.QueryValueEx(key, "MachineGuid")[0]).strip().lower() or None
        for name in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            path = Path(name)
            if path.is_file() and path.read_text(encoding="utf-8").strip():
                return path.read_text(encoding="utf-8").strip()
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    return None


def device_id():
    source = hardware_id()
    if not source:
        # Rare fallback: a random identity kept beside the licences. Deleting it means a new request.
        path = licenses_dir() / ".device"
        if not path.is_file():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(uuid.uuid4().hex + "\n", encoding="utf-8")
        source = "local:" + path.read_text(encoding="utf-8").strip()
    return hashlib.sha256(("leoliu-studio-device-v1\n" + source).encode("utf-8")).hexdigest()


def platform_name():
    return {"darwin": "macOS", "win32": "Windows"}.get(sys.platform, sys.platform)


def request():
    payload = {"v": 1, "device": device_id(), "studio": VERSION, "platform": platform_name(),
               "at": utcnow().replace(microsecond=0).isoformat()}
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    body = base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
    return {
        "申请码": REQUEST_PREFIX + body + "." + hashlib.sha256(raw).hexdigest()[:8],
        "本机编号": payload["device"][:12],
        "下一步": "把整串申请码发给 " + CONTACT + "。收到授权包后运行 license install 授权包.zip。",
        "说明": "申请码只含本机设备编号的散列、工作台版本和系统类型，不含项目、素材、账号或密码。",
    }


def parse_request(code):
    """Decode a request code. Used by the issuer; kept here so both sides share one format."""
    code = "".join(str(code).split())
    found = re.fullmatch(r"LEOREQ1\.([A-Za-z0-9_-]+)\.([0-9a-f]{8})", code)
    if not found:
        raise StudioError("申请码格式不对，请整串复制，以 LEOREQ1. 开头。")
    body = found.group(1)
    try:
        raw = base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
    except ValueError as error:
        raise StudioError("申请码无法解码，可能复制时缺了字符。") from error
    if hashlib.sha256(raw).hexdigest()[:8] != found.group(2):
        raise StudioError("申请码校验不通过，可能复制时缺了字符。")
    try:
        value = json.loads(raw)
    except ValueError as error:
        raise StudioError("申请码内容不对。") from error
    if not isinstance(value, dict) or value.get("v") != 1 or not SHA256.fullmatch(str(value.get("device", ""))):
        raise StudioError("申请码内容不对。")
    return value


def signer_lines():
    if not SIGNERS.is_file():
        return []
    return [
        line.strip()
        for line in SIGNERS.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


def verify(raw, signature):
    lines = signer_lines()
    if not lines:
        raise StudioError("这个工作台版本还没有授权公钥，请先更新工作台再安装授权。")
    with tempfile.TemporaryDirectory(prefix="studio-license-") as temporary:
        signers = Path(temporary) / "signers"
        signers.write_text("\n".join(lines) + "\n", encoding="utf-8")
        path = Path(temporary) / "license.sig"
        path.write_bytes(signature)
        try:
            process = subprocess.run(
                ["ssh-keygen", "-Y", "verify", "-f", str(signers), "-I", IDENTITY, "-n", NAMESPACE, "-s", str(path)],
                input=raw,
                capture_output=True,
                timeout=5,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise StudioError("授权签名工具不可用：需要系统自带的 ssh-keygen（OpenSSH）。") from error
        if process.returncode:
            raise StudioError("授权签名不正确，请向 " + CONTACT + " 重新获取授权包。")


def parse_time(value, label):
    try:
        result = datetime.fromisoformat(str(value))
    except ValueError as error:
        raise StudioError("授权里的" + label + "格式不对。") from error
    if result.tzinfo is None:
        raise StudioError("授权里的" + label + "缺少时区。")
    return result


def parse_license(raw):
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as error:
        raise StudioError("授权文件格式不对。") from error
    problem = "授权文件内容不完整。"
    if not isinstance(value, dict) or value.get("schemaVersion") != 1:
        raise StudioError(problem)
    if not LICENSE_ID.fullmatch(str(value.get("licenseId", ""))):
        raise StudioError(problem)
    customer = value.get("customer")
    if not isinstance(customer, str) or not 0 < len(customer.strip()) <= 40:
        raise StudioError(problem)
    if not WORKFLOW_ID.fullmatch(str(value.get("workflow", ""))) or value.get("plan") not in PLANS:
        raise StudioError(problem)
    devices = value.get("devices")
    if not isinstance(devices, list) or not 0 < len(devices) <= 10 or not all(
        isinstance(item, str) and SHA256.fullmatch(item) for item in devices
    ):
        raise StudioError(problem)
    package = value.get("package")
    files = package.get("files") if isinstance(package, dict) else None
    if not isinstance(package.get("version") if isinstance(package, dict) else None, str) or not isinstance(files, dict):
        raise StudioError(problem)
    for name, sha in files.items():
        if (
            not FILE_PATH.fullmatch(name)
            or any(part in (".", "..") for part in name.split("/"))
            or not isinstance(sha, str)
            or not SHA256.fullmatch(sha)
        ):
            raise StudioError(problem)
    if "manifest.json" not in files or "adapter.py" not in files:
        raise StudioError(problem)
    issued = parse_time(value.get("issuedAt"), "签发时间")
    # A permanent licence has no expiry at all (expiresAt null); every other plan must end after it starts.
    if value["plan"] == "permanent":
        if value.get("expiresAt") is not None:
            raise StudioError(problem)
    elif parse_time(value.get("expiresAt"), "到期时间") <= issued:
        raise StudioError(problem)
    return value


def expired(value, moment):
    return value.get("expiresAt") is not None and moment >= parse_time(value["expiresAt"], "到期时间")


def state_path():
    return licenses_dir() / "state.json"


def last_seen(license_id):
    seen = read_json(state_path(), {"schemaVersion": 1, "lastSeen": {}}).get("lastSeen", {})
    value = seen.get(license_id) if isinstance(seen, dict) else None
    try:
        return datetime.fromisoformat(value) if value else None
    except ValueError:
        return None


def touch(license_id, moment):
    state = read_json(state_path(), {"schemaVersion": 1, "lastSeen": {}})
    seen = state.get("lastSeen") if isinstance(state.get("lastSeen"), dict) else {}
    previous = last_seen(license_id)
    if previous is None or moment > previous:
        seen[license_id] = moment.isoformat()
        write_json(state_path(), {"schemaVersion": 1, "lastSeen": seen})


def clock_problem(value, moment):
    previous = last_seen(value["licenseId"])
    if previous is not None and moment < previous - CLOCK_SLACK:
        return "本机时间比上次使用时还早，授权暂停。请把电脑时间调回正确时间再试。"
    if moment < parse_time(value["issuedAt"], "签发时间") - timedelta(days=1):
        return "本机时间早于授权签发时间，请把电脑时间调回正确时间再试。"
    return None


def days_left(value, moment):
    return max(0, math.ceil((parse_time(value["expiresAt"], "到期时间") - moment).total_seconds() / 86400))


def shown_time(value):
    return parse_time(value, "到期时间").strftime("%Y-%m-%d %H:%M")


def package_problem(folder, files):
    folder = Path(folder)
    for name, expected in files.items():
        path = folder / name
        if path.is_symlink() or not path.is_file() or digest(path) != expected:
            return name
    return None


def license_files(workflow_id):
    folder = licenses_dir()
    return folder / (workflow_id + ".json"), folder / (workflow_id + ".json.sig")


def check(workflow_id, value=None):
    """Licence state of one workflow. Never raises for a missing or bad licence; see require()."""
    folder = studio_common.extension_workflows() / workflow_id
    value = value if value is not None else read_json(folder / "manifest.json")
    product = value.get("entitlement")
    name = value.get("name") or workflow_id
    base = {"工作流": workflow_id, "名称": name}
    if not product:
        return dict(base, state="free")
    missing = "「" + name + "」是付费工作流，这台电脑还没有授权。运行 license request，把申请码发给 " + CONTACT + "。"
    path, signature = license_files(workflow_id)
    if not path.is_file() or not signature.is_file():
        return dict(base, state="missing", message=missing)
    raw = path.read_bytes()
    try:
        verify(raw, signature.read_bytes())
        licence = parse_license(raw)
    except StudioError as error:
        return dict(base, state="invalid", message=str(error))
    info = dict(
        base,
        licenseId=licence["licenseId"],
        customer=licence["customer"],
        plan=licence["plan"],
        planName=PLANS[licence["plan"]],
        expiresAt=licence.get("expiresAt"),
    )
    if licence["workflow"] != workflow_id or product != workflow_id:
        return dict(info, state="invalid", message="授权和工作流对不上，请重新安装授权包。")
    if device_id() not in licence["devices"]:
        return dict(info, state="device", message="这份授权不是发给这台电脑的。换电脑请运行 license request，把新的申请码发给 " + CONTACT + "。")
    changed = package_problem(folder, licence["package"]["files"])
    if changed:
        return dict(info, state="tampered", message="「" + name + "」的文件和授权对不上（" + changed + " 被改动或缺失），请重新安装授权包。")
    moment = utcnow()
    problem = clock_problem(licence, moment)
    if problem:
        return dict(info, state="clock", message=problem)
    if licence.get("expiresAt") is None:
        return dict(info, state="active", message="永久授权，不会到期。")
    if expired(licence, moment):
        return dict(
            info,
            state="expired",
            daysLeft=0,
            message="「" + name + "」的授权已在 " + shown_time(licence["expiresAt"]) + " 到期。项目、素材和已出的视频都还在；"
            "续费请联系 " + CONTACT + "，拿到新授权包后运行 license install。",
        )
    left = days_left(licence, moment)
    return dict(
        info,
        state="trial" if licence["plan"] == "trial" else "active",
        daysLeft=left,
        message=PLANS[licence["plan"]] + "，" + shown_time(licence["expiresAt"]) + " 到期，还剩 " + str(left) + " 天。",
    )


def require(workflow_id, value=None):
    """Raise unless the workflow is free or holds a valid licence; records the time for clock checks."""
    status = check(workflow_id, value)
    if status["state"] == "free":
        return status
    if status["state"] not in VALID:
        raise StudioError(status["message"])
    touch(status["licenseId"], utcnow())
    return status


def display_name(value):
    """Name shown on the page card, so the state is visible without a new editor build."""
    status = check(value["id"], value)
    state, name = status["state"], value.get("name") or value["id"]
    if state == "free":
        return name
    if state == "trial":
        return name + " · 试用剩 " + str(status["daysLeft"]) + " 天"
    if state == "active":
        left = status.get("daysLeft")
        return name + (" · 剩 " + str(left) + " 天" if left is not None and left <= 7 else "")
    if state == "expired":
        return name + " · 已到期"
    return name + " · 未授权"


def summary(status):
    keys = {"工作流": "工作流", "名称": "名称", "customer": "授权给", "planName": "方案", "expiresAt": "到期",
            "daysLeft": "剩余天数", "licenseId": "授权编号", "message": "说明"}
    states = {"free": "免费", "trial": "试用中", "active": "有效", "expired": "已到期", "missing": "未授权",
              "invalid": "授权无效", "device": "不是本机的授权", "tampered": "文件被改动", "clock": "本机时间不对"}
    result = {label: status[key] for key, label in keys.items() if key in status}
    if "到期" in result:
        result["到期"] = "不会到期" if result["到期"] is None else shown_time(result["到期"])
    result["状态"] = states[status["state"]]
    return result


def status_all():
    from studio_common import workflow_directories

    rows = []
    for workflow_id, folder in workflow_directories().items():
        if folder.parent != studio_common.extension_workflows():
            continue
        value = read_json(folder / "manifest.json")
        if value.get("entitlement"):
            rows.append(summary(check(workflow_id, value)))
    return {"本机编号": device_id()[:12], "付费工作流": rows or "这台电脑没有安装付费工作流。"}


def safe_members(archive):
    members = {}
    total = 0
    for item in archive.infolist():
        name = item.filename
        if item.is_dir():
            continue
        parts = name.split("/")
        if (
            "\\" in name
            or name.startswith("/")
            or ":" in name
            or any(part in ("", ".", "..") for part in parts)
            or stat.S_ISLNK(item.external_attr >> 16)
            or name in members
        ):
            raise StudioError("授权包含不安全的路径，已拒绝。")
        total += item.file_size
        if len(members) >= MAX_MEMBERS or total > MAX_PACKAGE_BYTES:
            raise StudioError("授权包过大，已拒绝。")
        members[name] = item
    return members


def install(path):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise StudioError("找不到授权包：" + str(path))
    if path.stat().st_size > MAX_PACKAGE_BYTES:
        raise StudioError("授权包过大，已拒绝。")
    workflows = studio_common.extension_workflows()
    if any(item.is_symlink() for item in (workflows, *workflows.parents) if item.exists()):
        raise StudioError("本机扩展工作流目录不能使用符号链接。")
    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as error:
        raise StudioError("授权包不是有效的 ZIP 文件。") from error
    staging = workflows.parent / ".staging" / ("install-" + uuid.uuid4().hex)
    try:
        with archive:
            members = safe_members(archive)
            if "license.json" not in members or "license.json.sig" not in members:
                raise StudioError("授权包缺少授权文件。")
            raw = archive.read(members["license.json"])
            signature = archive.read(members["license.json.sig"])
            verify(raw, signature)
            licence = parse_license(raw)
            workflow_id = licence["workflow"]
            if device_id() not in licence["devices"]:
                raise StudioError("这份授权不是发给这台电脑的。请运行 license request，把本机申请码发给 " + CONTACT + "。")
            moment = utcnow()
            problem = clock_problem(licence, moment)
            if problem:
                raise StudioError(problem)
            if expired(licence, moment):
                raise StudioError("这份授权已在 " + shown_time(licence["expiresAt"]) + " 到期，请向 " + CONTACT + " 要新的授权包。")
            prefix = "extension/" + workflow_id + "/"
            package = {name[len(prefix):]: item for name, item in members.items() if name.startswith(prefix)}
            expected = licence["package"]["files"]
            if set(members) - {"license.json", "license.json.sig"} - {prefix + name for name in package}:
                raise StudioError("授权包里有多余的文件，已拒绝。")
            if set(package) != set(expected):
                raise StudioError("授权包里的工作流文件和授权对不上，已拒绝。")
            target = workflows / workflow_id
            unchanged = target.is_dir() and not package_problem(target, expected)
            if not unchanged:
                for name, item in package.items():
                    destination = staging / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    sha = hashlib.sha256()
                    with archive.open(item) as source, destination.open("wb") as output:
                        for chunk in iter(lambda: source.read(1024 * 1024), b""):
                            sha.update(chunk)
                            output.write(chunk)
                    if sha.hexdigest() != expected[name]:
                        raise StudioError("授权包里的 " + name + " 散列不对，已拒绝。")
                value = read_json(staging / "manifest.json")
                if not isinstance(value, dict) or value.get("id") != workflow_id or value.get("entitlement") != workflow_id:
                    raise StudioError("授权包里的工作流说明和授权对不上，已拒绝。")
        backup = None
        if not unchanged:
            workflows.mkdir(parents=True, exist_ok=True)
            if target.exists():
                backup = workflows.parent / "backups" / (workflow_id + "-" + moment.strftime("%Y%m%d-%H%M%S"))
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(target), str(backup))
            os.replace(staging, target)
        license_path, signature_path = license_files(workflow_id)
        previous = [item.read_bytes() if item.is_file() else None for item in (license_path, signature_path)]
        license_path.parent.mkdir(parents=True, exist_ok=True)
        atomic_bytes(license_path, raw)
        atomic_bytes(signature_path, signature)
        try:
            from studio_common import registry

            registry()
            status = check(workflow_id)
            if status["state"] not in VALID:
                raise StudioError(status["message"])
        except StudioError:
            # Leave the machine as it was: restore the previous extension and licence.
            if not unchanged:
                shutil.rmtree(target, ignore_errors=True)
                if backup is not None:
                    shutil.move(str(backup), str(target))
            for item, content in zip((license_path, signature_path), previous):
                if content is None:
                    item.unlink(missing_ok=True)
                else:
                    atomic_bytes(item, content)
            raise
        touch(licence["licenseId"], moment)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
        try:
            staging.parent.rmdir()
        except OSError:
            pass
    result = summary(status)
    result["下一步"] = "运行 open 重新打开工作台，页面上会出现「" + display_name(read_json(target / "manifest.json")) + "」。"
    if backup is not None:
        result["旧版本备份"] = str(backup)
    return result


def atomic_bytes(path, content):
    path = Path(path)
    descriptor, name = tempfile.mkstemp(prefix="." + path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)
