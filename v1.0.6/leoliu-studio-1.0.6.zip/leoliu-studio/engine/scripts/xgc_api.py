"""仙宫云 (xiangongyun.com) open API: release-GPU shutdown sent from this computer.

Tested 2026-11-15 on a real instance. Inside a 仙宫云 container there is no platform shutdown command
(AutoDL's /usr/bin/shutdown does not exist), and POST /open/instance/shutdown keeps the GPU and keeps
billing. The only call that stops GPU billing is POST /open/instance/shutdown_release_gpu with the
account access token; status then goes shutdown_backing_up -> shutdown (about 4 minutes).

The token can read every instance's SSH password, so it stays in the macOS keychain or Windows
Credential Manager (service leoliu-xgc-api-token). It is never sent to an instance, written to a file,
printed or put on a command line.
"""

import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request

from common import H3Error

API = "https://api.xiangongyun.com"
SERVICE = "leoliu-xgc-api-token"
HOST_SUFFIX = ".ssh.x-gpu.com"
IN_PROGRESS = {"running", "shutting_down", "shutdown_backing_up"}
POLL_SECONDS = 10
# A 300 GB disk took over 15 minutes in shutdown_backing_up on 11-15; 100 GB took 224 s.
TIMEOUT_SECONDS = 3600


def is_xgc(host):
    return isinstance(host, str) and host.lower().endswith(HOST_SUFFIX)


def instance_id(host):
    value = host.lower().split(".", 1)[0] if is_xgc(host) else ""
    if not re.fullmatch(r"[a-z0-9]{8,40}", value):
        raise H3Error("认不出仙宫云实例编号，请去控制台手动关机（释放GPU）。")
    return value


def looks_like_token(value):
    return bool(value) and not any(c.isspace() for c in value) and "@" not in value and not value.lower().startswith("ssh")


def token_get():
    if sys.platform == "win32":
        import local_support as local

        try:
            return local.windows_get(SERVICE)["token"]
        except (H3Error, KeyError, TypeError, ValueError):
            return None
    process = subprocess.run(["security", "find-generic-password", "-s", SERVICE, "-w"],
                             capture_output=True, text=True, encoding="utf-8")
    raw = process.stdout.strip() if process.returncode == 0 else ""
    if raw and len(raw) % 2 == 0 and all(c in "0123456789abcdef" for c in raw):
        try:
            raw = bytes.fromhex(raw).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            pass
    return raw if looks_like_token(raw) else None


def token_set(value):
    value = (value or "").strip()
    if not looks_like_token(value):
        raise H3Error("粘贴的不像仙宫云访问令牌（带空格、@ 或以 ssh 开头，可能是 SSH 指令），未保存。")
    if sys.platform == "win32":
        import local_support as local

        local.windows_set({"token": value}, SERVICE)
        return
    process = subprocess.run(
        ["security", "-i"],
        input=f"add-generic-password -U -a leoliu -s {SERVICE} -X {value.encode('utf-8').hex()}\n",
        capture_output=True, text=True, encoding="utf-8",
    )
    if process.returncode or token_get() != value:
        raise H3Error("钥匙串保存未通过；请允许 Mac 的钥匙串权限提示后重试。")


def request(method, path, token, body=None):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    call = urllib.request.Request(API + path, data=data, method=method,
                                  headers={"Authorization": token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(call, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise H3Error(f"仙宫云接口返回 HTTP {error.code}，请去控制台手动关机（释放GPU）。") from None
    except (urllib.error.URLError, OSError, ValueError):
        raise H3Error("连不上仙宫云接口，请去控制台手动关机（释放GPU）。") from None


def checked(reply, action):
    if isinstance(reply, dict) and reply.get("success"):
        return reply.get("data")
    code = reply.get("code") if isinstance(reply, dict) else None
    if code == 1000:
        raise H3Error("仙宫云访问令牌无效或已过期：请在控制台重新生成，再运行 save-xgc-token。")
    message = str(reply.get("msg", "")) if isinstance(reply, dict) else ""
    raise H3Error(f"仙宫云{action}没有成功（{code} {message[:60]}）；请去控制台手动关机（释放GPU）。")


def count_instances(token, call=request):
    data = checked(call("GET", "/open/instances", token), "查询实例")
    rows = data.get("list", data) if isinstance(data, dict) else data
    return len(rows) if isinstance(rows, list) else 0


def shutdown_release_gpu(host, token=None, call=request, sleep=time.sleep, clock=time.monotonic,
                         timeout=TIMEOUT_SECONDS, say=None):
    """Release-GPU shutdown of the instance behind an SSH host; returns once status is shutdown."""
    say = say or (lambda text: None)
    instance = instance_id(host)
    token = token or token_get()
    if not token:
        raise H3Error("还没保存仙宫云访问令牌：请运行 save-xgc-token 在私密窗口里粘贴，然后再关机；"
                      "现在请去控制台手动关机（释放GPU）。")
    checked(call("POST", "/open/instance/shutdown_release_gpu", token, {"id": instance}), "关机释放GPU")
    say("已向仙宫云提交“关机释放GPU”：" + instance)
    started, last = clock(), None
    while clock() - started < timeout:
        sleep(POLL_SECONDS)
        data = checked(call("GET", "/open/instance/" + instance, token), "查询实例状态")
        status = data.get("status") if isinstance(data, dict) else None
        if status != last:
            last = status
            say("仙宫云实例状态：" + str(status))
        if status == "shutdown":
            return "已通过仙宫云接口关机并释放 GPU（实例 " + instance + "），GPU 不再计费，只收磁盘保留费。"
        if status not in IN_PROGRESS:
            raise H3Error(f"关机后实例状态是 {status}，不是“已关机”；请去控制台核对。")
    raise H3Error("关机请求已提交，但 60 分钟内没到“已关机”（大盘备份可能很慢）；请去控制台核对。")


def main(argv=None):
    """python3 xgc_api.py status|shutdown <SSH 主机名或实例编号>

    For instances the engine does not manage (for example a separately installed ComfyUI): shutdown releases
    the GPU and waits for 已关机. It does not check for queued work first; only use it when nothing runs.
    """
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 2 or argv[0] not in ("status", "shutdown"):
        print("用法：python3 xgc_api.py status|shutdown <SSH 主机名或实例编号>", file=sys.stderr)
        return 2
    action, target = argv
    host = target if is_xgc(target) else target + HOST_SUFFIX
    try:
        if action == "shutdown":
            print(shutdown_release_gpu(host, say=print))
        else:
            token = token_get()
            if not token:
                raise H3Error("还没保存仙宫云访问令牌：请运行 save-xgc-token。")
            data = checked(request("GET", "/open/instance/" + instance_id(host), token), "查询实例状态")
            print(json.dumps({key: data.get(key) for key in ("id", "status", "gpu_model", "price_per_hour")},
                             ensure_ascii=False))
        return 0
    except H3Error as error:
        print("未完成：" + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
