"""Standard-library project IO; canvas.json is intentionally absent."""

import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path

PACKAGE = Path(__file__).resolve().parents[1]
ROOT = PACKAGE if (PACKAGE / "workflows").is_dir() else PACKAGE.parent
WORKFLOWS = ROOT / "workflows"
SCHEMAS = ROOT / "contract/schemas"
VERSION = (
    json.loads((PACKAGE / "version.json").read_text(encoding="utf-8"))["version"]
    if (PACKAGE / "version.json").is_file()
    else "1.0.5"
)


class StudioError(Exception):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024**2), b""):
            result.update(chunk)
    return result.hexdigest()


def read_json(path, default=None):
    path = Path(path)
    if not path.exists() and default is not None:
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (ValueError, OSError) as error:
        raise StudioError("无法读取项目文件：" + path.name) from error


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix="." + path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def safe_relative(root, relative):
    if not isinstance(relative, str) or not re.fullmatch(
        r"[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)*", relative
    ):
        raise StudioError("文件路径须使用项目内的 ASCII 相对路径。")
    if any(part in (".", "..") for part in relative.split("/")):
        raise StudioError("文件路径不能离开项目目录。")
    root = Path(root).resolve()
    result = (root / relative).resolve()
    try:
        result.relative_to(root)
    except ValueError as error:
        raise StudioError("文件路径不能离开项目目录。") from error
    return result


def load_project(folder):
    folder = Path(folder).resolve()
    project = {"path": folder}
    for name in ("studio", "assets", "brief", "storyboard", "review", "results"):
        path = folder / (name + ".json")
        if name in ("storyboard", "review") and not path.exists():
            # The page writes only documents that changed, so a project created there has no storyboard or
            # review file until a shot or review exists. Read them as the empty documents `new` writes.
            project[name] = None
            continue
        fallback = {"schemaVersion": 1, "items": []} if name == "results" else None
        project[name] = read_json(path, fallback)
    if project["storyboard"] is None or project["review"] is None:
        ids = [row["id"] for row in registry()]
        if project["storyboard"] is None:
            project["storyboard"] = {
                "schemaVersion": 1,
                "acceptedDraftRevision": 0,
                "dismissedDraftRevision": 0,
                "locallyEdited": False,
                "updatedAt": (project["studio"] or {}).get("createdAt") or now(),
                "workflows": {workflow_id: {"shots": []} for workflow_id in ids},
            }
        if project["review"] is None:
            project["review"] = {"schemaVersion": 1, "workflows": {workflow_id: {"items": []} for workflow_id in ids}}
    frames = read_json(folder / "frame-assets.json", {"schemaVersion": 1, "items": []})
    from schema_check import document_errors

    errors = document_errors("assets", frames)
    if errors:
        raise StudioError("末帧素材记录无效：" + "\n".join(errors))
    existing = {row["id"] for row in project["assets"]["items"]}
    project["assets"]["items"].extend(
        row for row in frames["items"]
        if row["id"] not in existing and all(safe_relative(folder, file["path"]).is_file() for file in row["files"])
    )
    return project


def workflow_directories():
    from workflow_registry import discover

    return discover(WORKFLOWS, extension_workflows())


def extension_workflows():
    return Path(os.environ.get("LEOLIU_STUDIO_EXTENSIONS", Path.home() / "LeoLiuStudio/extensions/workflows")).expanduser()


def workflow_folder(workflow_id):
    if not isinstance(workflow_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", workflow_id):
        raise StudioError("工作流编号不合法。")
    folder = workflow_directories().get(workflow_id)
    if folder is None:
        raise StudioError("工作流未安装，请更新工作台：" + workflow_id)
    return folder


def workflow_resources(workflow_id):
    workflow = manifest(workflow_id)
    return WORKFLOWS / workflow["editorWorkflow"] if "editorWorkflow" in workflow else workflow_folder(workflow_id)


def manifest(workflow_id):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", workflow_id):
        raise StudioError("工作流编号不合法。")
    path = workflow_folder(workflow_id) / "manifest.json"
    if not path.is_file():
        raise StudioError("工作流未安装，请更新工作台：" + workflow_id)
    result = read_json(path)
    if result["id"] != workflow_id:
        raise StudioError("工作流目录与 manifest 编号不一致。")
    return result


def registry():
    return sorted(
        [manifest(workflow_id) for workflow_id in workflow_directories()],
        key=lambda row: row["order"],
    )
