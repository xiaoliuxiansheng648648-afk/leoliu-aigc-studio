#!/usr/bin/env python3
"""LeoLiu Studio: local project orchestration; Python 3.9+ standard library only."""
import argparse
import json
import re
import sys
import uuid
from pathlib import Path
from studio_common import (
    VERSION,
    StudioError,
    now,
    registry,
    manifest,
    load_project,
    read_json,
    write_json,
    PACKAGE,
)
from validation import validate_project
from compiler import compile_project
from auto_reroll import summary as reroll_summary


def project_folder(root, name):
    if not name.strip() or name in (".", "..") or re.search(r'[\\/:*?"<>|]', name):
        raise StudioError("项目名不合法，请使用根文件夹下的项目名。")
    folder = (root / name).resolve()
    if folder.parent != root.resolve():
        raise StudioError("项目目录不能离开根文件夹。")
    return folder


def create_project(root, name, workflow_id):
    manifest(workflow_id)
    folder = project_folder(root, name)
    folder.mkdir(parents=True, exist_ok=False)
    created = now()
    write_json(
        folder / "studio.json",
        {
            "schemaVersion": 1,
            "projectId": "p-" + uuid.uuid4().hex,
            "name": name,
            "currentWorkflow": workflow_id,
            "createdAt": created,
        },
    )
    brief, storyboard, reviews = {}, {}, {}
    for workflow in registry():
        settings = {
            key: workflow["defaults"][key]
            for key in ("orientation", "secondsPerShot", "shotCount", "style")
        }
        settings["sequentialReview"] = workflow["id"] == "h3-hybrid"
        brief[workflow["id"]] = {"text": "", "settings": settings}
        storyboard[workflow["id"]] = {"shots": []}
        reviews[workflow["id"]] = {"items": []}
    write_json(folder / "assets.json", {"schemaVersion": 1, "items": []})
    write_json(folder / "brief.json", {"schemaVersion": 1, "workflows": brief})
    write_json(
        folder / "storyboard.json",
        {
            "schemaVersion": 1,
            "acceptedDraftRevision": 0,
            "dismissedDraftRevision": 0,
            "locallyEdited": False,
            "updatedAt": created,
            "workflows": storyboard,
        },
    )
    write_json(folder / "review.json", {"schemaVersion": 1, "workflows": reviews})
    write_json(folder / "results.json", {"schemaVersion": 1, "items": []})
    return {"项目": name, "目录": str(folder), "下一步": "打开工作台，连接根文件夹并添加素材。"}


def status(folder):
    import sequential_review
    import ai_review

    project = load_project(folder)
    workflows = []
    for key, brief in project["brief"]["workflows"].items():
        shots = project["storyboard"]["workflows"].get(key, {}).get("shots", [])
        approved = sum(shot["status"] == "approved" for shot in shots)
        workflows.append(
            {
                "工作流": key,
                "剧情": brief["text"],
                "设置": brief["settings"],
                "镜头数": len(shots),
                "已通过": approved,
                "下一步": (
                    "先写剧情"
                    if not brief["text"]
                    else (
                        "运行 draft-kit 拿素材和模板，再用 write-draft 写入草稿"
                        if not shots
                        else (
                            "请用户在页面通过分镜"
                            if approved < len(shots)
                            else "可运行 run，只生成已通过且尚未执行的镜头"
                        )
                    )
                ),
            }
        )
    # Same scope as run: workflows with approved shots, else the project's own workflow before approval.
    running = {
        key
        for key, board in project["storyboard"]["workflows"].items()
        if any(shot["status"] == "approved" for shot in board["shots"])
    } or {project["studio"]["currentWorkflow"]}
    return {
        "项目": project["studio"],
        "素材": project["assets"]["items"],
        "工作流": workflows,
        "页面采用的草稿版本": project["storyboard"]["acceptedDraftRevision"],
        "重抽与备注": project["review"],
        "AI 自动重抽": reroll_summary(project, folder),
        "AI 自动审核": ai_review.records(folder),
        "逐镜审核": sequential_review.instruction(project, running) if sequential_review.enabled(project, running) else "关闭（默认）",
        "结果": project["results"],
        "运行标记": [str(path.relative_to(folder)) for path in folder.glob("runs/*/RUNNING")],
    }


def parser():
    result = argparse.ArgumentParser(description="LeoLiu 工作台：项目、分镜校验、编译、生成与更新")
    result.add_argument(
        "--root", type=Path, default=Path.home() / "LeoLiuStudio", help="项目根目录"
    )
    sub = result.add_subparsers(dest="command", required=True)
    opened = sub.add_parser("open")
    opened.add_argument("--project")
    opened.add_argument("--print-target", action="store_true")
    created = sub.add_parser("new")
    created.add_argument("project")
    created.add_argument("--workflow", required=True)
    sub.add_parser("list")
    sub.add_parser("version")
    sub.add_parser("selftest")
    for name in ("status", "validate", "compile", "run", "wait", "setup"):
        command = sub.add_parser(name)
        command.add_argument("project")
        if name == "compile":
            command.add_argument("--shots", nargs="+")
            command.add_argument("--dry-run", action="store_true")
        if name == "run":
            command.add_argument("--defer-shutdown", action="store_true")
        if name == "wait":
            command.add_argument("--run-id", required=True)
        if name == "setup":
            command.add_argument("--data-dir", help="实例上的数据目录；单盘实例首次安装时指定")
            command.add_argument("--python", help="实例上已有的 Python 3.12＋CUDA PyTorch，不另装运行库")
            command.add_argument("--reserve-vram", type=float, help="给实例上已有服务预留的显存 GB")
    kit = sub.add_parser("draft-kit")
    kit.add_argument("project")
    kit.add_argument("--workflow")
    drafted = sub.add_parser("write-draft")
    drafted.add_argument("project")
    drafted.add_argument("--file", type=Path, required=True)
    drafted.add_argument("--workflow")
    rerolled = sub.add_parser("auto-reroll")
    rerolled.add_argument("project")
    rerolled.add_argument("--shots", nargs="+", required=True)
    rerolled.add_argument("--reason", required=True)
    reviewed = sub.add_parser("ai-review")
    reviewed.add_argument("project")
    reviewed.add_argument("--workflow", default="h3-hybrid")
    reviewed.add_argument("--shot", required=True)
    reviewed.add_argument("--result", required=True)
    reviewed.add_argument("--decision", choices=["passed", "unsatisfied"], required=True)
    reviewed.add_argument("--reason", required=True)
    update = sub.add_parser("update")
    group = update.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true")
    group.add_argument("--apply", action="store_true")
    update.add_argument("--channel")
    update.add_argument("--allowed-signers", type=Path, help="仅本地临时签名测试使用")
    engine = sub.add_parser("engine")
    engine.add_argument("arguments", nargs=argparse.REMAINDER)
    return result


def selftest():
    from compiler import adapter
    from schema_check import document_errors
    from studio_common import workflow_resources, digest
    from opener import local_editor
    import engine_bridge
    from common import ARCHIVE_SHA

    for workflow in registry():
        adapter(workflow["id"])
        folder = workflow_resources(workflow["id"])
        if not (folder / "prompt-guide.md").is_file():
            raise StudioError("工作流提示词指南缺失：" + workflow["id"])
        graphs = list(folder.glob("*.api.json"))
        if not graphs or any(not isinstance(read_json(graph), dict) for graph in graphs):
            raise StudioError("工作流图缺失或格式错误：" + workflow["id"])
    if not local_editor().is_file() or local_editor().stat().st_size < 100:
        raise StudioError("编辑器构建缺失，请重新构建或安装工作台。")
    runtime = engine_bridge.h3.ROOT / "assets/runtime/comfyui-source.tar.gz"
    if not runtime.is_file() or digest(runtime) != ARCHIVE_SHA:
        raise StudioError("引擎运行时缺失或散列不正确。")
    if not (PACKAGE / "engine/scripts/h3_cloud.py").is_file():
        raise StudioError("引擎文件缺失。")
    if document_errors("results", {"schemaVersion": 1, "items": []}):
        raise StudioError("项目合同自检失败。")
    return {"版本": VERSION, "工作流数": len(registry()), "自检": "通过"}


def main(argv=None):
    args = parser().parse_args(argv)
    root = args.root.expanduser().resolve()
    try:
        if args.command == "new":
            value = create_project(root, args.project, args.workflow)
        elif args.command == "list":
            value = (
                [
                    path.name
                    for path in root.iterdir()
                    if path.is_dir() and (path / "studio.json").is_file()
                ]
                if root.exists()
                else []
            )
        elif args.command == "version":
            value = {"name": "leoliu-studio", "version": VERSION, "schemaVersion": 1}
        elif args.command == "selftest":
            value = selftest()
        elif args.command == "status":
            value = status(project_folder(root, args.project))
        elif args.command == "validate":
            errors = validate_project(load_project(project_folder(root, args.project)))
            if errors:
                raise StudioError("\n".join(errors))
            value = {"校验": "通过"}
        elif args.command == "draft-kit":
            from drafting import kit

            value = kit(project_folder(root, args.project), args.workflow)
        elif args.command == "write-draft":
            from drafting import write

            value = write(project_folder(root, args.project), args.file, args.workflow)
        elif args.command == "auto-reroll":
            from auto_reroll import register

            value = register(project_folder(root, args.project), args.shots, args.reason)
        elif args.command == "ai-review":
            from ai_review import register

            value = register(project_folder(root, args.project), args.workflow, args.shot,
                             args.result, args.decision == "passed", args.reason)
        elif args.command == "compile":
            value = compile_project(project_folder(root, args.project), args.shots)
            value["说明"] = "仅本地编译，没有连接实例或提交生成。"
        elif args.command in ("run", "wait"):
            from runner import execute

            value = execute(
                project_folder(root, args.project),
                getattr(args, "defer_shutdown", False),
                getattr(args, "run_id", None),
            )
        elif args.command == "setup":
            import engine_bridge as bridge

            folder = project_folder(root, args.project)
            run = compile_project(folder, ready_only=True)
            if not run["jobs"]:
                # Without a ready shot the engine would fall back to its default model set.
                raise StudioError("还没有可准备的镜头：先在页面采用分镜草稿，再运行 setup。")
            models = {
                model["path"]: model
                for job in run["jobs"]
                for model in manifest(job["workflowId"])["models"]
            }
            graphs = [read_json(folder / job["graphPath"]) for job in run["jobs"]]
            with bridge.h3.lease():
                remote = bridge.StudioRemote()
                remote.sync()
                request = {"studio_models": list(models.values()), "studio_graphs": graphs,
                           "studio_nodes": ["comfyui-minimax-h3-audio-T8"]
                           if any(job["workflowId"] == "h3-hybrid" for job in run["jobs"]) else []}
                for key, given in (("data_dir", args.data_dir), ("python", args.python),
                                   ("reserve_vram_gb", args.reserve_vram)):
                    if given:
                        request[key] = given
                value = remote.task("install", request)
        elif args.command == "engine":
            import engine_bridge as bridge

            return bridge.h3.main(args.arguments)
        elif args.command == "update":
            from updater import update

            value = update(
                root, apply=args.apply, channel=args.channel, allowed_signers=args.allowed_signers
            )
            if value is None:
                return 0  # Unavailable channel is deliberately quiet.
        elif args.command == "open":
            from opener import open_editor
            from updater import trusted_manifest

            value = open_editor(
                trusted_manifest().get("editor_url"), args.project, args.print_target
            )
        else:
            raise StudioError("未知命令。")
        print(json.dumps(value, ensure_ascii=False, indent=2, default=str))
        return 0
    except (StudioError, OSError, ValueError, KeyError) as error:
        print("未完成：" + str(error), file=sys.stderr)
        return 1
    except Exception as error:
        # Includes sanitized errors from the original engine. Never print raw transport logs.
        print(
            "未完成："
            + (
                str(error)
                if type(error).__name__ == "H3Error"
                else "请检查项目或安装包，详细信息可通过本地自检定位。"
            ),
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
    raise SystemExit(main())
