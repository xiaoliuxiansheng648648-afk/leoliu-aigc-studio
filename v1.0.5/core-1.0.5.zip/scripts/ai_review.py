"""Explicit assistant review of a verified hybrid take, with bounded reroll fallback.

The assistant watches the downloaded video before recording this decision. Runtime
gates consume this ledger without writing page approvals or manual selections.
"""
import copy
from pathlib import Path
from studio_common import StudioError, load_project, read_json, write_json, safe_relative, digest, now
from workflow_tools import shot_hash
from auto_reroll import switch, chain, entries
from schema_check import document_errors

FILE = "ai-reviews.json"


def enabled(project, workflow_id):
    return workflow_id == "h3-hybrid" and switch(project, workflow_id)[0]


def records(folder):
    document = read_json(Path(folder) / FILE, {"schemaVersion": 1, "items": []})
    errors = document_errors("aiReviews", document)
    if errors:
        raise StudioError("AI 审核记录格式不正确：\n" + "\n".join(errors))
    return document


def accepted(project, workflow_id, shot):
    if not enabled(project, workflow_id) or shot["status"] != "approved":
        return None
    results = [r for r in project["results"]["items"]
               if r["workflowId"] == workflow_id and r["shotId"] == shot["id"]]
    latest = results[-1] if results else None
    if not latest or latest["status"] != "complete":
        return None
    manual = project["review"]["workflows"].get(workflow_id, {}).get("items", [])
    if any(r["resultId"] == latest["id"] and r["decision"] == "reroll" for r in manual):
        return None
    from sequential_review import history

    job = history(project["path"]).get((workflow_id, shot["id"]))
    if (not job or job["status"] != "complete" or job["shotSha256"] != shot_hash(shot)
            or latest["runId"] != job["runId"] or not latest["id"].startswith(job["id"] + "-")):
        return None
    return next((r for r in reversed(records(project["path"])["items"])
                 if r["workflowId"] == workflow_id and r["shotId"] == shot["id"]
                 and r["resultId"] == latest["id"] and r["videoSha256"] == latest.get("sha256")
                 and r["shotSha256"] == shot_hash(shot)), None)


def apply_frames(project):
    """Resolve only approved, declared previous-shot links against current reviewed outputs."""
    workflow_id = "h3-hybrid"
    if not enabled(project, workflow_id):
        return project
    result = copy.deepcopy(project)
    shots = sorted(result["storyboard"]["workflows"].get(workflow_id, {}).get("shots", []), key=lambda s: s["order"])
    for index, shot in enumerate(shots):
        frame = shot.get("firstFrame")
        if not frame or not index or shot["status"] != "approved" or frame["shotId"] != shots[index - 1]["id"]:
            continue
        review = accepted(result, workflow_id, shots[index - 1])
        asset = next((a for a in result["assets"]["items"] if review
                      and a.get("sourceFrame", {}).get("resultId") == review["resultId"]
                      and a["sourceFrame"]["videoSha256"] == review["videoSha256"]), None)
        if asset:
            shot["firstFrame"] = dict(frame, resultId=review["resultId"], videoSha256=review["videoSha256"],
                                      assetId=asset["id"], fileId=asset["files"][0]["id"])
    return result


def register(folder, workflow_id, shot_id, result_id, satisfied, reason):
    """Record pass, or use the last completed take only after all authorized rerolls ran."""
    import engine_bridge as bridge

    with bridge.h3.lease():
        from auto_reroll import effective
        from sequential_review import history
        from hybrid import dependency_issue, extract_frame

        folder = Path(folder)
        if not reason.strip():
            raise StudioError("请记录实际审片结论与问题。")
        page = load_project(folder)
        if not enabled(page, workflow_id):
            raise StudioError("请先在首帧＋多参考的剧情设置中打开“授权 AI 自动重抽”。")
        if list(folder.glob("runs/*/RUNNING")):
            raise StudioError("当前任务尚未结束，请先用 wait 恢复。")
        project = effective(page, folder)
        shot = next((s for s in project["storyboard"]["workflows"][workflow_id]["shots"] if s["id"] == shot_id), None)
        if not shot or shot["status"] != "approved":
            raise StudioError("请先在页面通过这一镜的分镜。")
        issue = dependency_issue(project, workflow_id, shot)
        if issue:
            raise StudioError(issue)
        job = history(folder).get((workflow_id, shot_id))
        results = [r for r in project["results"]["items"] if r["workflowId"] == workflow_id and r["shotId"] == shot_id]
        result = results[-1] if results else None
        if (not job or job["status"] != "complete" or job["shotSha256"] != shot_hash(shot)
                or not result or result["id"] != result_id or result["status"] != "complete"
                or result["runId"] != job["runId"] or not result_id.startswith(job["id"] + "-")):
            raise StudioError("只能审核当前分镜的最新已完成版本，请核对结果后重试。")
        page_shot = next(s for s in page["storyboard"]["workflows"][workflow_id]["shots"] if s["id"] == shot_id)
        used = len(chain(entries(folder)["items"], workflow_id, page_shot))
        limit = switch(page, workflow_id)[1]
        if not satisfied and used < limit:
            raise StudioError(f"仍可自动重抽 {limit - used} 次，请先修订提示词并登记 auto-reroll。")
        video = safe_relative(folder, result["path"])
        if not video.is_file() or digest(video) != result.get("sha256"):
            raise StudioError("视频文件缺失或散列不一致，未记录 AI 审核。")
        extract_frame(folder, result, shot_id, workflow_id, page_shot)
        record = {
            "workflowId": workflow_id, "shotId": shot_id, "resultId": result_id,
            "videoSha256": result["sha256"], "shotSha256": shot_hash(shot),
            "baseShotSha256": shot_hash(page_shot),
            "pageShot": page_shot, "decision": "passed" if satisfied else "exhausted",
            "reason": reason.strip(), "updatedAt": now(),
        }
        document = records(folder)
        document["items"] = [r for r in document["items"] if r["resultId"] != result_id] + [record]
        errors = document_errors("aiReviews", document)
        if errors:
            raise StudioError("\n".join(errors))
        write_json(folder / FILE, document)
        current = effective(load_project(folder), folder)
        complete = all(accepted(current, workflow_id, s) for s in current["storyboard"]["workflows"][workflow_id]["shots"])
        instruction = "全部镜头已审核完成，请提醒用户在对话里说“关机”。" if complete else "运行 run 继续下一镜，程序自动使用这一版的末帧。"
        return {"AI 审核": record, "下一步": instruction}
