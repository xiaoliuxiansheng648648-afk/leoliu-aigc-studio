# 多参考 · 自然：提示词写法

六段结构、绑定、主体令牌都照内置多参考：工作台安装目录 `workflows/h3-multiref/prompt-guide.md`。这里只写不一样的地方。

这个工作流在编译时自动加两样东西，提示词里不要写：

- 两个风格 LoRA：皮肤细节、电影质感，让人物更像真实相机拍的；
- 每个 `[Shot N] ` 后面的触发词。

每镜种子也是自动算的：同一镜头固定，镜头之间不一样，避免几镜构图一模一样。

## 1. 只有台词写中文

六段里只有 `<d>[Chinese] …</d>` 里面写中文，其余全写英文，景别、表情、动作这些导演要求也一样。中文备注模型基本不照做，所以编译会直接拦下：<d> 外面出现中文，就停止编译。页面上的中文摘要和台词放在镜头的 `summary`、`dialogue` 字段，不放进 `prompt`。

## 2. 画风：真实相机，不写 AI 短剧

照下面写，光那句按场景换：

```text
Photorealistic, like a real frame from a casual talking-to-camera video filmed with a good camera in a real room: natural unretouched skin with only subtle fine texture, no beauty filter, no skin smoothing, no glow, bloom or haze. {光} Natural muted colour with soft, low contrast and warm neutral tones; moderate depth of field so the background stays soft but readable. Not an AI drama still, not a glossy portrait, not an influencer ad photo, not anime, not 3D; no heavy grain or sharpening.
```

光要有来源，也要有方向，脸一侧亮、一侧有自然阴影，不打正面平光。例如晚上：

```text
The only light comes from warm lamps in the room and the cool dusk in the window: warm soft light falls on her face from the side with a gentle natural shadow on the other cheek, and the room behind her sinks into warm dimness.
```

不接美颜质感的场景图。房间和光用文字写。

## 3. 每镜第一句写景别和机位，相邻两镜不一样

`[Shot 1] ` 后面第一句只写景别和机位。相邻两镜第一句一样，编译会拦下。可选的写法：

- 近景，给反应句：`A close-up from the chest up, camera slightly to her left, eye level.`
- 中景，手势看得见：`A medium-wide shot from the waist up with the desk and both hands visible, camera straight on, eye level.`
- 侧一点的中景：`A medium shot from the mid-torso up, camera about thirty degrees to her right, eye level.`

一组镜头里景别要换着来，同一个景别不要连着用。

## 4. 表情跟着台词的情绪走

每个时间点写具体的脸部动作，不要默认带笑，结尾也不要统一写 `keeps a smile`。

| 台词             | 写法举例                                                                      |
| ---------------- | ----------------------------------------------------------------------------- |
| 担心、疑惑的问句 | brows knit, head tilts, one corner of the mouth pulls down                    |
| 抱怨、累         | a small sigh, shoulders drop, lips press together, eyes glance down then back |
| 惊讶、发现       | eyebrows rise, eyes widen, lips part                                          |
| 得意、收尾       | a quick genuine smile, a small nod                                            |

一镜里表情至少变一次。想要更有感染力，就每句台词配一个看得清的表情加一个手势，可以做得夸张一点。

## 5. 手要看得见

- 手势写在桌面以上，可以抬到脸旁（挥手、托腮、比心、比数字）；不碰胸口和领口。
- 用到电脑时，把它斜放在桌子一侧，开口朝人物，只露侧面，不要摆在画面下方正中挡手。
- 用不到电脑的镜头，就不放电脑。
- 写动作只写一个主要动作，“合上一半电脑”这种细活模型常常做不出来。

## 6. 8 步加速

页面上勾选“8 步加速”后，这个工作流同样能用，两个风格 LoRA 照常接在加速前面，写法不用改。加速后皮肤细节可能比 24 步少一些，定稿镜头建议关掉加速再出一版。
