"""多参考 · 自然：内置多参考图，加皮肤细节和电影质感两个风格 LoRA，每镜加触发词、各用不同种子。"""

import hashlib
import re
from pathlib import Path
import workflow_tools
from studio_common import StudioError, read_json

FOLDER = Path(__file__).resolve().parent
# Han, CJK punctuation and full-width forms; dialogue inside <d>…</d> is the only Chinese H3 should read.
CJK = re.compile(r"[\u3000-\u303f\u3400-\u4dbf\u4e00-\u9fff\uff00-\uffef]")


def chinese_sections(prompt):
    return [
        key
        for key, text in prompt.items()
        if CJK.search(re.sub(r"<d>.*?</d>", "", text, flags=re.S))
    ]


def framing(shot):
    # The first sentence of [Shot 1] carries the shot size and camera angle (prompt-guide.md).
    text = re.sub(r"^\[Shot 1\] ", "", shot["prompt"]["detailed_description"])
    return re.split(r"(?<=\.)\s", text, maxsplit=1)[0].strip()


def repeated_framing(shots):
    ordered = sorted(shots, key=lambda shot: shot["order"])
    return [(a["id"], b["id"]) for a, b in zip(ordered, ordered[1:]) if framing(a) == framing(b)]


def shot_seed(shot_id):
    # Stable per shot, different between shots: one seed for every shot repeated the same composition.
    return int(hashlib.sha256(shot_id.encode("utf-8")).hexdigest()[:8], 16) % 2**31


def plan(project):
    tasks = workflow_tools.plan(project, FOLDER)
    pairs = repeated_framing([task["shot"] for task in tasks])
    if pairs:
        raise StudioError(
            "相邻两镜第一句景别写得一样，请换景别或机位："
            + "、".join(a + "/" + b for a, b in pairs)
        )
    return tasks


def compile(job):
    sections = chinese_sections(job["shot"]["prompt"])
    if sections:
        raise StudioError(
            job["shot"]["id"]
            + " 的提示词在 <d> 以外有中文（"
            + "、".join(sections)
            + "），导演要求请改成英文写进 detailed_description。"
        )
    detailed = job["shot"]["prompt"]["detailed_description"]
    markers = list(re.finditer(r"\[Shot\s+\d+\]", detailed))
    if not detailed.startswith("[Shot 1] ") or any(
        not re.match(r"\[Shot [1-9]\d*\] ", detailed[m.start() :]) for m in markers
    ):
        raise StudioError("提示词镜头结构不是 [Shot N] 加空格，停止编译。")
    config = read_json(FOLDER / "config.json")
    compiled = workflow_tools.compile_h3(job, FOLDER, reference=True, loras=config["loras"])
    prompt = re.sub(
        r"(\[Shot [1-9]\d*\] )", lambda m: m[1] + config["trigger"], compiled["prompt"]
    )
    compiled["graph"]["10"]["inputs"]["noise_seed"] = shot_seed(job["shot"]["id"])
    compiled["graph"]["9"]["inputs"]["prompt"] = prompt
    compiled["prompt"] = prompt
    return compiled


def collect(job, outputs):
    return workflow_tools.collect(job, outputs)
