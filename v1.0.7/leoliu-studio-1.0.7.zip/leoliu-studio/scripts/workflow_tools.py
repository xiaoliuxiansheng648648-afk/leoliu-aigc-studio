"""Shared graph mechanics. Plugins choose their own templates and modes."""

import copy
import hashlib
import json
from pathlib import Path
from studio_common import StudioError, read_json, manifest, safe_relative
from validation import compile_prompt


def shot_hash(shot):
    content = {key: value for key, value in shot.items() if key != "status"}
    return hashlib.sha256(
        json.dumps(content, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def plan(project, folder):
    workflow = read_json(Path(folder) / "manifest.json")
    workflow_id = workflow["id"]
    board = project["storyboard"]["workflows"].get(workflow_id, {"shots": []})
    return [
        {
            "shot": copy.deepcopy(shot),
            "workflow": workflow,
            "assets": copy.deepcopy(project["assets"]["items"]),
            "settings": project["brief"]["workflows"]
            .get(workflow_id, {})
            .get("settings", workflow["defaults"]),
            "projectPath": str(project["path"]),
        }
        for shot in board["shots"]
    ]


def turbo_enabled(job):
    """The page's 8-step switch. Only workflows whose manifest declares `turbo` accept it."""
    if not job["settings"].get("turbo"):
        return False
    if not job["workflow"].get("turbo"):
        raise StudioError(job["workflow"]["name"] + " 暂不支持 8 步加速，请在页面取消勾选。")
    return True


def job_models(job):
    """Models a compiled job needs on the instance; the turbo LoRA only when that job was compiled with it."""
    workflow = manifest(job["workflowId"])
    models = list(workflow["models"])
    if job.get("turbo"):
        models.append(workflow["turbo"]["model"])
    return models


def chain_model(graph, loras=(), turbo=None):
    """UNET → style LoRAs → turbo LoRA → sigma shift; guider and scheduler read the end of the chain."""
    if graph["1"]["class_type"] != "UNETLoader" or any(
        graph[key]["inputs"]["model"] != ["1", 0] for key in ("11", "13")
    ):
        raise StudioError("内置工作流模型接线已变化，停止编译。")
    previous = "1"
    next_id = max(50, max(map(int, graph)) + 1)
    rows = [(row["name"], row["strength"]) for row in loras]
    if turbo:
        rows.append((Path(turbo["model"]["path"]).name, turbo["strength"]))
    for name, strength in rows:
        node = str(next_id)
        graph[node] = dict(
            class_type="LoraLoaderModelOnly",
            inputs=dict(model=[previous, 0], lora_name=name, strength_model=strength),
        )
        previous = node
        next_id += 1
    if turbo:
        node = str(next_id)
        graph[node] = dict(
            class_type="MiniMaxH3SigmaShift",
            inputs=dict(
                model=[previous, 0],
                shift_video=turbo["shiftVideo"],
                shift_audio=turbo["shiftAudio"],
            ),
        )
        previous = node
        graph["12"]["inputs"]["sampler_name"] = turbo["sampler"]
        graph["13"]["inputs"]["steps"] = turbo["steps"]
    for key in ("11", "13"):
        graph[key]["inputs"]["model"] = [previous, 0]
    return graph


def compile_h3(job, folder, reference=False, loras=()):
    folder = Path(folder)
    workflow = read_json(folder / "manifest.json")
    assets = {asset["id"]: asset for asset in job["assets"]}
    shot = job["shot"]
    prompt, tables = compile_prompt(shot, assets, workflow)
    graph_name = (
        "graph.api.json" if reference else ("i2v.api.json" if shot["bindings"] else "t2v.api.json")
    )
    graph = read_json(folder / graph_name)
    defaults = workflow["defaults"]
    width, height = defaults["width"], defaults["height"]
    if job["settings"]["orientation"] == "portrait":
        width, height = height, width
    frames = int(shot["durationSeconds"] * defaults["fps"])
    length = (
        defaults["length"]
        if shot["durationSeconds"] == defaults["secondsPerShot"]
        else frames + (5 - frames % 17) % 17
    )
    graph["9"]["inputs"].update(prompt=prompt, width=width, height=height, length=length)
    graph["10"]["inputs"]["noise_seed"] = defaults["seed"]
    graph["12"]["inputs"]["sampler_name"] = defaults["sampler"]
    graph["13"]["inputs"].update(steps=defaults["steps"], scheduler=defaults["scheduler"])
    graph["17"]["inputs"]["fps"] = defaults["fps"]
    if reference:
        graph["9"]["inputs"]["ref_image_size"] = defaults["refImageSize"]
    graph["18"]["inputs"]["filename_prefix"] = "leoliu-studio/" + job.get("id", shot["id"])
    uploads = []
    for binding in shot["bindings"]:
        aid = binding["assetId"]
        asset = assets[aid]
        file = next(file for file in asset["files"] if file["id"] == binding["fileId"])
        kind = "audio" if asset["category"] == "voice" else "picture"
        order = tables[kind][aid] - 1
        node_id = str(40 + order) if kind == "audio" else str(8 if order == 0 else 18 + order)
        remote_name = file["sha256"] + Path(file["path"]).suffix.lower()
        graph[node_id] = {
            "class_type": "LoadAudio" if kind == "audio" else "LoadImage",
            "inputs": {"audio" if kind == "audio" else "image": remote_name},
        }
        if workflow["id"] == "h3-hybrid" and binding["purpose"] == "first_frame":
            graph["9"]["inputs"]["first_frame"] = [node_id, 0]
        elif reference:
            slot = order - (1 if workflow["id"] == "h3-hybrid" and kind == "picture" else 0)
            graph["9"]["inputs"][
                ("ref_audios.ref_audio_" if kind == "audio" else "ref_images.ref_image_")
                + str(slot)
            ] = [node_id, 0]
        else:
            graph["9"]["inputs"]["first_frame"] = [node_id, 0]
        safe_relative(job["projectPath"], file["path"])
        uploads.append(
            {
                "assetId": aid,
                "fileId": file["id"],
                "path": file["path"],
                "sha256": file["sha256"],
                "size": file["size"],
                "remoteName": remote_name,
                "nodeId": node_id,
                "mediaType": kind,
            }
        )
    turbo = job["workflow"]["turbo"] if turbo_enabled(job) else None
    if loras or turbo:
        chain_model(graph, loras, turbo)
    return {
        "graph": graph,
        "prompt": prompt,
        "uploads": uploads,
        "tables": tables,
        "turbo": bool(turbo),
    }


def collect(job, outputs):
    return [
        dict(output, shotId=job["shotId"], workflowId=job["workflowId"], runId=job["runId"])
        for output in outputs
    ]
