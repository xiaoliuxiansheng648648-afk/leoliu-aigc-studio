# 字体许可来源

- Noto Sans SC：原字库随附 OFL.txt，保留原版权及完整 OFL 1.1。
- Inter：rsms/inter 的 LICENSE.txt；OFL 1.1 正文相同，版权行为 Inter Project Authors。
- JetBrains Mono：JetBrains/JetBrainsMono 的 OFL.txt；OFL 1.1 正文相同，版权行为 JetBrains Mono Project Authors。

三份版权行均已与内嵌 WOFF/WOFF2 的 name 表核对；OFL 1.1 正文来自原字库随附许可。
三份许可用于页面内嵌字库，不受工作台专有许可覆盖。
