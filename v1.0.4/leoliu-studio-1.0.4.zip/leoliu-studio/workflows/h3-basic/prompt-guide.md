# 文生 / 首帧分镜与提示词

先读 manifest.json。没有图是文生；一张图且用途 first_frame 是首帧；不支持声音参考或尾帧。
出现人物/场景/道具多张参考时，切到多参考工作流，不把它们偷偷塞进首帧模式。
当前执行器每镜 5 / 10 / 15 秒，沿用原 h3-cloud t2v / i2v API 图。

助手只写 storyboard.draft.json，draftRevision 递增，镜头状态 draft。
提示词 prompt 是三个非空字符串的对象：

```json
{
  "integrated_multimodal_description": "[Shot 1] Start from {{picture:frameId}}. Describe the visible starting pose, one clear action, camera and ending state.",
  "overall_soundscape": "Quiet room tone. She asks softly: <d>[Chinese] 准备好了吗？</d> She closes her lips.",
  "non_diegetic_music": "N/A"
}
```

有首帧时，用真实 assetId/fileId 建一条 binding，purpose=first_frame，在画面段通过 `{{picture:id}}` 引用它。
文生没有 binding，也不能留下任何素材令牌；删除上例里首帧引用并按用户意图描述画面。
此工作流不用 subject_definitions 或 Subject 令牌。图片不改，原图上传后由编译器接到 first_frame。

摘要写中文，dialogue 与 `<d>[Chinese] ...</d>` 逐字一致；无台词则 dialogue 为空且不写对白块。
表演按动作原因组织：先看见/听见，再反应，再说话；发声方式放对白前，收嘴放对白后，停顿交代静默口型。
台词超过本镜自然发声时间时，先提出拆镜或改时长，不静默删改用户锁定的台词。

不要写采样器、节点或模型术语给零基础用户；这些只放高级字段和编译结果。
