from pathlib import Path
import workflow_tools

FOLDER = Path(__file__).resolve().parent


def plan(project):
    return workflow_tools.plan(project, FOLDER)


def compile(job):
    return workflow_tools.compile_h3(job, FOLDER, reference=True)


def collect(job, outputs):
    return workflow_tools.collect(job, outputs)
