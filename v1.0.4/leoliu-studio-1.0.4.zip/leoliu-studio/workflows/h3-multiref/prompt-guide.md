# 多参考分镜与提示词

先读同目录 manifest.json。每镜最多 9 张图、3 段声音；声音每段 2–15 秒、合计不超过 15 秒。
当前执行器每镜选择 5 / 10 / 15 秒。默认 1344×768、124 帧、24 步、res_multistep、simple、seed 42、ref_image_size=match。
竖屏对调宽高；5 秒默认 124 帧，其他时长遵循同一 17n+5 对齐规则。不要自行改模型、采样或散列。

助手只写 storyboard.draft.json，draftRevision 递增。每镜 status=draft，摘要和台词用中文。
一个素材在一镜里只接一个 fileId；绑定顺序同时决定图片/声音接线编号。图和声音分别编号。

## 六段整体提交

prompt 为含六个非空字符串的对象，固定键：
subject_definitions、summary、retention_analysis、detailed_description、overall_soundscape、non_diegetic_music。

```text
subject_definitions: {{subject:personId}} is the young woman in {{picture:personId}}.
{{picture:sceneId}} defines only the room layout and lighting.
{{audio:voiceId}} provides only the speaking voice timbre.
summary: The woman notices the screen and asks a short question.
retention_analysis: {{subject:personId}} (appears in [Shot 1]): fully_preserved - face and outfit.
{{picture:sceneId}} (appears in [Shot 1]): partially_preserved - desk layout and dusk light.
{{audio:voiceId}} (appears in [Shot 1]): reference - timbre only, never its recorded words.
detailed_description: [Shot 1] She sits at the desk, looks at the screen, leans in slightly and speaks.
Her lips remain closed during the opening pause. After speaking she waits quietly. No captions or added text.
overall_soundscape: Quiet room. {{subject:personId}} speaks softly with the timbre of {{audio:voiceId}}:
<d>[Chinese] 你早就知道？</d> She closes her lips.
non_diegetic_music: N/A
```

上面是结构示意，须换成项目真实 ID、实际素材内容和用户原文，不能原样塞入未知 ID。
Subject 按 subject_definitions 首次定义排序；同一行必须把这个 Subject 绑定到同 ID 的 Picture。
正文使用稳定主体令牌，不写 `<Subject 1>` / `<Picture 1>` / `<Audio 1>`，也不写旧 `{{asset:id}}`。
每个接线素材在 subject_definitions 说明用途；未接线引用和未定义接线都会被编译器拒绝。

## 每张图只负责一件事

人物图管身份，道具图管外形，场景图管空间，开场构图图管起始姿态。
把允许变化和必须保留的部分写入 retention_analysis：角色图不能顺带决定机位，场景图不能改变人物脸。
只带本镜真正需要的输入；不要为凑多模态而塞满上限。

多参考和首帧输入互斥。若首帧与其他参考同时存在，整组转为多参考，把首帧用途改为身份/场景/道具中贴合的一项，
并在说明里明确它仅控制起始构图。不要给多参考节点再接 first_frame。
只有一张首帧、没有其他参考时使用文生 / 首帧工作流。

## 音色与台词

声音文件只提供音色，不能包含本镜准备说的台词。台词栏与 `<d>[Chinese] 原定台词</d>` 逐字一致。
先写表情、视线和发声方式，再写对白；对白后紧接收嘴句。停顿明确静默口型，不在对白旁堆口语命令。
每句台词只出现一次，不加翻译、额外开场词、字幕或未授权角色。
先算准备、动作、发声、停顿、收尾时间；作者经验语速不是模型保证，不能把 15 秒能说多少字写成硬承诺。

坏头 WAV 的显示用浏览器解码；上传前原引擎扩展用 ffmpeg 转 32 kHz 立体声 WAV。
没有 ffmpeg 时会警告并保留原件上传；不能声称已完成音频规范化。
