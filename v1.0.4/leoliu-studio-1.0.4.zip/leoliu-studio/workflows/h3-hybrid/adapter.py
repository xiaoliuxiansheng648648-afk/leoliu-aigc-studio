from pathlib import Path
import workflow_tools
import hybrid

FOLDER = Path(__file__).resolve().parent


def plan(project):
    return workflow_tools.plan(project, FOLDER)


def compile(job):
    return workflow_tools.compile_h3(hybrid.resolve_job(job), FOLDER, reference=True)


def prepare(remote):
    remote.task("studio-nodes", {"folders": ["comfyui-minimax-h3-audio-T8"]})


def collect(job, outputs):
    for output in outputs:
        hybrid.extract_frame(job["projectPath"], output, job["shotId"], job["workflowId"], job.get("shotSnapshot"))
    return workflow_tools.collect(job, outputs)
