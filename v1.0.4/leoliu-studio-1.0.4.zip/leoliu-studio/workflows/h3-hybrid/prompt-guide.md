# 首帧＋多参考分镜与提示词

首帧决定开场构图和起始姿势，参考图管人物身份、场景或道具，声音参考管音色。
镜头可能会慢推或重新构图，按短剧的正常运镜看待。下一镜从上一镜实际末帧接，构图跟着走。
动作从首帧里的姿势继续向下写。人物参考图的背景要干净，背景会被带进画面。
实测中女主全身图背景的走廊进入了生成画面，不能只看脸就使用复杂背景的人物图。

每镜必须有一张首帧，另接最多 9 张参考图、3 段声音。声音每段 2–15 秒，合计不超过 15 秒。
至少要有一项图片或声音参考。首帧与参考图必须是不同文件，复制一份相同图片也不行。
时长只能选择 5、10、15 秒。默认尺寸、采样器、步数、种子、帧数对齐沿用多参考模式。

稳定节点默认强度为 0.999，不提供强弱选项。参考图强度不要往低调，0.6 和 0.3 都测过，没有明显好处。

## 首帧来源

素材首帧用 bindings 中 purpose=first_frame 指定图片，其他图片用 identity / scene / prop，声音用 voice。
编译器先接首帧，随后按绑定列表里的参考图顺序接线。首帧恒为 Picture 1，参考图从 Picture 2 开始。
Audio 单独从 1 编号。删掉或重排输入，编译器会重排编号，不允许手写编号。

上一镜末帧由页面“首帧来源”选择。上一镜完成、下载校验并选用当前版本后，点击“更新为选用版末帧”。
引擎完整解码下载的视频，保存最后一个完整帧为素材，记录来源视频 SHA-256、从 0 开始的帧号、PTS 和 time base。
引擎把新末帧写进 frame-assets.json，页面自动纳入素材库并保存到 assets.json，避免下载期间覆盖用户的素材编辑。
不根据视频时长 seek。更新末帧会撤回本镜通过状态，用户需要重新通过。
上一镜重抽，包括授权 AI 自动重抽，或上游接戏链改变，下游旧末帧会过期，旧片和旧末帧保留。
接戏镜头按顺序生成，当前版必须由用户选用，才能更新下一镜的末帧。此模式保持逐镜审核和手动关机规则。

助手写草稿时可以先写 `firstFrame: {"source":"previous","shotId":"上一镜ID"}`。
未生成的末帧不填虚构文件。提示词中使用保留令牌 `{{picture:previous-frame}}`。
待页面更新末帧并重新通过后，编译器才会允许提交。离线检查未就绪的链时，用 `compile --dry-run --shots 镜头ID` 编译已就绪镜头。
助手只写 storyboard.draft.json，页面采用与通过由用户负责。

## 六段整体提交

六段必须非空，固定键与多参考一致。以下用素材首帧，ID 要替换为项目真实 ID。

```text
subject_definitions: {{picture:opening}} defines the exact opening composition and pose.
{{subject:woman}} is the young woman in {{picture:woman}}. This clean-background image defines identity only.
{{audio:voice}} provides only her speaking timbre, never its recorded words.
summary: She lifts her gaze from the opening pose and speaks.
retention_analysis: {{picture:opening}} sets the opening pose and light.
{{subject:woman}} (appears in [Shot 1]): fully_preserved - face and outfit.
{{audio:voice}} (appears in [Shot 1]): reference - voice timbre only.
detailed_description: [Shot 1] Starting from the opening pose, she lifts her gaze and speaks softly.
After speaking she closes her lips and holds the books still. No captions or extra people.
overall_soundscape: Quiet corridor. {{subject:woman}} speaks with the timbre of {{audio:voice}}:
<d>[Chinese] 你先别说。</d> She closes her lips.
non_diegetic_music: N/A
```

上一镜末帧把示例中的 `{{picture:opening}}` 换成 `{{picture:previous-frame}}`。
每个接线素材要在 subject_definitions 说明用途，Subject 同行绑定同 ID 的 Picture。
台词栏与 `<d>[Chinese] 原文</d>` 逐字一致，只出现一次，说完接收嘴句。
其余提示词原则沿用 h3-multiref/prompt-guide.md 的六段、台词和音频规范，混合模式允许首帧和参考同时存在。
