# LeoLiu Studio

© 2026 LeoLiu（微信 LeoLiu_AI），仅限个人非商业使用，非开源；详见 LICENSE。

安装包将本目录、两个 workflows、contract/schemas 和单文件 editor 合并为 `leoliu-studio/`。
只用 Python 3.9+ 标准库和系统 OpenSSH；可选 ffmpeg 用于音频规范化。

入口：`python scripts/studio.py --help`。完整助手流程见 SKILL.md。
本地开发时 editor 位于仓库 dist；安装后位于包内 editor/index.html。

发行状态见 release-status.json：只有正式公钥与签名配置完成后才能作为签名更新发行。
1.0.0 未配置通道的用户需要重新下载并安装一次正式 1.0.1；原项目目录无需迁移。
第三方软件和字体依其原许可提供，详见 THIRD_PARTY_NOTICES.md。

逐镜审核（默认关闭）：在剧情设置打开后，每次只生成一镜；用户选用当前最新一版，再在对话说“继续”。
此模式不自动关机，GPU 等待审核仍计费；完成或暂时不用时请在对话说“关机”。

优化反馈：点击顶栏反馈入口，填写一段文字后提交。只有主动提交才向 LeoLiu 服务器发送文字及工作台版本，不上传项目文件。
