import re
from studio_common import StudioError, manifest, safe_relative, digest
from schema_check import document_errors

TOKEN = re.compile(r"\{\{(subject|picture|audio):([A-Za-z0-9][A-Za-z0-9_-]*)\}\}")


def binding_errors(shot, assets, workflow):
    errors = []
    hybrid = "hybrid" in workflow["modes"]
    bound = []
    for binding in shot["bindings"]:
        asset = assets.get(binding["assetId"])
        file = (
            next((f for f in asset["files"] if f["id"] == binding["fileId"]), None)
            if asset
            else None
        )
        if not file:
            errors.append("参考素材或文件已缺失，请重新绑定。")
            continue
        if asset["category"] not in workflow["assetCategories"]:
            errors.append("本工作流不支持该素材类别，请移除绑定。")
        bound.append((binding, asset, file))
    if shot.get("firstFrame") and not hybrid:
        errors.append("上一镜末帧仅用于首帧＋多参考模式。")
    if shot.get("firstFrame") and any(b["assetId"] == "previous-frame" for b in shot["bindings"]):
        errors.append("previous-frame 是末帧保留令牌，请为参考素材更换 ID。")
    if len({b["assetId"] for b in shot["bindings"]}) != len(shot["bindings"]):
        errors.append("一个素材在同一镜头只能绑定一次，请移除重复项。")
    audio = [row for row in bound if row[1]["category"] == "voice"]
    images = [row for row in bound if row[1]["category"] != "voice"
              and (not hybrid or row[0]["purpose"] != "first_frame")]
    limits = workflow["limits"]
    if len(images) > limits["images"]:
        errors.append(f"参考图最多 {limits['images']} 张，请移除多余图片。")
    if len(audio) > limits["audios"]:
        errors.append(f"参考音频最多 {limits['audios']} 段，请移除多余声音。")
    total = 0
    for _, asset, file in audio:
        duration = file.get("durationSeconds", 0)
        total += duration
        if duration < limits.get("audioMinSeconds", 0) or duration > limits.get(
            "audioMaxSeconds", float("inf")
        ):
            errors.append(
                f"@{asset['name']} 音频应为 {limits.get('audioMinSeconds')}–{limits.get('audioMaxSeconds')} 秒，请裁剪或更换。"
            )
    if total > limits.get("audioTotalSeconds", float("inf")):
        errors.append(f"音频合计不能超过 {limits['audioTotalSeconds']} 秒，请缩短音频。")
    frame = any(b["purpose"] in ("first_frame", "last_frame") for b in shot["bindings"])
    if hybrid:
        frames = [row for row in bound if row[0]["purpose"] == "first_frame"]
        previous = shot.get("firstFrame")
        if len(frames) + bool(previous) != 1:
            errors.append("必须且只能指定一个首帧，不能退回纯多参考。")
        if frames and frames[0][1]["category"] == "voice":
            errors.append("首帧必须是图片。")
        if frames and any(row[2]["sha256"] == frames[0][2]["sha256"] for row in bound if row not in frames):
            errors.append("首帧和参考图不能使用同一个文件。")
        refs = [row for row in bound if row[0]["purpose"] != "first_frame"]
        if not refs:
            errors.append("首帧＋多参考至少需要一个图片或声音参考。")
    if frame and not hybrid and (len(bound) > 1 or "reference" in workflow["modes"]):
        errors.append("首帧和参考不能混用，请改成参考用途并使用多参考工作流。")
    if "first_frame" in workflow["modes"] and bound and not frame:
        errors.append("文生 / 首帧工作流只能绑定一张首帧，请修改用途或切到多参考。")
    if "last_frame" in [b["purpose"] for b in shot["bindings"]]:
        errors.append("v1 尚不支持尾帧，请移除尾帧或改用参考用途。")
    if shot["durationSeconds"] not in limits.get("durations", [shot["durationSeconds"]]):
        errors.append("当前执行器时长可选 5、10、15 秒，请修改镜头时长。")
    return errors


def compile_prompt(shot, assets, workflow):
    sections = workflow["promptSections"]
    prompt = shot["prompt"]
    if set(prompt) != set(sections) or any(not prompt.get(key, "").strip() for key in sections):
        raise StudioError("提示词段落不完整，请按当前工作流指南补齐。")
    body = "\n".join(prompt[key] for key in sections)
    if re.search(r"<(?:Subject|Picture|Audio)\s+\d+>", body) or "{{asset:" in body:
        raise StudioError("请使用 subject / picture / audio 令牌，不要手写编号或旧 asset 令牌。")
    tables = {"picture": {}, "audio": {}, "subject": {}}
    bindings = shot["bindings"]
    if "hybrid" in workflow["modes"]:
        from hybrid import ordered_bindings, ALIAS

        bindings = ordered_bindings(shot)
        if shot.get("firstFrame"):
            tables["picture"][ALIAS] = 1
    for binding in bindings:
        aid = binding["assetId"]
        kind = "audio" if assets[aid]["category"] == "voice" else "picture"
        tables[kind][aid] = len(tables[kind]) + 1
    definitions = prompt.get("subject_definitions", "")
    subject_defs = list(re.finditer(r"\{\{subject:([A-Za-z0-9_-]+)\}\}", definitions))
    for index, match in enumerate(subject_defs):
        aid = match.group(1)
        end = subject_defs[index + 1].start() if index + 1 < len(subject_defs) else len(definitions)
        clause = definitions[match.end() : end].split("\n")[0]
        if aid not in tables["picture"] or "{{picture:" + aid + "}}" not in clause:
            raise StudioError("每个 Subject 必须在主体定义的同一行绑定对应 Picture：" + aid)
        if aid not in tables["subject"]:
            tables["subject"][aid] = len(tables["subject"]) + 1
    referenced = set()
    for match in TOKEN.finditer(body):
        kind, aid = match.groups()
        if aid not in tables[kind]:
            raise StudioError("正文引用了未接线、未定义或种类不符的素材：" + aid)
        if kind != "subject":
            referenced.add((kind, aid))
    for kind in ("picture", "audio"):
        for aid in tables[kind]:
            if (kind, aid) not in referenced:
                raise StudioError("素材已接线，但正文没有引用：" + aid)
            if (
                any(mode in workflow["modes"] for mode in ("reference", "hybrid"))
                and "{{" + kind + ":" + aid + "}}" not in definitions
            ):
                raise StudioError("素材已接线，但主体定义中没有说明其用途：" + aid)
    replaced = TOKEN.sub(lambda m: f"<{m[1].title()} {tables[m[1]][m[2]]}>", body)
    if "{{" in replaced or "}}" in replaced:
        raise StudioError("提示词含有未识别的素材令牌。")
    if "[Shot 1]" not in body:
        raise StudioError("画面提示词需要保留 [Shot 1]。")
    dialogue = "".join(re.findall(r"<d>\[Chinese\]\s*(.*?)</d>", body, re.S))
    if dialogue != shot["dialogue"]:
        raise StudioError("台词栏与提示词中的中文台词不一致，请让助手核对。")
    if body.count("<d>") != body.count("</d>"):
        raise StudioError("台词标签未闭合。")
    text = "\n".join(
        key + ": " + TOKEN.sub(lambda m: f"<{m[1].title()} {tables[m[1]][m[2]]}>", prompt[key])
        for key in sections
    )
    return text, tables


def validate_project(project, verify_files=True):
    errors = []
    for name in ("studio", "assets", "brief", "storyboard", "review", "results"):
        errors += document_errors(name, project[name])
    if errors:
        return errors
    assets = {a["id"]: a for a in project["assets"]["items"]}
    if len(assets) != len(project["assets"]["items"]):
        errors.append("素材 ID 重复，请为每个素材使用独立 ID。")
    if len({a["name"] for a in assets.values()}) != len(assets):
        errors.append("素材名字重复，请换一个 @ 名。")
    for brief in project["brief"]["workflows"].values():
        for aid in re.findall(r"@\[[^\]]*\]\(asset:([^)]*)\)", brief["text"]):
            if aid not in assets:
                errors.append("剧情引用的素材已缺失，请重新选择 @ 素材：" + aid)
    for asset in assets.values():
        if len({f["id"] for f in asset["files"]}) != len(asset["files"]):
            errors.append("素材文件 ID 重复。")
        for file in asset["files"]:
            try:
                path = safe_relative(project["path"], file["path"])
                if verify_files and (
                    not path.is_file()
                    or path.stat().st_size != file["size"]
                    or digest(path) != file["sha256"]
                ):
                    errors.append("原文件缺失或散列不一致：" + file["path"])
            except StudioError as error:
                errors.append(str(error))
    for workflow_id, board in project["storyboard"]["workflows"].items():
        workflow = manifest(workflow_id)
        if len({s["id"] for s in board["shots"]}) != len(board["shots"]):
            errors.append("镜头 ID 重复，请重新编号。")
        if "hybrid" in workflow["modes"]:
            ordered = sorted(board["shots"], key=lambda row: row["order"])
            if len({row["order"] for row in ordered}) != len(ordered):
                errors.append("接戏链的镜头顺序不能重复。")
            for index, shot in enumerate(ordered):
                if shot.get("firstFrame") and (index == 0 or shot["firstFrame"]["shotId"] != ordered[index - 1]["id"]):
                    errors.append(shot["id"] + "：末帧来源必须是分镜顺序中的上一镜。")
        for shot in board["shots"]:
            issues = binding_errors(shot, assets, workflow)
            if not issues:
                try:
                    compile_prompt(shot, assets, workflow)
                except StudioError as error:
                    issues.append(str(error))
            errors += [shot["id"] + "：" + issue for issue in issues]
    return errors
