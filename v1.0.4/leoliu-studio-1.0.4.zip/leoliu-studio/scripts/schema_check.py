"""The exact JSON Schema subset used by the bundled contract, with no runtime dependencies."""

import math
import re
from studio_common import read_json, SCHEMAS


def validate_schema(value, schema, document=None, path="$"):
    document = document or schema
    if "$ref" in schema:
        target = document
        reference = schema["$ref"].split("#", 1)[-1]
        for part in reference.strip("/").split("/"):
            target = target[part]
        return validate_schema(value, target, document, path)
    errors = []
    if "oneOf" in schema:
        choices = [validate_schema(value, option, document, path) for option in schema["oneOf"]]
        if sum(not choice for choice in choices) != 1:
            return [path + "：提示词段落不符合三段或六段格式，请按工作流指南重写。"]
    if "const" in schema and value != schema["const"]:
        errors.append(path + "：版本或固定值不兼容，请更新工作台。")
    if "enum" in schema and value not in schema["enum"]:
        errors.append(path + "：值不在允许范围内。")
    kind = schema.get("type")
    types = {
        "object": dict,
        "array": list,
        "string": str,
        "boolean": bool,
        "integer": int,
        "number": (int, float),
    }
    if kind and (
        not isinstance(value, types[kind])
        or kind in ("integer", "number")
        and isinstance(value, bool)
    ):
        return errors + [path + "：字段类型不正确。"]
    if kind in ("number", "integer"):
        if not math.isfinite(value):
            errors.append(path + "：数字必须有限。")
        if (
            "minimum" in schema
            and value < schema["minimum"]
            or "exclusiveMinimum" in schema
            and value <= schema["exclusiveMinimum"]
        ):
            errors.append(path + "：数字过小。")
    if kind == "string":
        if len(value) < schema.get("minLength", 0):
            errors.append(path + "：不能为空。")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            errors.append(path + "：格式或文件路径不合法。")
    if kind == "array":
        if len(value) < schema.get("minItems", 0):
            errors.append(path + "：请至少添加一个项目。")
        for index, item in enumerate(value):
            errors += validate_schema(item, schema.get("items", {}), document, f"{path}[{index}]")
    if kind == "object":
        for key in schema.get("required", []):
            if key not in value:
                errors.append(path + "：缺少字段 " + key)
        for key, item in value.items():
            properties = schema.get("properties", {})
            if key in properties:
                errors += validate_schema(item, properties[key], document, path + "." + key)
            elif schema.get("additionalProperties") is False:
                errors.append(path + "：不支持字段 " + key)
            elif isinstance(schema.get("additionalProperties"), dict):
                errors += validate_schema(
                    item, schema["additionalProperties"], document, path + "." + key
                )
    return errors


def document_errors(name, value):
    schema = read_json(SCHEMAS / "project.schema.json")
    return validate_schema(value, schema["$defs"][name], schema, name)
