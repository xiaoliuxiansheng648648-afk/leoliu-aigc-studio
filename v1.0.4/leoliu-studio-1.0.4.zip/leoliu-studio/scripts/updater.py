"""Signed, component-aware updates using the installation's public trust anchor."""

import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from studio_common import PACKAGE, VERSION, StudioError, read_json, write_json, digest
from update_swap import swap, selftest

NAMESPACE = "leoliu-studio-update"
IDENTITY = "leoliu-studio"


def verify(raw, signature, signers):
    if not Path(signers).is_file():
        raise StudioError("更新公钥未配置，保留当前版本。")
    with tempfile.TemporaryDirectory(prefix="studio-signature-") as temporary:
        path = Path(temporary) / "manifest.sig"
        path.write_bytes(signature)
        try:
            process = subprocess.run(
                [
                    "ssh-keygen",
                    "-Y",
                    "verify",
                    "-f",
                    str(signers),
                    "-I",
                    IDENTITY,
                    "-n",
                    NAMESPACE,
                    "-s",
                    str(path),
                ],
                input=raw,
                capture_output=True,
                timeout=3,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise StudioError("更新签名工具不可用或超时，保留当前版本。") from error
        if process.returncode:
            raise StudioError("更新签名不正确，保留当前版本。")


def checked_url(url):
    parts = urllib.parse.urlsplit(url)
    if (
        parts.scheme == "https"
        or parts.scheme == "http"
        and parts.hostname in ("127.0.0.1", "localhost", "::1")
    ):
        return url
    raise StudioError("更新通道需要 HTTPS；本地 mock 仅允许回环 HTTP。")


def fetch(url, timeout, limit):
    with urllib.request.urlopen(checked_url(url), timeout=timeout) as response:
        checked_url(response.url)
        data = response.read(limit + 1)
    if len(data) > limit:
        raise StudioError("更新文件超过清单大小，已拒绝。")
    return data


def get_channel(url, signers):
    start = time.monotonic()
    raw = fetch(url, 3, 1024 * 1024)
    remaining = 3 - (time.monotonic() - start)
    if remaining <= 0:
        raise TimeoutError()
    signature = fetch(url + ".sig", remaining, 32 * 1024)
    verify(raw, signature, signers)
    data = json.loads(raw)
    if data.get("name") != "leoliu-studio" or data.get("schemaVersion") != 1:
        raise StudioError("更新清单格式不兼容。")
    if not re.fullmatch(r"\d+\.\d+\.\d+", data.get("version", "")):
        raise StudioError("更新版本号不合法。")
    if set(data.get("components", {})) != {"core", "runtime"}:
        raise StudioError("更新清单必须包含 core 和 runtime。")
    for component in data["components"].values():
        if (
            type(component.get("size")) is not int
            or component["size"] <= 0
            or not re.fullmatch("[a-f0-9]{64}", component.get("sha256", ""))
        ):
            raise StudioError("更新组件大小或散列不合法。")
        checked_url(urllib.parse.urljoin(url, component["url"]))
    if data.get("editor_url"):
        checked_url(data["editor_url"])
    return data, raw, signature


def safe_extract(archive, destination, component):
    seen = set()
    with zipfile.ZipFile(archive) as package:
        for item in package.infolist():
            name = item.filename
            path = Path(name)
            if item.is_dir():
                continue
            if (
                "\\" in name
                or path.is_absolute()
                or any(part in (".", "..") for part in path.parts)
                or ":" in name
                or stat.S_ISLNK(item.external_attr >> 16)
                or name in seen
            ):
                raise StudioError("更新压缩包含不安全路径，已拒绝。")
            seen.add(name)
            is_runtime = name.startswith("engine/assets/runtime/")
            if is_runtime != (component == "runtime"):
                raise StudioError("组件文件越过 core / runtime 边界，已拒绝。")
            if name.startswith((".state/", "keys/")):
                # Never let an update silently replace its own trust anchor or local configuration.
                continue
            target = destination / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with package.open(item) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def trusted_manifest(package=PACKAGE, signers=None):
    folder = Path(package) / ".state"
    try:
        raw = (folder / "stable.json").read_bytes()
        signature = (folder / "stable.json.sig").read_bytes()
        verify(raw, signature, signers or Path(package) / "keys/allowed_signers")
        return json.loads(raw)
    except (OSError, ValueError, StudioError):
        return {}


def component_files(folder, component):
    return {
        path.relative_to(folder).as_posix(): digest(path)
        for path in folder.rglob("*")
        if path.is_file()
        and ("engine/assets/runtime/" in path.relative_to(folder).as_posix())
        == (component == "runtime")
        and not any(
            part in (".state", "__pycache__", "keys") for part in path.relative_to(folder).parts
        )
    }


def update(root, apply=False, channel=None, allowed_signers=None, package=PACKAGE):
    package = Path(package).resolve()
    config = read_json(package / "channel.json", {"url": None})
    url = channel or config.get("url")
    if not url:
        return None
    signers = Path(allowed_signers or package / "keys/allowed_signers")
    try:
        data, raw, signature = get_channel(url, signers)
    except (OSError, TimeoutError):
        return None
    state_dir = package / ".state"
    local = trusted_manifest(package, signers)
    current_version = local.get("version", read_json(package / "version.json", {"version": VERSION})["version"])
    target_version = tuple(map(int, data["version"].split(".")))
    if target_version < tuple(map(int, current_version.split("."))):
        raise StudioError("更新版本比当前版本旧，已拒绝降级。")
    installed_state = read_json(state_dir / "components.json", {})
    unchanged = all(
        installed_state.get(name, {}).get("sha256") == row["sha256"]
        for name, row in data["components"].items()
    )
    if target_version == tuple(map(int, current_version.split("."))) and unchanged and not apply:
        # editor_url can be changed by a newly signed manifest without bumping the Skill.
        write_json(state_dir / "channel-config.json", {"url": url})
        state_dir.mkdir(parents=True, exist_ok=True)
        (state_dir / "stable.json").write_bytes(raw)
        (state_dir / "stable.json.sig").write_bytes(signature)
        return {"updated": False, "version": current_version}
    roots = [str(Path(root).resolve())]
    roots += read_json(state_dir / "project-roots.json", {"roots": []})["roots"]
    if any(list(Path(path).glob("*/runs/*/RUNNING")) for path in roots):
        return {"updated": False, "deferred": True, "reason": "项目有任务运行，结束后自动更新。"}
    if not (package / "workflows").is_dir():
        raise StudioError("源码开发目录不能原地更新，请先安装到临时 skills 目录测试。")
    stage = Path(tempfile.mkdtemp(prefix="." + package.name + "-stage-", dir=package.parent))
    downloads = []
    scheduled = False
    try:
        installed = read_json(state_dir / "components.json", {})
        # Build a clean package; only unchanged components are copied, so removed code stays removed.
        for component, entry in data["components"].items():
            old = installed.get(component, {})
            files = old.get("files", {})
            reusable = (
                old.get("sha256") == entry["sha256"]
                and files
                and all(
                    (package / name).is_file() and digest(package / name) == sha
                    for name, sha in files.items()
                )
            )
            if reusable:
                for name in files:
                    target = stage / name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(package / name, target)
            else:
                payload = fetch(urllib.parse.urljoin(url, entry["url"]), 60, entry["size"])
                if (
                    len(payload) != entry["size"]
                    or hashlib.sha256(payload).hexdigest() != entry["sha256"]
                ):
                    raise StudioError("更新组件 SHA-256 或大小不正确，旧版完好。")
                archive = stage.parent / (stage.name + "-" + component + ".zip")
                try:
                    archive.write_bytes(payload)
                    safe_extract(archive, stage, component)
                finally:
                    archive.unlink(missing_ok=True)
                downloads.append(component)
        for name in ("keys", ".state"):
            if (package / name).is_dir():
                shutil.copytree(package / name, stage / name, dirs_exist_ok=True)
        shutil.copy2(package / "channel.json", stage / "channel.json")
        stage_state = stage / ".state"
        stage_state.mkdir(exist_ok=True)
        (stage_state / "stable.json").write_bytes(raw)
        (stage_state / "stable.json.sig").write_bytes(signature)
        write_json(
            stage_state / "components.json",
            {
                component: {"sha256": entry["sha256"], "files": component_files(stage, component)}
                for component, entry in data["components"].items()
            },
        )
        write_json(stage_state / "project-roots.json", {"roots": sorted(set(roots))})
        selftest(stage)
        if sys.platform == "win32":
            result = windows_replace(package, stage, roots, downloads, data)
            scheduled = True
            return result
        from engine_bridge import h3

        with h3.lease():
            result = swap(package, stage, roots)
        return dict(
            result, version=data["version"], downloads=downloads, notes=data.get("notes", "")
        )
    finally:
        if stage.exists() and not scheduled:
            shutil.rmtree(stage)


def windows_replace(package, stage, roots, downloads, data):
    # Helper source and dependencies live outside the installation being renamed.
    import engine_bridge

    helper_dir = Path(tempfile.mkdtemp(prefix="leoliu-update-helper-"))
    shutil.copy2(package / "scripts/update_swap.py", helper_dir / "update_swap.py")
    for name in ("local_support.py", "common.py"):
        shutil.copy2(package / "engine/scripts" / name, helper_dir / name)
    request_path = helper_dir / "request.json"
    result_path = helper_dir / "result.json"
    write_json(
        request_path,
        {
            "current": str(package),
            "stage": str(stage),
            "roots": roots,
            "engineScripts": str(helper_dir),
            "lockDirectory": str(engine_bridge.h3.LOCAL),
            "result": str(result_path),
            "parentPid": os.getpid(),
        },
    )
    with engine_bridge.h3.lease():
        subprocess.Popen(
            [sys.executable, str(helper_dir / "update_swap.py"), "--request", str(request_path)],
            cwd=helper_dir,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=0x00000008 | 0x08000000,
        )
        # The parent returns immediately; the helper's lock acquisition follows process exit.
    return {
        "scheduled": True,
        "resultFile": str(result_path),
        "version": data["version"],
        "downloads": downloads,
        "notes": data.get("notes", ""),
    }
