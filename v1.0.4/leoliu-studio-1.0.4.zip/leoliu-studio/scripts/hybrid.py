"""Hybrid shot dependencies and verified, fully decoded last-frame assets."""

import copy
import hashlib
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from studio_common import StudioError, read_json, write_json, safe_relative, digest, load_project

ALIAS = "previous-frame"


def ordered_bindings(shot):
    return sorted(shot["bindings"], key=lambda row: row["purpose"] != "first_frame")


def dependency_issue(project, workflow_id, shot, visiting=()):
    frame = shot.get("firstFrame")
    if not frame:
        return ""
    if shot["id"] in visiting:
        return "接戏链存在循环，请重新选择上一镜。"
    shots = sorted(project["storyboard"]["workflows"][workflow_id]["shots"], key=lambda row: row["order"])
    index = next(i for i, row in enumerate(shots) if row["id"] == shot["id"])
    if index == 0 or shots[index - 1]["id"] != frame["shotId"]:
        return "末帧来源必须是分镜顺序中的上一镜。"
    previous = shots[index - 1]
    if dependency_issue(project, workflow_id, previous, (*visiting, shot["id"])):
        return "已过期：上游接戏链已改变，请逐镜更新末帧并重新通过。"
    results = [r for r in project["results"]["items"] if r["workflowId"] == workflow_id and r["shotId"] == previous["id"]]
    latest = results[-1] if results else None
    reviews = project["review"]["workflows"].get(workflow_id, {}).get("items", [])
    review = next((row for row in reviews if latest and row["resultId"] == latest["id"]), {})
    if not latest or latest["status"] != "complete" or review.get("decision") != "selected":
        return "等待上一镜完成并选用当前版本，再更新末帧、重新通过。"
    if previous["status"] != "approved":
        return "已过期：上一镜分镜已修改，请先重新通过并生成。"
    from sequential_review import history
    from workflow_tools import shot_hash

    job = history(project["path"]).get((workflow_id, previous["id"]))
    if (not job or job["status"] != "complete" or job["shotSha256"] != shot_hash(previous)
            or latest["runId"] != job["runId"] or not latest["id"].startswith(job["id"] + "-")):
        return "已过期：上一镜已修改或正在重抽，请先完成并选用新版本。"
    if not frame.get("resultId"):
        return "上一镜已选用，请更新末帧并通过此镜。"
    if frame.get("resultId") != latest["id"] or frame.get("videoSha256") != latest.get("sha256"):
        return "已过期：上一镜版本已改变，请更新末帧并重新通过。"
    asset = next((row for row in project["assets"]["items"] if row["id"] == frame.get("assetId")), {})
    source = asset.get("sourceFrame", {})
    if (source.get("resultId"), source.get("videoSha256")) != (latest["id"], latest.get("sha256")):
        return "末帧素材或来源记录缺失，请更新末帧并重新通过。"
    if not any(row["id"] == frame.get("fileId") for row in asset.get("files", [])):
        return "末帧文件缺失，请更新末帧并重新通过。"
    video = safe_relative(project["path"], latest["path"])
    if not video.is_file() or digest(video) != latest["sha256"]:
        return "来源视频散列已改变，请恢复已校验的视频。"
    return ""


def resolve_job(job):
    job = copy.deepcopy(job)
    shot = job["shot"]
    if shot.get("firstFrame"):
        project = load_project(job["projectPath"])
        # Effective auto-reroll content must participate in dependency checks too.
        from auto_reroll import effective

        project = effective(project, job["projectPath"])
        issue = dependency_issue(project, job["workflow"]["id"], shot)
        if issue:
            raise StudioError(issue)
        frame = shot["firstFrame"]
        asset = next(row for row in job["assets"] if row["id"] == frame["assetId"])
        job["assets"].append(dict(asset, id=ALIAS))
        shot["bindings"].insert(0, {"assetId": ALIAS, "fileId": frame["fileId"], "purpose": "first_frame"})
        del shot["firstFrame"]
    shot["bindings"] = ordered_bindings(shot)
    from validation import binding_errors

    issues = binding_errors(shot, {a["id"]: a for a in job["assets"]}, job["workflow"])
    if issues:
        raise StudioError("\n".join(issues))
    return job


def extract_frame(folder, output, shot_id, workflow_id, snapshot=None):
    """Decode every frame in presentation order. No duration-based seek or frame-count estimate."""
    folder = Path(folder)
    video = safe_relative(folder, output["path"])
    if digest(video) != output["sha256"]:
        raise StudioError("来源视频散列不一致，未提取末帧。")
    asset_id = "frame-" + hashlib.sha256((output["id"] + output["sha256"]).encode()).hexdigest()[:24]
    document = read_json(folder / "frame-assets.json", {"schemaVersion": 1, "items": []})
    existing = next((a for a in document["items"] if a["id"] == asset_id), None)
    if existing:
        file = existing["files"][0]
        path = safe_relative(folder, file["path"])
        if path.is_file():
            if digest(path) != file["sha256"]:
                raise StudioError("已提取末帧的散列不一致，请恢复素材。")
            return existing
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise StudioError("提取上一镜末帧需要 ffmpeg，请安装后用 wait 恢复。")
    with tempfile.TemporaryDirectory(prefix="studio-last-frame-") as temp:
        target = Path(temp) / "last.png"
        result = subprocess.run(
            [ffmpeg, "-nostdin", "-hide_banner", "-xerror", "-i", str(video), "-map", "0:v:0",
             "-vf", "showinfo", "-fps_mode", "passthrough", "-an", "-update", "1", "-y", str(target)],
            capture_output=True, text=True, timeout=300,
        )
        frames = re.findall(r"\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:", result.stderr)
        time_base = re.search(r"config in time_base:\s*([0-9]+/[0-9]+)", result.stderr)
        if result.returncode or not frames or not time_base or not target.is_file():
            raise StudioError("视频未完整解码，未保存末帧；请核对视频后恢复任务。")
        relative = "assets/" + asset_id + ".png"
        destination = safe_relative(folder, relative)
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Publish a complete PNG via atomic replacement, including on another filesystem.
        staging = destination.with_suffix(".tmp")
        shutil.copyfile(target, staging)
        staging.replace(destination)
    asset = {
        "id": asset_id, "name": "末帧-" + output["id"], "category": "scene",
        "description": "完整解码的上一镜最后一帧，接戏用。",
        "files": [{"id": "last", "path": relative, "mime": "image/png",
                   "sha256": digest(destination), "size": destination.stat().st_size}],
        "sourceFrame": {"resultId": output["id"], "shotId": shot_id, "workflowId": workflow_id,
                        "videoSha256": output["sha256"], "frameIndex": int(frames[-1][0]),
                        "pts": frames[-1][1], "timeBase": time_base[1]},
    }
    if snapshot is not None:
        asset["sourceFrame"]["shotSnapshot"] = snapshot
    # Only the engine writes this ledger. The page keeps ownership of assets.json.
    document = read_json(folder / "frame-assets.json", {"schemaVersion": 1, "items": []})
    document["items"] = [a for a in document["items"] if a["id"] != asset_id] + [asset]
    write_json(folder / "frame-assets.json", document)
    return asset
