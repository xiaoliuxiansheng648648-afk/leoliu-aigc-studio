"""Local workflow discovery. Installed workflows never load code from linked directories."""

import json
import re
from pathlib import Path


def discover(builtin, extensions):
    from studio_common import StudioError, read_json

    builtin, extensions = Path(builtin), Path(extensions)
    result = {p.parent.name: p.parent for p in builtin.glob("*/manifest.json")}
    if any(p.is_symlink() for p in (extensions, *extensions.parents)):
        raise StudioError("本机扩展工作流目录不能使用符号链接。")
    if not extensions.exists():
        return result
    if not extensions.is_dir():
        raise StudioError("本机扩展工作流入口必须为目录。")
    for folder in sorted(extensions.iterdir()):
        if folder.is_symlink():
            raise StudioError("本机扩展工作流不能使用符号链接。")
        if not folder.is_dir():
            continue
        if any(p.is_symlink() for p in folder.rglob("*")):
            raise StudioError("本机扩展工作流不能包含符号链接。")
        if not (folder / "manifest.json").is_file():
            continue
        value = read_json(folder / "manifest.json")
        if not isinstance(value, dict) or value.get("id") != folder.name or not re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9_-]*", folder.name
        ):
            raise StudioError("本机扩展工作流目录与 manifest 编号不一致。")
        if folder.name in result:
            raise StudioError("工作流编号重复：" + folder.name)
        editor = value.get("editorWorkflow")
        if editor not in result or not (builtin / str(editor) / "manifest.json").is_file():
            raise StudioError("本机扩展工作流必须声明已安装的内置编辑界面。")
        required = ("version", "name", "icon", "order", "assetCategories", "limits", "modes", "models", "defaults", "promptSections")
        if any(key not in value for key in required) or not (folder / "adapter.py").is_file():
            raise StudioError("本机扩展工作流的 manifest 或适配器不完整。")
        result[folder.name] = folder
    return result


def local_editor(source):
    from studio_common import WORKFLOWS, manifest, workflow_directories, extension_workflows, StudioError

    extensions = [manifest(key) for key, folder in workflow_directories().items() if folder.parent != WORKFLOWS]
    if not extensions:
        return source
    marker = r'<script id="studio-local-workflows" type="application/json">\s*\[\]\s*</script>'
    html = source.read_text(encoding="utf-8")
    if len(re.findall(marker, html)) != 1:
        raise ValueError("编辑器缺少本机扩展工作流入口，请重新构建。")
    # JSON is data, never executable markup; escape closing tags and HTML special characters.
    payload = json.dumps(extensions, ensure_ascii=True).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    target = extension_workflows().parent / ".cache/editor-local.html"
    if target.is_symlink() or target.parent.is_symlink():
        raise StudioError("本机扩展工作流页面缓存不能使用符号链接。")
    target.parent.mkdir(parents=True, exist_ok=True)
    replacement = '<script id="studio-local-workflows" type="application/json">' + payload + "</script>"
    target.write_text(re.sub(marker, lambda _: replacement, html), encoding="utf-8")
    return target
