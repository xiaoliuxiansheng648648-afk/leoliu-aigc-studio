"""Assistant rerolls that skip page re-approval, allowed only while the page's brief switch is on.

The page stays the only writer of storyboard.json. The assistant records each reroll in
auto-rerolls.json; compile and run read the page storyboard with those entries applied on top.
An entry only applies while the switch is on and the page shot is still the one it replaced.
"""

import copy
import uuid
from pathlib import Path
from studio_common import StudioError, read_json, write_json, now, load_project
from schema_check import document_errors
from workflow_tools import shot_hash

FILE = "auto-rerolls.json"
EXECUTED = ("complete", "failed", "unknown")


def switch(project, workflow_id):
    workflow = project["brief"]["workflows"].get(workflow_id, {})
    value = workflow.get("settings", {}).get("autoReroll") or {}
    return bool(value.get("enabled")), min(max(int(value.get("maxPerShot", 1)), 1), 3)


def entries(folder):
    value = read_json(Path(folder) / FILE, {"schemaVersion": 1, "items": []})
    errors = document_errors("autoRerolls", value)
    if errors:
        raise StudioError("自动重抽记录格式不正确：\n" + "\n".join(errors))
    return value


def chain(items, workflow_id, page_shot):
    base = shot_hash(page_shot)
    return [
        item
        for item in items
        if item["workflowId"] == workflow_id
        and item["shotId"] == page_shot["id"]
        and item["baseShotSha256"] == base
    ]


def effective(project, folder):
    """The storyboard compile/run should use: page approvals plus authorized assistant rerolls."""
    items = entries(folder)["items"]
    if not items:
        return project
    result = copy.deepcopy(project)
    for workflow_id, workflow in result["storyboard"]["workflows"].items():
        if not switch(result, workflow_id)[0]:
            continue
        for index, shot in enumerate(workflow["shots"]):
            applied = chain(items, workflow_id, shot)
            if shot["status"] == "approved" and applied:
                workflow["shots"][index] = copy.deepcopy(applied[-1]["shot"])
    return result


def executed_shots(folder):
    done = set()
    for record in Path(folder).glob("runs/*/run.json"):
        for job in read_json(record)["jobs"]:
            if job["status"] in EXECUTED:
                done.add((job["workflowId"], job["shotId"]))
    return done


def register(folder, shot_ids, reason):
    folder = Path(folder)
    if not reason.strip():
        raise StudioError("请写明重抽原因。")
    project = load_project(folder)
    draft = read_json(folder / "storyboard.draft.json", {})
    record = entries(folder)
    done = executed_shots(folder)
    added = []
    counts = []
    for shot_id in shot_ids:
        workflow_id, page_shot = next(
            (
                (workflow_id, shot)
                for workflow_id, workflow in project["storyboard"]["workflows"].items()
                for shot in workflow["shots"]
                if shot["id"] == shot_id
            ),
            (None, None),
        )
        if not page_shot:
            raise StudioError("页面分镜里没有这一镜：" + shot_id)
        enabled, limit = switch(project, workflow_id)
        if not enabled:
            raise StudioError("页面没有打开“授权 AI 自动重抽”。请先在页面打开，或照常在页面重新通过。")
        if page_shot["status"] != "approved":
            raise StudioError("这一镜还没在页面通过，不能自动重抽：" + shot_id)
        if (workflow_id, shot_id) not in done:
            raise StudioError("这一镜还没跑过，不算重抽：" + shot_id)
        draft_shot = next(
            (
                shot
                for shot in draft.get("workflows", {}).get(workflow_id, {}).get("shots", [])
                if shot["id"] == shot_id
            ),
            None,
        )
        if not draft_shot:
            raise StudioError("草稿里没有这一镜，请先把改好的提示词写进 storyboard.draft.json：" + shot_id)
        shot = dict(copy.deepcopy(draft_shot), status="approved")
        errors = document_errors("shot", shot)
        if errors:
            raise StudioError("\n".join(errors))
        previous = chain(record["items"] + added, workflow_id, page_shot)
        if len(previous) >= limit:
            raise StudioError(f"这一镜自动重抽已经 {limit} 次，到上限了，请交给用户决定：" + shot_id)
        current = previous[-1]["shotSha256"] if previous else shot_hash(page_shot)
        if shot_hash(shot) == current:
            raise StudioError("草稿里这一镜和上一版一样。种子是固定的，请先改提示词再重抽：" + shot_id)
        counts.append((shot_id, len(previous) + 1))
        added.append(
            {
                "id": "reroll-" + uuid.uuid4().hex,
                "workflowId": workflow_id,
                "shotId": shot_id,
                "draftRevision": draft["draftRevision"],
                "baseShotSha256": shot_hash(page_shot),
                "shotSha256": shot_hash(shot),
                "reason": reason.strip(),
                "shot": shot,
                "createdAt": now(),
            }
        )
    record["items"] += added
    errors = document_errors("autoRerolls", record)
    if errors:
        raise StudioError("\n".join(errors))
    write_json(folder / FILE, record)
    return {
        "已登记": [
            {"镜头": shot_id, "原因": reason.strip(), "第几次": count}
            for shot_id, count in counts
        ],
        "下一步": "运行 run 项目名 开跑这些镜头；当前任务没结束就等它结束后再运行。",
    }


def summary(project, folder):
    items = entries(folder)["items"]
    rows = []
    for workflow_id, workflow in project["storyboard"]["workflows"].items():
        enabled, limit = switch(project, workflow_id)
        for shot in workflow["shots"]:
            used = len(chain(items, workflow_id, shot))
            if used or enabled:
                rows.append(
                    {
                        "工作流": workflow_id,
                        "镜头": shot["id"],
                        "开关": "开" if enabled else "关",
                        "已自动重抽": used,
                        "上限": limit,
                    }
                )
    return rows
