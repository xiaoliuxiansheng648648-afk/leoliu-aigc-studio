import os
import shutil
import subprocess
import sys
import urllib.request
import urllib.parse
from pathlib import Path
from studio_common import PACKAGE, ROOT


def local_editor():
    return (
        PACKAGE / "editor/index.html"
        if (PACKAGE / "editor/index.html").is_file()
        else ROOT / "dist/index.html"
    )


def select_target(editor_url=None, project=None, probe=None):
    from workflow_registry import local_editor as with_extensions

    source = local_editor()
    editor = with_extensions(source)
    if editor != source:
        editor_url = None
    target = editor.resolve().as_uri()
    if editor_url and urllib.parse.urlsplit(editor_url).scheme in ("http", "https"):
        try:
            if probe:
                reachable = probe(editor_url, 3)
            else:
                with urllib.request.urlopen(
                    urllib.request.Request(editor_url, method="HEAD"), timeout=3
                ) as response:
                    reachable = 200 <= response.status < 400
            if reachable:
                target = editor_url
        except (OSError, ValueError):
            pass
    if project:
        target += "#" + urllib.parse.urlencode({"project": project})
    return target


def chromium_browser():
    if sys.platform == "darwin":
        for app in ("Google Chrome", "Microsoft Edge"):
            path = Path("/Applications") / (app + ".app/Contents/MacOS/" + app)
            if path.is_file():
                return str(path)
    elif sys.platform == "win32":
        for root in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            for relative in (
                "Google/Chrome/Application/chrome.exe",
                "Microsoft/Edge/Application/msedge.exe",
            ):
                path = Path(os.environ.get(root, "")) / relative
                if path.is_file():
                    return str(path)
    for name in ("google-chrome", "chrome", "msedge", "chromium"):
        if shutil.which(name):
            return shutil.which(name)
    return None


def open_editor(editor_url=None, project=None, print_only=False):
    target = select_target(editor_url, project)
    browser = chromium_browser()
    if print_only:
        return {"target": target, "browser": browser, "launched": False}
    if browser:
        if sys.platform == "darwin":
            # LaunchServices keeps the browser independent of the invoking task. A new instance
            # with the default profile reaches the user's own Chrome, never an automation
            # Chrome that holds a temporary profile.
            app = Path(browser).parents[2]
            subprocess.run(
                ["/usr/bin/open", "-na", str(app), "--args", "--profile-directory=Default", target],
                check=True,
            )
        else:
            subprocess.Popen([browser, target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    else:
        import webbrowser

        webbrowser.open((PACKAGE / "references/browser-help.html").resolve().as_uri())
    return {"target": target, "browser": browser, "launched": True}
