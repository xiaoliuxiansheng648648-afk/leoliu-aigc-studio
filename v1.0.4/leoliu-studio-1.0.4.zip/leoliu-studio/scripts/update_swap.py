"""Detached Windows helper and shared transactional directory replacement. Standard library only."""

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path


def rename(source, target):
    last = None
    for _ in range(20):
        try:
            Path(source).rename(target)
            return
        except PermissionError as error:
            last = error
            time.sleep(0.25)
    raise last


def selftest(folder):
    process = subprocess.run(
        [sys.executable, str(Path(folder) / "scripts/studio.py"), "selftest"],
        capture_output=True,
        timeout=30,
    )
    if process.returncode:
        raise RuntimeError("新版自检失败。")


def swap(current, stage, roots, tester=selftest):
    current, stage = Path(current), Path(stage)
    previous = current.with_name(current.name + ".prev")
    for root in map(lambda value: Path(value).resolve(), roots):
        for folder in (current.resolve(), stage.resolve(), previous.resolve()):
            if root == folder or root in folder.parents or folder in root.parents:
                raise RuntimeError("安装目录、更新暂存目录或备份目录与项目根目录重叠，已拒绝更新以保护项目。")
    if any(list(Path(root).glob("*/runs/*/RUNNING")) for root in roots):
        raise RuntimeError("项目有任务运行，更新已推迟。")
    tester(stage)
    # The installed version is untouched until the complete staged package passes selftest.
    if previous.exists():
        shutil.rmtree(previous)
    rename(current, previous)
    try:
        rename(stage, current)
        tester(current)
    except BaseException:
        if current.exists():
            rename(current, stage)
        rename(previous, current)
        raise
    return {"updated": True, "previous": str(previous)}


def wait_parent(pid):
    if sys.platform != "win32":
        return
    import ctypes

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.OpenProcess.restype = ctypes.c_void_p
    kernel.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    kernel.CloseHandle.argtypes = [ctypes.c_void_p]
    handle = kernel.OpenProcess(0x00100000, False, pid)
    if not handle and ctypes.get_last_error() != 87:
        raise RuntimeError("无法确认主进程已退出，保留旧版，稍后重试更新。")
    if handle:
        try:
            if kernel.WaitForSingleObject(handle, 30000) != 0:
                raise RuntimeError("主进程仍未退出，保留旧版，稍后重试更新。")
        finally:
            kernel.CloseHandle(handle)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", required=True)
    args = parser.parse_args()
    request = json.loads(Path(args.request).read_text(encoding="utf-8"))
    try:
        wait_parent(request["parentPid"])
        # Parent owns this lease; Windows releases its byte-range lock on process exit.
        sys.path.insert(0, request["engineScripts"])
        import local_support

        deadline = time.monotonic() + 30
        while True:
            try:
                with local_support.operation_lock(Path(request["lockDirectory"])):
                    result = swap(request["current"], request["stage"], request["roots"])
                break
            except Exception as error:
                if "另一个" in str(error) and time.monotonic() < deadline:
                    time.sleep(0.25)
                    continue
                raise
    except Exception as error:
        result = {"updated": False, "error": str(error), "retainedStage": request["stage"]}
    Path(request["result"]).write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return 0 if result["updated"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
