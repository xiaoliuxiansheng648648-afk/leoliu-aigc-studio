"""Shared graph mechanics. Plugins choose their own templates and modes."""

import copy
import hashlib
import json
from pathlib import Path
from studio_common import read_json, manifest, safe_relative
from validation import compile_prompt


def shot_hash(shot):
    content = {key: value for key, value in shot.items() if key != "status"}
    return hashlib.sha256(
        json.dumps(content, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def plan(project, folder):
    workflow = read_json(Path(folder) / "manifest.json")
    workflow_id = workflow["id"]
    board = project["storyboard"]["workflows"].get(workflow_id, {"shots": []})
    return [
        {
            "shot": copy.deepcopy(shot),
            "workflow": workflow,
            "assets": copy.deepcopy(project["assets"]["items"]),
            "settings": project["brief"]["workflows"]
            .get(workflow_id, {})
            .get("settings", workflow["defaults"]),
            "projectPath": str(project["path"]),
        }
        for shot in board["shots"]
    ]


def compile_h3(job, folder, reference=False):
    folder = Path(folder)
    workflow = read_json(folder / "manifest.json")
    assets = {asset["id"]: asset for asset in job["assets"]}
    shot = job["shot"]
    prompt, tables = compile_prompt(shot, assets, workflow)
    graph_name = (
        "graph.api.json" if reference else ("i2v.api.json" if shot["bindings"] else "t2v.api.json")
    )
    graph = read_json(folder / graph_name)
    defaults = workflow["defaults"]
    width, height = defaults["width"], defaults["height"]
    if job["settings"]["orientation"] == "portrait":
        width, height = height, width
    frames = int(shot["durationSeconds"] * defaults["fps"])
    length = (
        defaults["length"]
        if shot["durationSeconds"] == defaults["secondsPerShot"]
        else frames + (5 - frames % 17) % 17
    )
    graph["9"]["inputs"].update(prompt=prompt, width=width, height=height, length=length)
    graph["10"]["inputs"]["noise_seed"] = defaults["seed"]
    graph["12"]["inputs"]["sampler_name"] = defaults["sampler"]
    graph["13"]["inputs"].update(steps=defaults["steps"], scheduler=defaults["scheduler"])
    graph["17"]["inputs"]["fps"] = defaults["fps"]
    if reference:
        graph["9"]["inputs"]["ref_image_size"] = defaults["refImageSize"]
    graph["18"]["inputs"]["filename_prefix"] = "leoliu-studio/" + job.get("id", shot["id"])
    uploads = []
    for binding in shot["bindings"]:
        aid = binding["assetId"]
        asset = assets[aid]
        file = next(file for file in asset["files"] if file["id"] == binding["fileId"])
        kind = "audio" if asset["category"] == "voice" else "picture"
        order = tables[kind][aid] - 1
        node_id = str(40 + order) if kind == "audio" else str(8 if order == 0 else 18 + order)
        remote_name = file["sha256"] + Path(file["path"]).suffix.lower()
        graph[node_id] = {
            "class_type": "LoadAudio" if kind == "audio" else "LoadImage",
            "inputs": {"audio" if kind == "audio" else "image": remote_name},
        }
        if workflow["id"] == "h3-hybrid" and binding["purpose"] == "first_frame":
            graph["9"]["inputs"]["first_frame"] = [node_id, 0]
        elif reference:
            slot = order - (1 if workflow["id"] == "h3-hybrid" and kind == "picture" else 0)
            graph["9"]["inputs"][
                ("ref_audios.ref_audio_" if kind == "audio" else "ref_images.ref_image_")
                + str(slot)
            ] = [node_id, 0]
        else:
            graph["9"]["inputs"]["first_frame"] = [node_id, 0]
        safe_relative(job["projectPath"], file["path"])
        uploads.append(
            {
                "assetId": aid,
                "fileId": file["id"],
                "path": file["path"],
                "sha256": file["sha256"],
                "size": file["size"],
                "remoteName": remote_name,
                "nodeId": node_id,
                "mediaType": kind,
            }
        )
    return {"graph": graph, "prompt": prompt, "uploads": uploads, "tables": tables}


def collect(job, outputs):
    return [
        dict(output, shotId=job["shotId"], workflowId=job["workflowId"], runId=job["runId"])
        for output in outputs
    ]
