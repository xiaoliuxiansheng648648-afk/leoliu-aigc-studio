"""One downloaded shot per invocation, gated by the page's selection of its current take."""

from pathlib import Path
from studio_common import StudioError, load_project, read_json
from auto_reroll import effective
from workflow_tools import shot_hash


def sequential(project, workflow_id):
    """h3-hybrid chains always review shot by shot; any other workflow follows only its own switch."""
    if workflow_id == "h3-hybrid":
        return True
    settings = project["brief"]["workflows"].get(workflow_id, {}).get("settings", {})
    return bool(settings.get("sequentialReview", False))


def enabled(project, workflows):
    """Decided by the workflows being run, never by another workflow's switch or default."""
    return any(sequential(project, workflow_id) for workflow_id in set(workflows))


def history(folder):
    latest = {}
    runs = [read_json(path) for path in Path(folder).glob("runs/*/run.json")]
    for run in sorted(runs, key=lambda row: (row["createdAt"], row["id"])):
        for job in run["jobs"]:
            if job["status"] != "prepared":
                latest[(job["workflowId"], job["shotId"])] = dict(job, runId=run["id"])
    return latest


def selected(project, workflow_id, shot, latest):
    if not latest or latest["status"] != "complete" or latest["shotSha256"] != shot_hash(shot):
        return False
    reviews = {
        row["resultId"]: row
        for row in project["review"]["workflows"].get(workflow_id, {}).get("items", [])
    }
    return any(
        row["workflowId"] == workflow_id
        and row["shotId"] == shot["id"]
        and row["runId"] == latest["runId"]
        and row["id"].startswith(latest["id"] + "-")
        and row["status"] == "complete"
        and reviews.get(row["id"], {}).get("decision") == "selected"
        and reviews[row["id"]]["shotId"] == shot["id"]
        for row in project["results"]["items"]
    )


def choose(folder, jobs, workflows=()):
    # workflows: everything this run covers, including workflows whose shots were all run before.
    running = set(workflows) | {job["workflowId"] for job in jobs}
    project = effective(load_project(folder), folder)
    if not enabled(project, running):
        return jobs
    latest = history(folder)
    by_shot = {(job["workflowId"], job["shotId"]): job for job in jobs}
    batch = []
    for workflow_id, workflow in project["storyboard"]["workflows"].items():
        if workflow_id not in running:
            continue
        if not sequential(project, workflow_id):
            batch.extend(job for job in jobs if job["workflowId"] == workflow_id)
            continue
        for shot in sorted(workflow["shots"], key=lambda row: row["order"]):
            if workflow_id == "h3-hybrid" and shot.get("firstFrame"):
                from hybrid import dependency_issue

                issue = dependency_issue(project, workflow_id, shot)
                if issue:
                    raise StudioError(issue)
            key = (workflow_id, shot["id"])
            if shot["status"] == "approved" and selected(project, workflow_id, shot, latest.get(key)):
                continue
            if shot["status"] != "approved":
                raise StudioError(f"逐镜审核停在 {shot['id']}：请先在页面通过这一镜的分镜。GPU 不会自动关机。")
            if key in by_shot:
                return [by_shot[key]]
            raise StudioError(
                f"逐镜审核停在 {shot['id']}：请在工作台对当前最新一版点“选用此版”，再在对话里说“继续”。"
                "需要重抽时先更新这一镜并重新通过，或使用已授权的 AI 自动重抽。GPU 不会自动关机。"
            )
    if not batch:
        raise StudioError("逐镜审核的镜头已全部选用；GPU 不会自动关机，请在对话里说“关机”。")
    return batch[:1]


def instruction():
    return (
        "已暂停，请用户在工作台对当前最新一版点“选用此版”，再在对话里说“继续”。"
        "不满意先重抽当前镜头。GPU 仍在计费，本模式不会自动关机；全部完成或暂时不用时请说“关机”。"
    )
