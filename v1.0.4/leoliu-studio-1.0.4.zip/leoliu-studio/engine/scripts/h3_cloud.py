#!/usr/bin/env python3
"""leoliu-h3-cloud: macOS/Windows local CLI, using only Python's standard library and system tools."""
import argparse
import base64
import contextlib
import datetime
import hashlib
import io
import http.client
import json
import math
import os
import re
import shlex
import shutil
import socket
import subprocess
import sys
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from common import (
    ROOT,
    GIB,
    H3Error,
    OOM,
    NO_GPU,
    digest,
    frame_count,
    say,
    write_json,
    lora_filename,
)

import local_support as local

LOCAL = local.local_dir()
# Reuse one SSH connection: some gateways intermittently reset fresh handshakes.
MUX = (
    []
    if os.name == "nt"
    else [
        "-o",
        "ControlMaster=auto",
        "-o",
        "ControlPath=" + (Path.home() / ".ssh" / "leoliu-%C").as_posix(),
        "-o",
        "ControlPersist=3600",
    ]
)
# ssh stderr for failures before any remote command started; only these are retried.
BEFORE_SESSION = (
    "kex_exchange_identification",
    "banner exchange",
    "Connection refused",
    "Connection timed out",
    "Operation timed out",
)
RETRY_WAITS = (5, 10, 20, 30, 45)


def before_session(process):
    return process.returncode == 255 and any(
        text in process.stderr.decode(errors="replace") for text in BEFORE_SESSION
    )
SIZES = {"landscape": (1344, 768), "portrait": (768, 1344), "hd": (1920, 1088)}


def keychain_get():
    return local.credential_get()


def keychain_set(value):
    return local.credential_set(value)


def dialog(message, hidden=False):
    return local.dialog(message, hidden)


def parse_login(login):
    try:
        words = shlex.split(login)
        if words.pop(0) != "ssh":
            raise ValueError()
        port = 22
        target = None
        while words:
            word = words.pop(0)
            if word == "-p":
                port = int(words.pop(0))
            elif word.startswith("-p") and word[2:].isdigit():
                port = int(word[2:])
            elif target is None and re.fullmatch(r"[A-Za-z0-9_.-]+@[A-Za-z0-9.-]+", word):
                target = word
            else:
                raise ValueError()
        if not target or not 1 <= port <= 65535:
            raise ValueError()
        user, host = target.split("@")
        return {"user": user, "host": host, "port": port}
    except (IndexError, ValueError):
        raise H3Error("登录指令格式未识别；请复制控制台提供的标准 SSH 登录指令。")


def identity(connection):
    return hashlib.sha256(
        json.dumps({k: connection[k] for k in ("user", "host", "port")}, sort_keys=True).encode()
    ).hexdigest()


@contextlib.contextmanager
def lease():
    with local.operation_lock(LOCAL):
        yield


class Remote:
    def __init__(self):
        self.ssh = local.ssh_executable()
        self.askpass = local.prepare_askpass(LOCAL)
        self.connection = keychain_get()
        self.identity = identity(self.connection)
        self.package = None
        if MUX:
            (Path.home() / ".ssh").mkdir(mode=0o700, exist_ok=True)

    def argv(self, extra=None):
        c = self.connection
        return [
            self.ssh,
            "-p",
            str(c["port"]),
            "-o",
            "StrictHostKeyChecking=accept-new",
            "-o",
            "UserKnownHostsFile=" + (LOCAL / "known_hosts").as_posix(),
            "-o",
            "LogLevel=ERROR",
            "-o",
            "ConnectTimeout=12",
            "-o",
            "HashKnownHosts=yes",
            "-o",
            "ServerAliveInterval=15",
            "-o",
            "ServerAliveCountMax=4",
            "-o",
            "NumberOfPasswordPrompts=1",
            *(extra or []),  # before MUX: ssh keeps the first value of an option
            *MUX,
            c["user"] + "@" + c["host"],
        ]

    def env(self):
        return local.askpass_env(self.askpass)

    def python_command(self, *args):
        # SSH does not source Conda's interactive shell setup. Resolve without a second
        # connection, modifying PATH, creating system links, or consuming upload stdin.
        candidates = (
            '"$(command -v python3 2>/dev/null)" '
            '"$HOME/miniconda3/bin/python3" "$HOME/anaconda3/bin/python3" '
            '"/opt/conda/bin/python3" "/usr/local/bin/python3" "/usr/bin/python3" '
            '"$HOME"/miniconda3/envs/*/bin/python3 "$HOME"/anaconda3/envs/*/bin/python3 '
            "/opt/conda/envs/*/bin/python3"
        )
        # Images often ship an old system python3 first on PATH and PyTorch in a Conda env.
        # Prefer Python 3.12 with PyTorch; otherwise the first one reports what is missing.
        probe = shlex.quote(
            "import sys,importlib.util as u;"
            "sys.exit(sys.version_info[:2]!=(3,12) or u.find_spec('torch') is None)"
        )
        run = shlex.join(args)
        return (
            "_leoliu_first=; for _leoliu_py in " + candidates + '; do '
            'if [ -n "$_leoliu_py" ] && [ -x "$_leoliu_py" ]; then '
            '[ -n "$_leoliu_first" ] || _leoliu_first="$_leoliu_py"; '
            'if "$_leoliu_py" -c ' + probe + " </dev/null >/dev/null 2>&1; then "
            'exec "$_leoliu_py" ' + run + "; fi; fi; done; "
            'if [ -n "$_leoliu_first" ]; then exec "$_leoliu_first" ' + run + "; fi; "
            "printf '%s\\n' 'LEOLIU_PYTHON_MISSING' >&2; exit 126"
        )

    def execute(self, command, data=None, timeout=90, raw=False):
        for wait in (0, *RETRY_WAITS):
            if wait:
                say(f"SSH 入口拒绝握手，命令还没发出，{wait} 秒后重连", mark="…")
                time.sleep(wait)
            try:
                p = subprocess.run(
                    self.argv() + [command],
                    input=data,
                    capture_output=True,
                    env=self.env(),
                    timeout=timeout,
                    **local.process_options(),
                )
            except subprocess.TimeoutExpired:
                raise H3Error("连接或实例操作超时；未自动重发任务。")
            if not before_session(p):
                break
        if raw:
            return p
        lines = p.stdout.decode(errors="replace").splitlines()
        result = next(
            (
                json.loads(x[len("@@RESULT@@") :])
                for x in reversed(lines)
                if x.startswith("@@RESULT@@")
            ),
            None,
        )
        if result is None:
            if p.returncode == 255:
                raise H3Error("连接失败；请核对实例开机状态和系统凭据中的登录信息。")
            if p.returncode in (126, 127):
                raise H3Error("SSH 已连通，但实例命令或 Python 不可用；无需重新保存登录信息。")
            raise H3Error(f"SSH 已连通，但实例命令未返回有效结果（退出码 {p.returncode}）。")
        if result.get("ok") is False:
            raise H3Error(result.get("error", "实例操作未通过。"))
        if p.returncode:
            raise H3Error(f"SSH 已连通，但实例操作失败（退出码 {p.returncode}）。")
        return result.get("value", result)

    def upload_lora(self, path, request):
        payload = base64.b64encode(json.dumps(request).encode()).decode()
        command = self.python_command(
            self.package + "/scripts/remote.py", "upload-lora", "--request-b64", payload
        )
        with Path(path).open("rb") as source:
            try:
                result = subprocess.run(
                    self.argv() + [command],
                    stdin=source,
                    capture_output=True,
                    env=self.env(),
                    timeout=1800,
                    **local.process_options(),
                )
            except subprocess.TimeoutExpired:
                raise H3Error("LoRA 上传超时；未自动重传，可用同名同散列命令重试。")
        lines = result.stdout.decode(errors="replace").splitlines()
        value = next(
            (
                json.loads(x[len("@@RESULT@@") :])
                for x in reversed(lines)
                if x.startswith("@@RESULT@@")
            ),
            None,
        )
        if result.returncode or value is None or value.get("ok") is False:
            raise H3Error(
                value.get("error", "LoRA 上传失败，未标记完成。")
                if value
                else "LoRA 上传连接中断，未标记完成。"
            )
        return value.get("value", value)

    def sync(self):
        files = [
            path
            for path in sorted(ROOT.rglob("*"))
            if path.is_file()
            and "__pycache__" not in path.parts
            and path.suffix != ".pyc"
            and "tests" not in path.parts
        ]
        stamp = hashlib.sha256()
        for path in files:
            stamp.update(path.relative_to(ROOT).as_posix().encode() + b"\0")
            stamp.update(hashlib.sha256(path.read_bytes()).digest())
        stamp = stamp.hexdigest()
        # The package holds an 11 MB runtime archive; skip the upload when the instance has this exact one.
        probe = """import pathlib,json
p=pathlib.Path.home()/'.local/share/leoliu-h3-cloud/package';s=p/'.sync-stamp'
print('@@RESULT@@'+json.dumps({'value':{'package':str(p),'stamp':s.read_text().strip() if s.is_file() else ''}}))
"""
        current = self.execute(self.python_command("-c", probe))
        if current.get("stamp") == stamp:
            self.package = current["package"]
            return {"package": self.package, "skipped": True}
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as t:
            for path in files:
                t.add(path, arcname=path.relative_to(ROOT).as_posix(), recursive=False)
        code = """import sys,tarfile,pathlib,io,json
p=pathlib.Path.home()/'.local/share/leoliu-h3-cloud/package';p.mkdir(parents=True,exist_ok=True)
s=p/'.sync-stamp'
if s.exists(): s.unlink()
with tarfile.open(fileobj=io.BytesIO(sys.stdin.buffer.read()),mode='r:gz') as t:
 for m in t.getmembers():
  if m.name.startswith('/') or '..' in pathlib.Path(m.name).parts or not m.isfile(): raise ValueError('unsafe package')
  dst=p/m.name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(t.extractfile(m).read())
s.write_text(sys.argv[1])
print('@@RESULT@@'+json.dumps({'value':{'package':str(p)}}))
"""
        result = self.execute(self.python_command("-c", code, stamp), buf.getvalue(), timeout=240)
        self.package = result["package"]
        return result

    def call(self, action, request=None, background=False):
        request = request or {}
        # Resolve the runtime from its state. Pre-install operations keep the base Python.
        launcher = """import os,sys,pathlib,json
p=pathlib.Path.home()/'.local/share/leoliu-h3-cloud/package/scripts/remote.py'
state=pathlib.Path.home()/'.local/share/leoliu-h3-cloud/state.json'
py=sys.executable
if state.exists() and sys.argv[1] in ('doctor','start','restart','cpu-check'):
 py=str(pathlib.Path(json.loads(state.read_text())['software'])/'.venv/bin/python')
os.execv(py,[py,str(p)]+sys.argv[1:])
"""
        args = [action, "--request-b64", base64.b64encode(json.dumps(request).encode()).decode()]
        if background:
            args.append("--background")
        return self.execute(
            self.python_command("-c", launcher, *args), timeout=300
        )

    def task(self, action, request):
        job = self.call(action, request, background=True)["job"]
        # Persistent polling never restarts an interrupted installation job.
        write_json(LOCAL / "last-job.json", {"job": job, "target": self.identity, "action": action})
        return self.wait_task(job)

    def wait_task(self, job):
        seen = 0
        interval = 0.25
        t = time.monotonic()
        last_notice = t
        while True:
            result = self.call("job", {"job": job})
            for ev in result.get("events", [])[seen:]:
                say(ev["message"], ev.get("elapsed", time.monotonic() - t), ev.get("mark", "…"))
            seen = len(result.get("events", []))
            if not result.get("running"):
                if result.get("ok") is False:
                    raise H3Error(result["error"])
                return result.get("value", {})
            if time.monotonic() - last_notice >= 45:
                say("实例正在处理，详细进度保存在实例日志", time.monotonic() - t, "…")
                last_notice = time.monotonic()
            time.sleep(interval)
            interval = min(10, interval * 2)

    def probe_connection(self):
        try:
            p = self.execute("true", timeout=20, raw=True)
        except H3Error:
            return "unreachable"
        if p.returncode == 0:
            return "connected"
        text = p.stderr.lower()
        if (
            b"permission denied" in text
            or b"host key verification failed" in text
            or b"remote host identification" in text
        ):
            return "auth-error"
        if any(
            x in text
            for x in (
                b"connection refused",
                b"connection timed out",
                b"operation timed out",
                b"no route to host",
                b"connection closed",
                b"connection reset",
                b"network is unreachable",
            )
        ):
            return "unreachable"
        return "unknown"


class Tunnel:
    def __init__(self, remote):
        self.remote = remote
        self.process = None
        self.port = None

    def __enter__(self):
        for wait in (0, *RETRY_WAITS):
            if wait:
                say(f"服务隧道未建立，{wait} 秒后重连", mark="…")
                time.sleep(wait)
            if self.open():
                return self
        raise H3Error("服务连接未建立，请用 doctor 核对实例。")

    def open(self):
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            self.port = sock.getsockname()[1]
        self.process = subprocess.Popen(
            self.remote.argv(
                [
                    "-N",
                    "-L",
                    f"127.0.0.1:{self.port}:127.0.0.1:18188",
                    "-o",
                    "ExitOnForwardFailure=yes",
                    # A multiplexed -N forward returns at once; keep the tunnel its own process.
                    "-o",
                    "ControlPath=none",
                ]
            ),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=self.remote.env(),
            **local.process_options(),
        )
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                break
            try:
                with socket.create_connection(("127.0.0.1", self.port), timeout=1):
                    return True
            except OSError:
                time.sleep(0.2)
        self.__exit__()
        return False

    def __exit__(self, *args):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()


class Comfy:
    def __init__(self, tunnel):
        self.tunnel = tunnel
        self.base = f"http://127.0.0.1:{tunnel.port}"

    def call(self, path, data=None, raw=False, headers=None):
        if data is not None and not isinstance(data, bytes):
            data = json.dumps(data).encode()
        for attempt in range(3):
            req = urllib.request.Request(
                self.base + path, data=data, headers=headers or {"Content-Type": "application/json"}
            )
            try:
                with urllib.request.urlopen(req, timeout=90) as f:
                    b = f.read()
                break
            except urllib.error.HTTPError as e:
                if path == "/prompt":
                    raise H3Error("提交被拒绝；请检查节点、模型和参数，未自动重发。")
                raise H3Error("服务返回错误，未自动重发。")
            except (OSError, urllib.error.URLError, http.client.HTTPException):
                if path == "/prompt":
                    raise H3Error("任务提交响应中断，状态未知；请查询记录，禁止重复提交。")
                # Rebuild a dropped SSH forward only for idempotent reads. Never replay a POST.
                if data is not None or attempt == 2:
                    raise H3Error("服务连接中断；用 wait 恢复当前任务。")
                say("只读状态查询连接中断，重建连接后继续查原任务；不重发生成", mark="…")
                self.tunnel.__exit__()
                self.tunnel.__enter__()
                self.base = f"http://127.0.0.1:{self.tunnel.port}"
        return b if raw else json.loads(b)

    def download(self, relative, destination):
        p = Path(relative)
        if p.is_absolute() or ".." in p.parts:
            raise H3Error("服务返回了不安全的输出路径。")
        query = urllib.parse.urlencode(
            {
                "filename": p.name,
                "subfolder": str(p.parent) if str(p.parent) != "." else "",
                "type": "output",
            }
        )
        try:
            with urllib.request.urlopen(
                self.base + "/view?" + query, timeout=600
            ) as response, Path(destination).open("wb") as f:
                shutil.copyfileobj(response, f, 4 * 1024**2)
        except (OSError, urllib.error.URLError, http.client.HTTPException):
            raise H3Error("下载中断；远端结果仍保留，用 wait 恢复下载。")


def validate_lora(mode, lora=None, strength=None):
    if lora is None:
        if strength is not None:
            raise H3Error("--lora-strength 需要同时指定 --lora。")
        return None
    lora_filename(lora)
    # fast-hd also loads the turbo LoRA; neither accelerated graph stacks styles.
    if mode != "standard":
        raise H3Error("--lora 不能与 turbo 或 fast-hd 同用，本次不叠加 LoRA。")
    strength = 1.0 if strength is None else strength
    if not math.isfinite(strength):
        raise H3Error("LoRA 强度需要是有限数字。")
    return strength


def validate_lora_upload(args):
    if not args.file or not args.name or not args.sha256:
        raise H3Error("upload-lora 需要 --file、--name 和 --sha256。")
    lora_filename(args.name)
    if not re.fullmatch("[a-f0-9]{64}", args.sha256):
        raise H3Error("需要 manifest 中的 SHA-256。")
    path = Path(args.file).expanduser().resolve()
    if not path.is_file() or path.suffix.lower() != ".safetensors" or path.stat().st_size == 0:
        raise H3Error("LoRA 需要是本机非空 safetensors 文件。")
    if digest(path) != args.sha256:
        raise H3Error("本机 LoRA SHA-256 与 manifest 不一致，未连接实例。")
    return path


def upload_lora(remote, args):
    path = validate_lora_upload(args)
    request = {"name": args.name, "sha256": args.sha256, "bytes": path.stat().st_size}
    remote.sync()
    result = remote.upload_lora(path, request)
    if result.get("sha256") != request["sha256"] or result.get("bytes") != request["bytes"]:
        raise H3Error("远端 LoRA SHA-256 或大小不一致，未标记完成。")
    say("LoRA 上传与远端散列核对通过：" + args.name)
    return result


def build_workflow(
    prompt,
    seconds=5,
    size="landscape",
    mode="standard",
    image=None,
    seed=42,
    label="video",
    lora=None,
    lora_strength=None,
):
    strength = validate_lora(mode, lora, lora_strength)
    if seconds not in (5, 10, 15):
        raise H3Error("时长可选 5、10、15 秒。")
    if size not in SIZES:
        raise H3Error("分辨率预设无效。")
    if mode not in ("standard", "turbo", "fast-hd"):
        raise H3Error("生成模式无效。")
    w = json.loads(
        (ROOT / "assets/workflows" / ("i2v.api.json" if image else "t2v.api.json")).read_text(
            encoding="utf-8"
        )
    )
    width, height = SIZES[size]
    w["9"]["inputs"].update(prompt=prompt, width=width, height=height, length=frame_count(seconds))
    w["10"]["inputs"]["noise_seed"] = seed
    w["18"]["inputs"]["filename_prefix"] = "leoliu-h3-cloud/" + label
    if image:
        w["8"]["inputs"]["image"] = image
    if lora is not None:
        w["20"] = {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {"model": ["1", 0], "lora_name": lora, "strength_model": strength},
        }
        w["11"]["inputs"]["model"] = ["20", 0]
        w["13"]["inputs"]["model"] = ["20", 0]
    if mode in ("turbo", "fast-hd"):
        w["20"] = {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["1", 0],
                "lora_name": "minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
                "strength_model": 0.75,
            },
        }
        w["21"] = {
            "class_type": "MiniMaxH3SigmaShift",
            "inputs": {"model": ["20", 0], "shift_video": 8.0, "shift_audio": 3.0},
        }
        w["11"]["inputs"]["model"] = ["21", 0]
        w["13"]["inputs"].update(model=["21", 0], steps=8)
        w["12"]["inputs"]["sampler_name"] = "euler"
    if mode == "fast-hd":
        # Preserve first-pass audio, upscale video latent only, then refine three steps.
        w["9"]["inputs"].update(
            width=864 if width >= height else 480, height=480 if width >= height else 864
        )
        w["30"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["14", 1]}}
        w["31"] = {
            "class_type": "MinimaxH3LatentUpscaler3D",
            "inputs": {
                "latent": ["30", 0],
                "model_name": "minimax_h3_latent_upscaler_3d_fp16.safetensors",
                "mode": "target dimensions",
                "mode.width": width,
                "mode.height": height,
                "align": 32,
                "enable_temporal_chunking": True,
                "force_unload": True,
                "device": "cuda",
                "precision": "fp16",
            },
        }
        w["32"] = {
            "class_type": "LTXVConcatAVLatent",
            "inputs": {"video_latent": ["31", 0], "audio_latent": ["30", 1]},
        }
        w["33"] = {
            "class_type": "ManualSigmas",
            "inputs": {"sigmas": "0.9035, 0.6316, 0.3158, 0.0000"},
        }
        # A high-resolution first-frame condition must match the refined video latent.
        w["37"] = json.loads(json.dumps(w["9"]))
        w["37"]["inputs"].update(width=width, height=height)
        w["38"] = {
            "class_type": "BasicGuider",
            "inputs": {"model": ["21", 0], "conditioning": ["37", 0]},
        }
        w["34"] = {
            "class_type": "SamplerCustomAdvanced",
            "inputs": {
                "noise": ["10", 0],
                "guider": ["38", 0],
                "sampler": ["12", 0],
                "sigmas": ["33", 0],
                "latent_image": ["32", 0],
            },
        }
        w["35"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["34", 0]}}
        w["36"] = {
            "class_type": "LTXVConcatAVLatent",
            "inputs": {"video_latent": ["35", 0], "audio_latent": ["30", 1]},
        }
        w["15"]["inputs"]["samples"] = ["36", 0]
        w["16"]["inputs"]["samples"] = ["36", 0]
    return w


def validate_prompt(text):
    names = ("integrated_multimodal_description:", "overall_soundscape:", "non_diegetic_music:")
    positions = [text.find(n) for n in names]
    if any(i < 0 for i in positions) or positions != sorted(positions) or "[Shot 1]" not in text:
        raise H3Error("提示词需要按指南写完整三段，并保留 [Shot 1]。")
    for i, pos in enumerate(positions):
        end = positions[i + 1] if i + 1 < len(positions) else len(text)
        if not text[pos + len(names[i]) : end].strip():
            raise H3Error("提示词段落不能为空。")
    if text.count("<d>") != text.count("</d>"):
        raise H3Error("台词标签没有闭合。")
    return text


def ensure_empty_queue(comfy):
    q = comfy.call("/queue")
    if not isinstance(q.get("queue_running"), list) or not isinstance(q.get("queue_pending"), list):
        raise H3Error("未取得可靠的队列状态，停止操作。")
    if q["queue_running"] or q["queue_pending"]:
        raise H3Error("队列还有其他任务，停止操作。")


def validate_graph(comfy, w):
    info = comfy.call("/object_info")
    for key, n in w.items():
        spec = info.get(n["class_type"])
        if not spec:
            raise H3Error("缺少工作流节点：" + n["class_type"])
        for group in ("required", "optional"):
            for name, option in spec.get("input", {}).get(group, {}).items():
                if (
                    group == "required"
                    and name not in n["inputs"]
                    and not any(k.startswith(name + ".") for k in n["inputs"])
                ):
                    raise H3Error("工作流缺少必要参数：" + n["class_type"] + "." + name)
                if (
                    name in n["inputs"]
                    and isinstance(option[0], list)
                    and n["inputs"][name] not in option[0]
                ):
                    raise H3Error("节点参数或模型不可用：" + name)


def upload(comfy, image):
    path = Path(image)
    if path.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp") or not path.is_file():
        raise H3Error("首帧需要是本机 PNG、JPEG 或 WebP 图片。")
    if path.stat().st_size > 32 * 1024**2:
        raise H3Error("首帧图片超过 32MB，请先缩小。")
    boundary = uuid.uuid4().hex
    filename = uuid.uuid4().hex + path.suffix.lower()
    body = (
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="image"; filename="{filename}"\r\n'
            "Content-Type: application/octet-stream\r\n\r\n"
        ).encode()
        + path.read_bytes()
        + f"\r\n--{boundary}--\r\n".encode()
    )
    result = comfy.call(
        "/upload/image", body, headers={"Content-Type": "multipart/form-data; boundary=" + boundary}
    )
    name = result["name"]
    sub = result.get("subfolder", "")
    return (sub + "/" if sub else "") + name


def poll(comfy, pid, timeout=7200, clock=time.monotonic, sleep=time.sleep):
    start = clock()
    last = None
    unknown_since = None
    last_notice = start
    while True:
        history = comfy.call("/history/" + urllib.parse.quote(pid))
        if pid in history:
            item = history[pid]
            status = item.get("status", {})
            if status.get("completed") and status.get("status_str") == "success":
                return item
            errors = [m[1] for m in status.get("messages", []) if m and m[0] == "execution_error"]
            if any(
                "out of memory" in str(e.get("exception_message", "")).lower()
                or "OutOfMemoryError" in str(e.get("exception_type", ""))
                for e in errors
            ):
                raise OOM("CUDA 显存不足。")
            raise H3Error("生成失败；详细报错保存在实例日志。")
        q = comfy.call("/queue")
        ids = [row[1] for key in ("queue_running", "queue_pending") for row in q.get(key, [])]
        if pid not in ids:
            unknown_since = unknown_since or clock()
            if clock() - unknown_since >= 120:
                raise H3Error("任务状态未知；保留记录，禁止重复提交。")
        else:
            unknown_since = None
        if clock() - last_notice >= 45:
            say("生成中，请稍候", clock() - start, "…")
            last_notice = clock()
        if clock() - start > timeout:
            raise H3Error("等待超时；用 wait 恢复当前任务，禁止重新提交。")
        sleep(10)


def oom_attempts(attempt, restart, size):
    try:
        return attempt(size, 0)
    except OOM:
        say("显存不足，重启服务清理显存，原参数重试一次", mark="…")
    restart()
    try:
        return attempt(size, 1)
    except OOM:
        pass
    # One resolution downgrade only, retaining the orientation.
    lower = {"hd": "landscape", "landscape": "small-landscape", "portrait": "small-portrait"}.get(
        size
    )
    if not lower:
        raise H3Error("重启后仍显存不足，已到最低预设；停止重试。")
    say("仍显存不足，分辨率降低一档后最后重试一次", mark="…")
    restart()
    try:
        return attempt(lower, 2)
    except OOM:
        raise H3Error("三次尝试仍显存不足，已停止；请选更短视频或更大显存。")


def save_video(comfy, remote, item, record, record_path, out):
    files = item.get("outputs", {}).get("18", {}).get("images", []) + item.get("outputs", {}).get(
        "18", {}
    ).get("videos", [])
    files = [
        v
        for v in files
        if v.get("filename", "").lower().endswith(".mp4") and v.get("type", "output") == "output"
    ]
    if not files:
        raise H3Error("任务结束但没有找到 MP4，已保留任务记录。")
    f = files[0]
    relative = "/".join(x for x in [f.get("subfolder", ""), f["filename"]] if x)
    meta = remote.call("hash", {"relative": relative})
    target = out / (record["client_id"] + ".mp4")
    part = target.with_suffix(".mp4.part")
    record.update(remote_output=relative, remote_sha256=meta["sha256"], status="downloading")
    write_json(record_path, record)
    if not (
        target.is_file()
        and target.stat().st_size == meta["bytes"]
        and digest(target) == meta["sha256"]
    ):
        comfy.download(relative, part)
        if part.stat().st_size != meta["bytes"] or digest(part) != meta["sha256"]:
            raise H3Error("远端与本机文件散列不一致，未标记完成、未自动关机；用 wait 重下。")
        part.replace(target)
    record.update(
        status="saved",
        local_file=str(target),
        sha256=meta["sha256"],
        bytes=meta["bytes"],
        downloaded_at=time.time(),
    )
    write_json(record_path, record)
    say("下载与远端散列核对通过：" + str(target))
    return target


def confirm_shutdown(send, probe, sleep=None, attempts=18):
    sleep = sleep or time.sleep
    send()
    misses = 0
    for _ in range(attempts):
        sleep(10)
        result = probe()
        if result == "unreachable":
            misses += 1
            if misses == 2:
                return "已发关机命令，SSH 已断开；请去控制台确认“已关机”。"
        elif result == "connected":
            misses = 0
        else:
            raise H3Error("SSH 状态无法确认；请去控制台手动关机并核对状态。")
    raise H3Error("没关掉：发出命令后仍能连接，请去控制台手动关机。")


def shutdown(remote):
    # Only the current skill service may be stopped; other queued work prevents shutdown.
    remote.call("shutdown-ready")

    def send():
        p = remote.execute(
            "nohup sh -c 'sleep 3; /usr/bin/shutdown' >/dev/null 2>&1 < /dev/null &", raw=True
        )
        if p.returncode != 0:
            raise H3Error("关机命令发送失败，请去控制台手动关机。")

    message = confirm_shutdown(send, remote.probe_connection)
    say(message)
    return message


def cost_summary(record, end=None):
    end = time.time() if end is None else end
    start = record["started_at"]
    seconds = max(0, end - start)
    rate = record.get("hourly_rate")
    result = {
        "elapsed_seconds": round(seconds),
        "estimated": True,
        "timing_basis": record.get("timing_basis"),
    }
    if rate is not None:
        result.update(hourly_rate=rate, estimated_cost=round(seconds / 3600 * rate, 4))
    return result


def new_record(remote, args):
    probe = remote.call("probe")
    now = time.time()
    started = args.booted_at if args.booted_at is not None else now - probe["uptime_seconds"]
    if started > now:
        raise H3Error("开机时间晚于当前时间，请核对。")
    billing = LOCAL / "billing.json"
    rate = args.hourly_rate
    if rate is None and billing.exists():
        rate = json.loads(billing.read_text(encoding="utf-8")).get(remote.identity)
    elif rate is not None:
        prefs = json.loads(billing.read_text(encoding="utf-8")) if billing.exists() else {}
        prefs[remote.identity] = rate
        write_json(billing, prefs)
    return {
        "client_id": uuid.uuid4().hex,
        "target": remote.identity,
        "started_at": started,
        "timing_basis": (
            "用户提供的开机时间"
            if args.booted_at is not None
            else "容器启动时长推算，可能不同于平台开机与计费"
        ),
        "hourly_rate": rate,
        "status": "prepared",
        "attempts": [],
        "auto_shutdown": not getattr(args, "defer_shutdown", False),
    }


def make(remote, args, record=None):
    prompt = validate_prompt(Path(args.prompt_file).read_text(encoding="utf-8-sig"))
    if not args.approved:
        raise H3Error("需要提示词确认，或用户本次明确授权直接跑；取得授权后再加 --approved 生成。")
    strength = validate_lora(
        args.mode, getattr(args, "lora", None), getattr(args, "lora_strength", None)
    )
    report = remote.call("doctor")
    if report.get("cpu_only"):
        raise H3Error(NO_GPU)
    say(f'显卡：{report["gpu"]}，{report["vram_bytes"]/GIB:.1f}GiB；CUDA 运算和内存检查通过')
    if args.size == "hd":
        say("高清模式更慢，可能显存不足，最多按规则重试两次", mark="…")
    remote.call("start")
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    record = record or new_record(remote, args)
    record_path = out / (record["client_id"] + ".json")
    record.update(
        prompt=prompt,
        mode=args.mode,
        seconds=args.seconds,
        size=args.size,
        seed=args.seed,
        source_image_sha256=digest(args.image) if args.image else None,
    )
    if getattr(args, "lora", None) is not None:
        record.update(lora=args.lora, lora_strength=strength)
    write_json(record_path, record)
    holder = {"tunnel": None, "comfy": None, "image": None}

    def connect():
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
        holder["tunnel"] = Tunnel(remote).__enter__()
        holder["comfy"] = Comfy(holder["tunnel"])

    def restart():
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
            holder["tunnel"] = None
        remote.call("restart")
        connect()

    def attempt(size, index):
        c = holder["comfy"]
        ensure_empty_queue(c)
        if args.image and holder["image"] is None:
            holder["image"] = upload(c, args.image)
        actual = size
        if size.startswith("small-"):
            actual = "portrait" if size == "small-portrait" else "landscape"
        w = build_workflow(
            prompt,
            args.seconds,
            actual,
            args.mode,
            holder["image"],
            args.seed,
            record["client_id"],
            getattr(args, "lora", None),
            getattr(args, "lora_strength", None),
        )
        if size.startswith("small-"):
            width, height = (480, 864) if actual == "portrait" else (864, 480)
            if args.mode == "fast-hd":
                w["31"]["inputs"].update({"mode.width": width, "mode.height": height})
                w["37"]["inputs"].update(width=width, height=height)
            else:
                w["9"]["inputs"].update(width=width, height=height)
        validate_graph(c, w)
        task = {
            "index": index,
            "size": size,
            "workflow": w,
            "client_id": uuid.uuid4().hex,
            "status": "submitting",
        }
        record["attempts"].append(task)
        record.update(status="submitting", prompt_id=None)
        write_json(record_path, record)
        # No automatic POST retry: persist the uncertainty before sending.
        response = c.call("/prompt", {"prompt": w, "client_id": task["client_id"]})
        pid = response.get("prompt_id")
        if not pid:
            raise H3Error("没有收到任务编号，状态未知；禁止重复提交。")
        task.update(prompt_id=pid, status="running")
        record.update(prompt_id=pid, status="running")
        write_json(record_path, record)
        say("任务已提交，等待生成", mark="…")
        try:
            item = poll(c, pid, args.timeout)
        except OOM:
            task["status"] = "oom"
            record["status"] = "oom"
            write_json(record_path, record)
            raise
        task["status"] = "completed"
        return save_video(c, remote, item, record, record_path, out)

    try:
        connect()
        target = oom_attempts(attempt, restart, args.size)
    finally:
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
    try:
        if record.get("auto_shutdown", True):
            record["shutdown_message"] = shutdown(remote)
            record["ssh_disconnected_at"] = time.time()
        else:
            say("本条已下载校验；整批任务继续，最后统一执行 shutdown", mark="…")
    finally:
        record["cost"] = cost_summary(record)
        write_json(record_path, record)
        display_cost(record)
    return target


def display_cost(record):
    cost = record.get("cost") or cost_summary(record)
    message = f'本轮计时 {cost["elapsed_seconds"]/60:.1f} 分钟'
    if "estimated_cost" in cost:
        message += f'，估算花费 {cost["estimated_cost"]:.2f}（与每小时单价同币种）'
    else:
        message += "，未提供每小时单价，未计算金额"
    say(message + "；估算，以平台账单为准")


def wait_record(remote, args):
    path = Path(args.record).resolve()
    record = json.loads(path.read_text(encoding="utf-8"))
    if record["target"] != remote.identity:
        raise H3Error("任务绑定的连接与当前连接不同，未查询实例。")
    if (
        record.get("status") == "saved"
        and record.get("local_file")
        and Path(record["local_file"]).is_file()
        and digest(record["local_file"]) == record["sha256"]
    ):
        say("本机结果已存在且散列一致：" + record["local_file"])
        if record.get("auto_shutdown", True) and not record.get("ssh_disconnected_at"):
            try:
                record["shutdown_message"] = shutdown(remote)
                record["ssh_disconnected_at"] = time.time()
            finally:
                record["cost"] = cost_summary(record)
                write_json(path, record)
                display_cost(record)
        return
    if not record.get("prompt_id"):
        raise H3Error("提交状态未知，没有确定任务编号；需核对队列和历史，不能重发。")
    with Tunnel(remote) as tunnel:
        c = Comfy(tunnel)
        item = poll(c, record["prompt_id"], args.timeout)
        save_video(c, remote, item, record, path, path.parent)
    try:
        if record.get("auto_shutdown", True):
            record["shutdown_message"] = shutdown(remote)
            record["ssh_disconnected_at"] = time.time()
        else:
            say("本条恢复下载校验完成；整批任务继续，最后统一执行 shutdown", mark="…")
    finally:
        record["cost"] = cost_summary(record)
        write_json(path, record)
        display_cost(record)


def dry_run(args):
    action = args.command
    say("预演：不会连接实例、保存凭据、安装软件或提交生成", mark="…")
    if action == "upload-lora":
        say(
            "预演：流式上传 LoRA 到已安装服务的 models/loras，核对 manifest SHA-256；不覆盖异散列文件",
            mark="…",
        )
        return
    if action == "save-ssh":
        say("预演：打开私密输入窗口，将登录信息和密码存入系统凭据库", mark="…")
        return
    if action == "local-check":
        say("预演：检查本机 Python、SSH 与私密输入助手，不读凭据、不联网", mark="…")
        return
    if action in ("all", "install"):
        for command in ("probe", "install", "cpu-check"):
            say(
                '预演远端：python3 "$PACKAGE/scripts/remote.py" '
                + command
                + " --request-b64 <参数>",
                mark="…",
            )
        say("软件按两盘余量选择，模型、输入和输出放数据盘；下载逐个核对大小及 SHA-256")
        say("ComfyUI 0.33.0（锁定），PyTorch 2.11.0＋cu130")
        say("下载扩散模型 20.97GB，ModelScope，已完成 63%（模拟）", 20, "…")
        say("四个核心模型大小和 SHA-256 全部通过（模拟）")
        say("CPU 节点和模型可见性通过，未做真实显卡生成（模拟）")
    if action in ("all", "make"):
        for command in ("doctor", "start"):
            say(
                '预演远端：python3 "$PACKAGE/scripts/remote.py" '
                + command
                + " --request-b64 <参数>",
                mark="…",
            )
        say("显卡：RTX 5090，32GB；CUDA 实际运算与内存检查通过（模拟）", 4)
        if args.approved:
            say("已传入提示词确认或本次明确直接跑授权；按三段提示词生成（预演）", mark="…")
        else:
            say("默认先展示三段提示词并确认；本次明确授权直接跑也可使用 --approved", mark="…")
        if args.prompt_file:
            prompt = validate_prompt(Path(args.prompt_file).read_text(encoding="utf-8-sig"))
            wf = build_workflow(
                prompt,
                args.seconds,
                args.size,
                args.mode,
                "approved-input.png" if args.image else None,
                args.seed,
                lora=args.lora,
                lora_strength=args.lora_strength,
            )
            say(f"工作流已构建：{len(wf)} 节点，24fps，{frame_count(args.seconds)} 帧（未提交）")
        say("预演远端操作：通过受控服务连接提交工作流，记录任务编号，等待结果", mark="…")
        say("下载到本机项目文件夹并核对远端和本机 SHA-256（模拟）")
    if action in ("all", "make") and getattr(args, "defer_shutdown", False):
        say("本条下载核对后保持开机；批次全部核对完成后必须显式运行 shutdown", mark="…")
    if action == "shutdown" or (
        action in ("all", "make") and not getattr(args, "defer_shutdown", False)
    ):
        say(
            "预演远端：nohup sh -c 'sleep 3; /usr/bin/shutdown' >/dev/null 2>&1 < /dev/null &",
            mark="…",
        )
        say("预演远端：true；连续两次无法连接才报告 SSH 断开", mark="…")
        say("已发关机命令，SSH 已断开；请去控制台确认“已关机”（模拟）")
        rate = getattr(args, "hourly_rate", None)
        if rate is not None:
            say(f"模拟计时 1.5 小时，估算花费 {rate*1.5:.2f}；估算，以平台账单为准")
    if action in ("doctor", "models", "cpu-check", "wait", "resume-install"):
        say(
            '预演远端：python3 "$PACKAGE/scripts/remote.py" '
            + ({"wait": "hash", "resume-install": "job"}.get(action, action))
            + " --request-b64 <参数>",
            mark="…",
        )
        if action == "wait":
            say("预演：查询已记录任务，下载散列核对后按记录继续关机", mark="…")


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        say("命令参数未识别，请用 --help 查看用法。", mark="✗")
        raise SystemExit(2)


def parser():
    p = SafeParser(description="leoliu-h3-cloud：安装、检查、生成、下载与关机")
    sub = p.add_subparsers(dest="command", required=True)
    for name in (
        "local-check",
        "save-ssh",
        "install",
        "models",
        "doctor",
        "cpu-check",
        "make",
        "all",
        "wait",
        "shutdown",
        "resume-install",
        "upload-lora",
        "_askpass",
    ):
        s = sub.add_parser(name)
        s.add_argument("--dry-run", action="store_true")
        if name in ("install", "models", "all"):
            s.add_argument("--data-dir")
            s.add_argument("--software-dir")
            s.add_argument("--mode", choices=("standard", "turbo", "fast-hd"), default="standard")
        if name in ("make", "all"):
            s.add_argument("--prompt-file")
            s.add_argument(
                "--approved", action="store_true", help="已确认提示词，或用户本次明确授权直接跑"
            )
            s.add_argument("--image")
            s.add_argument("--size", choices=SIZES, default="landscape")
            s.add_argument("--seconds", type=int, choices=(5, 10, 15), default=5)
            if name == "make":
                s.add_argument(
                    "--mode", choices=("standard", "turbo", "fast-hd"), default="standard"
                )
            s.add_argument("--lora", help="models/loras 下的纯 ASCII 文件名")
            s.add_argument("--lora-strength", type=float, help="默认 1.0；须与 --lora 同用")
            s.add_argument("--seed", type=int, default=42)
            s.add_argument("--out", default=str(Path.cwd() / "h3-output"))
            s.add_argument("--timeout", type=int, default=7200)
            s.add_argument("--hourly-rate", type=float)
            s.add_argument("--booted-at", type=float, help="用户提供的开机 Unix 时间")
            s.add_argument(
                "--defer-shutdown",
                action="store_true",
                help="整批任务专用：本条校验后保持开机，整批结束显式运行 shutdown",
            )
        if name == "upload-lora":
            s.add_argument("--file")
            s.add_argument("--name")
            s.add_argument("--sha256")
        if name == "wait":
            s.add_argument("--record")
            s.add_argument("--timeout", type=int, default=7200)
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        if args.command in ("make", "all"):
            validate_lora(args.mode, args.lora, args.lora_strength)
        if args.dry_run:
            dry_run(args)
            return 0
        if args.command == "_askpass":
            value = keychain_get()["password"]
            sys.stdout.write(value + "\n")
            return 0
        if sys.platform not in ("darwin", "win32"):
            raise H3Error("本机控制端支持 macOS 和原生 Windows 10/11；WSL/Linux 本机端尚未适配。")
        if args.command == "local-check":
            with lease():
                result = local.local_check(LOCAL)
            say("本机依赖检查通过；未读取凭据、连接云实例或验证显卡生成")
            print(json.dumps(result, ensure_ascii=False))
            return 0
        if args.command == "save-ssh":
            with lease():
                local.local_check(LOCAL)
                connection = parse_login(
                    dialog("请粘贴控制台的 SSH 登录指令（不会写入文件或聊天）")
                )
                connection["password"] = dialog(
                    "请粘贴实例密码（仅保存到" + local.credential_label() + "）", True
                )
                keychain_set(connection)
                say("登录信息与密码已保存到" + local.credential_label())
            return 0
        if args.command in ("make", "all"):
            if not args.prompt_file:
                raise H3Error("需要 --prompt-file，先按提示词指南准备三段内容。")
            validate_prompt(Path(args.prompt_file).read_text(encoding="utf-8-sig"))
            if args.hourly_rate is not None and (
                not math.isfinite(args.hourly_rate) or args.hourly_rate < 0
            ):
                raise H3Error("每小时单价需要是非负的有限数字。")
        if args.command == "upload-lora":
            validate_lora_upload(args)
        with lease():
            remote = Remote()
            if args.command == "all":
                # Approval covers prompt acceptance or explicit direct-run delegation; never infer it from installation.
                remote.sync()
                record = new_record(remote, args)
                remote.task("install", vars(args))
                if not args.approved:
                    say("安装完成；提示词确认后运行 make，当前实例仍在计费", mark="…")
                    return 0
                if remote.call("doctor").get("cpu_only"):
                    say(NO_GPU, mark="…")
                    return 0
                make(remote, args, record)
            elif args.command == "install":
                remote.sync()
                r = remote.task("install", vars(args))
                say(NO_GPU if r.get("cpu_only") else "安装完成，可检查显卡并生成")
            elif args.command == "models":
                remote.task("models", vars(args))
                say("模型下载核对完成")
            elif args.command == "resume-install":
                rec = json.loads((LOCAL / "last-job.json").read_text(encoding="utf-8"))
                if rec["target"] != remote.identity:
                    raise H3Error("安装任务绑定的连接不同，已停止。")
                remote.wait_task(rec["job"])
                say("原安装任务已完成")
            elif args.command == "doctor":
                r = remote.call("doctor")
                say(
                    NO_GPU
                    if r.get("cpu_only")
                    else f'显卡：{r["gpu"]}，{r["vram_bytes"]/GIB:.1f}GiB；CUDA 运算和内存检查通过'
                )
            elif args.command == "cpu-check":
                remote.task("cpu-check", {})
                say("CPU 自检通过，未提交生成")
            elif args.command == "upload-lora":
                upload_lora(remote, args)
            elif args.command == "make":
                make(remote, args)
            elif args.command == "wait":
                if not args.record:
                    raise H3Error("需要 --record 指定本机任务记录。")
                wait_record(remote, args)
            elif args.command == "shutdown":
                shutdown(remote)
        return 0
    except (H3Error, OSError, ValueError, KeyError) as e:
        say(
            str(e) if isinstance(e, H3Error) else "本机操作未通过，请检查参数和本机文件。", mark="✗"
        )
        return 1
    except KeyboardInterrupt:
        say("已停止本机等待；实例可能仍在计费，请恢复任务或在控制台关机。", mark="✗")
        return 130


if __name__ == "__main__":
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="backslashreplace")
    sys.exit(main())
