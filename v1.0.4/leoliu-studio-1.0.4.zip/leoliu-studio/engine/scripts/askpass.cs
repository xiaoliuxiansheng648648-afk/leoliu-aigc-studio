// Windows OpenSSH requires an executable SSH_ASKPASS, not a .sh/.cmd file.
// Only interpreter/script paths are in the environment. Credentials stay in the OS vault.
using System;
using System.Diagnostics;
using System.IO;
using System.Text;

class H3Askpass {
    static string Quote(string value) {
        // Windows command-line quoting, including trailing backslashes and embedded quotes.
        var output = new StringBuilder("\"");
        int slashes = 0;
        foreach (char c in value) {
            if (c == '\\') { slashes++; continue; }
            if (c == '"') { output.Append('\\', slashes * 2 + 1); output.Append(c); }
            else { output.Append('\\', slashes); output.Append(c); }
            slashes = 0;
        }
        output.Append('\\', slashes * 2); output.Append('"');
        return output.ToString();
    }
    static int Main() {
        try {
            string python = Environment.GetEnvironmentVariable("H3_PYTHON");
            string entry = Environment.GetEnvironmentVariable("H3_ENTRY");
            if (!File.Exists(python) || !File.Exists(entry)) return 1;
            var info = new ProcessStartInfo(python, Quote(entry) + " _askpass");
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            info.StandardOutputEncoding = new UTF8Encoding(false);
            using (var process = Process.Start(info)) {
                var errors = process.StandardError.ReadToEndAsync();
                string answer = process.StandardOutput.ReadToEnd();
                process.WaitForExit();
                if (process.ExitCode != 0) return 1;
                Console.OutputEncoding = new UTF8Encoding(false);
                Console.Write(answer);
                return 0;
            }
        } catch { return 1; }
    }
}
