# ASCII source supports Windows PowerShell 5.1 without encoding-dependent Chinese literals.
param([string]$Message, [string]$Hidden = '0')
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'leoliu-h3-cloud'
    $form.Size = New-Object System.Drawing.Size(640, 210)
    $form.StartPosition = 'CenterScreen'
    $form.TopMost = $true
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Message
    $label.SetBounds(20, 15, 590, 45)
    $inputBox = New-Object System.Windows.Forms.TextBox
    $inputBox.SetBounds(20, 65, 580, 28)
    $inputBox.UseSystemPasswordChar = ($Hidden -eq '1')
    $save = New-Object System.Windows.Forms.Button
    $save.Text = 'Save'
    $save.SetBounds(400, 115, 90, 30)
    $save.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = 'Cancel'
    $cancel.SetBounds(510, 115, 90, 30)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $form.Controls.AddRange(@($label, $inputBox, $save, $cancel))
    $form.AcceptButton = $save
    $form.CancelButton = $cancel
    $form.Add_Shown({ [void]$inputBox.Focus() })
    $result = $form.ShowDialog()
    if ($result -ne [System.Windows.Forms.DialogResult]::OK -or $inputBox.Text.Length -eq 0) {
        $form.Dispose(); exit 1
    }
    $encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($inputBox.Text))
    $inputBox.Clear()
    $form.Dispose()
    [Console]::Write($encoded)
    exit 0
} catch { exit 1 }
