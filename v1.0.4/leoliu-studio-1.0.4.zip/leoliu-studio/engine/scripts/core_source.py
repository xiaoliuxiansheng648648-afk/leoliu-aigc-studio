"""Replace only hash-verified core files, retaining custom nodes and user directories."""

import json
import os
import shutil
from pathlib import Path
from common import COMMIT, ARCHIVE_SHA, H3Error, digest, write_json


def verify_source(core, hashes):
    for name, sha in hashes.items():
        path = core / name
        if not path.is_file() or path.is_symlink() or digest(path) != sha:
            raise H3Error("已安装源码被改动，请使用新软件目录。")


def finish_swap(soft):
    """Recover an interrupted directory swap before inspecting any installation receipts."""
    journal = soft / "state/core-swap.json"
    if not journal.exists():
        return
    record = json.loads(journal.read_text())
    core, stage, backup = (soft / name for name in ("ComfyUI", ".core-next", ".core-old"))
    if stage.exists():
        if core.exists():
            core.rename(backup)
        stage.rename(core)
    verify_source(core, record["hashes"])
    write_json(soft / "state/source-hashes.json", record["hashes"])
    write_json(soft / "state/core-source.json", record["source"])
    if backup.exists():
        shutil.rmtree(backup)
    journal.unlink()


def ensure_core(soft, archive, extract, before_replace, event):
    soft = Path(soft)
    finish_swap(soft)
    core = soft / "ComfyUI"
    source_lock = soft / "state/source-hashes.json"
    marker = soft / "state/core-source.json"
    receipt = marker if marker.exists() else soft / "state/installed.json"
    previous = json.loads(receipt.read_text()) if receipt.exists() else {}
    hashes = json.loads(source_lock.read_text()) if source_lock.exists() else {}
    if source_lock.exists():
        verify_source(core, hashes)
        if not previous.get("commit"):
            raise H3Error("已有源码缺少核心版本收据，请使用新软件目录。")
        if previous["commit"] == COMMIT:
            if previous.get("archive_sha256") != ARCHIVE_SHA:
                raise H3Error("已有核心收据与源码包不符，请使用新软件目录。")
            return False
    elif core.exists():
        raise H3Error("已有源码缺少散列记录，请使用新软件目录。")
    before_replace()
    stage = soft / ".core-next"
    if stage.exists():
        shutil.rmtree(stage)
    stage.mkdir()
    try:
        extract(archive, stage)
        new_hashes = {str(p.relative_to(stage)): digest(p) for p in stage.rglob("*") if p.is_file()}
        if source_lock.exists():
            # Keep everything outside the previous core inventory, including node commit markers.
            for path in core.rglob("*"):
                name = str(path.relative_to(core))
                if name in hashes or "__pycache__" in path.parts:
                    continue
                target = stage / name
                if path.is_dir() and not path.is_symlink():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                if name in new_hashes:
                    raise H3Error("新核心路径已有用户文件，请使用新软件目录。")
                target.parent.mkdir(parents=True, exist_ok=True)
                if path.is_symlink():
                    target.symlink_to(os.readlink(path))
                else:
                    shutil.copy2(path, target)
        source = {"commit": COMMIT, "archive_sha256": ARCHIVE_SHA}
        write_json(soft / "state/core-swap.json", {"source": source, "hashes": new_hashes})
        finish_swap(soft)
    except BaseException:
        if not (soft / "state/core-swap.json").exists():
            shutil.rmtree(stage, ignore_errors=True)
        raise
    if previous.get("commit"):
        event(f'核心从 {previous["commit"][:7]} 升到 {COMMIT[:7]}')
    return True
