#!/usr/bin/env python3
"""Scan distributable text and nested source archives, without reading private configuration."""
import argparse
import ipaddress
import json
import re
import tarfile
from pathlib import Path
from common import ROOT, say


def scan(root=ROOT):
    forbidden = [
        (
            "provider",
            r"(?i)"
            + "".join(("auto", "dl"))
            + "|"
            + "".join(("see", "tacloud"))
            + "|"
            + "".join(("aiManga", "DirectorWorkbench"))
            + "|"
            + "".join(("h3_", "pro_bridge"))
            + r"|pro-[0-9a-f]{8,}",
        ),
        ("private-source-author", "".join(("一", "十", "七")) + "|" + "".join(("Yi", "shiqi"))),
        ("private-key", r"-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY-----"),
        ("literal-target-config", r'["\']host["\']\s*:\s*["\'][^"\']+["\']'),
    ]
    hits = []
    checked = 0
    version_literals = []

    def inspect(name, data):
        nonlocal checked
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return
        checked += 1
        for rule, pattern in forbidden:
            if re.search(pattern, text):
                hits.append({"file": name, "rule": rule})
        # Detect addresses in connection/URL contexts, not four-component package versions.
        for match in re.finditer(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", text):
            token = match.group()
            try:
                ip = ipaddress.ip_address(token)
            except ValueError:
                continue
            if ip.is_loopback or ip.is_unspecified:
                continue
            context = text[max(0, match.start() - 32) : match.end() + 20]
            if re.search(r"https?://|@|\bhost\b|\bhostname\b|ssh ", context):
                hits.append({"file": name, "rule": "address-in-connection-context"})
            else:
                version_literals.append({"file": name, "literal": token})

    for path in sorted(Path(root).rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        name = str(path.relative_to(root))
        if name.endswith(".tar.gz"):
            with tarfile.open(path) as archive:
                for member in archive.getmembers():
                    if member.isfile():
                        inspect(name + "::" + member.name, archive.extractfile(member).read())
        else:
            inspect(name, path.read_bytes())
    return {
        "text_files_checked": checked,
        "hits": hits,
        "true_hit_count": len(hits),
        "non_address_numeric_literals_reviewed": version_literals,
        "scope": "分发文件及内嵌源码；公开下载域名、回环地址、测试保留域名不算真实实例信息；不读取钥匙串",
    }


def main():
    parser = argparse.ArgumentParser(description="分发包敏感信息检查")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    if args.dry_run:
        say("预演：只扫描本包文本及内嵌源码，不连接实例", mark="…")
        return 0
    result = scan()
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        say(
            f'包扫描：{result["text_files_checked"]}个文本文件，真实敏感信息命中{result["true_hit_count"]}',
            mark="✗" if result["hits"] else "✓",
        )
    return int(bool(result["hits"]))


if __name__ == "__main__":
    raise SystemExit(main())
