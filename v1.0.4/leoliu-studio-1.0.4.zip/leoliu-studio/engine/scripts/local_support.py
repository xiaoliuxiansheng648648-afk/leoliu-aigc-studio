"""Local macOS/Windows adapters. No cloud operations or third-party Python packages."""

import base64
import contextlib
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

from common import H3Error

SERVICE = "leoliu-h3-cloud-connection"
SCRIPTS = Path(__file__).resolve().parent


def local_dir():
    if sys.platform == "win32":
        return (
            Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData/Local")))
            / "leoliu-h3-cloud"
        )
    return Path.home() / "Library/Application Support/leoliu-h3-cloud"


def credential_label():
    return "Windows 凭据管理器" if sys.platform == "win32" else "Mac 钥匙串"


def windows_credentials():
    # Load lazily so importing the CLI (including --dry-run) never needs Win32/POSIX APIs.
    from ctypes import wintypes as w

    class Credential(ctypes.Structure):
        _fields_ = [
            ("Flags", w.DWORD),
            ("Type", w.DWORD),
            ("TargetName", w.LPWSTR),
            ("Comment", w.LPWSTR),
            ("LastWritten", w.FILETIME),
            ("CredentialBlobSize", w.DWORD),
            ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
            ("Persist", w.DWORD),
            ("AttributeCount", w.DWORD),
            ("Attributes", ctypes.c_void_p),
            ("TargetAlias", w.LPWSTR),
            ("UserName", w.LPWSTR),
        ]

    api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    api.CredReadW.argtypes = [
        w.LPCWSTR,
        w.DWORD,
        w.DWORD,
        ctypes.POINTER(ctypes.POINTER(Credential)),
    ]
    api.CredReadW.restype = w.BOOL
    api.CredWriteW.argtypes = [ctypes.POINTER(Credential), w.DWORD]
    api.CredWriteW.restype = w.BOOL
    api.CredFree.argtypes = [ctypes.c_void_p]
    api.CredFree.restype = None
    api.CredDeleteW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD]
    api.CredDeleteW.restype = w.BOOL
    return api, Credential


def windows_get(service=SERVICE):
    api, Credential = windows_credentials()
    pointer = ctypes.POINTER(Credential)()
    if not api.CredReadW(service, 1, 0, ctypes.byref(pointer)):
        raise H3Error("尚未保存或无法读取登录信息；请用 save-ssh 打开私密输入窗口。")
    try:
        value = pointer.contents
        return json.loads(
            ctypes.string_at(value.CredentialBlob, value.CredentialBlobSize).decode("utf-8")
        )
    finally:
        api.CredFree(pointer)


def windows_set(value, service=SERVICE):
    raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
    if len(raw) > 2560:
        raise H3Error("登录信息超过 Windows 凭据长度限制，未保存。")
    api, Credential = windows_credentials()
    blob = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    item = Credential(
        Type=1,
        TargetName=service,
        UserName="leoliu-h3-cloud",
        CredentialBlobSize=len(raw),
        CredentialBlob=blob,
        Persist=2,
    )
    if not api.CredWriteW(ctypes.byref(item), 0):
        raise H3Error("Windows 凭据管理器保存未通过，未写入明文文件。")
    if windows_get(service) != value:
        raise H3Error("Windows 凭据管理器回读不一致，请重新保存。")


def credential_get():
    if sys.platform == "win32":
        return windows_get()
    p = subprocess.run(
        ["security", "find-generic-password", "-s", SERVICE, "-w"],
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if p.returncode:
        raise H3Error("尚未保存登录信息；请用 save-ssh 打开私密输入窗口。")
    raw = p.stdout.rstrip("\n")
    if raw and all(c in "0123456789abcdef" for c in raw) and len(raw) % 2 == 0:
        raw = bytes.fromhex(raw).decode("utf-8")
    return json.loads(raw)


def credential_set(value):
    if sys.platform == "win32":
        return windows_set(value)
    secret = json.dumps(value, ensure_ascii=False).encode("utf-8").hex()
    p = subprocess.run(
        ["security", "-i"],
        input=f"add-generic-password -U -a leoliu-h3-cloud -s {SERVICE} -X {secret}\n",
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if p.returncode or credential_get() != value:
        raise H3Error("钥匙串保存未通过；请允许 Mac 的钥匙串权限提示后重试。")


def powershell():
    path = shutil.which("powershell.exe")
    if not path:
        path = (
            Path(os.environ.get("SystemRoot", r"C:\Windows"))
            / "System32/WindowsPowerShell/v1.0/powershell.exe"
        )
        if not path.is_file():
            raise H3Error("未找到 Windows PowerShell 5.1，无法打开私密窗口。")
    return str(path)


def dialog(message, hidden=False):
    if sys.platform == "win32":
        p = subprocess.run(
            [
                powershell(),
                "-NoProfile",
                "-STA",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(SCRIPTS / "private_input.ps1"),
                message,
                "1" if hidden else "0",
            ],
            capture_output=True,
            **process_options(),
        )
        if p.returncode or not p.stdout.strip():
            raise H3Error("私密输入已取消或窗口无法打开，未保存。")
        return base64.b64decode(p.stdout.strip(), validate=True).decode("utf-8")
    script = (
        "display dialog "
        + json.dumps(message, ensure_ascii=False)
        + ' default answer "" '
        + ("with hidden answer " if hidden else "")
        + 'with title "leoliu-h3-cloud" buttons {"取消", "保存"} default button "保存"'
    )
    p = subprocess.run(
        ["osascript", "-e", script, "-e", "text returned of result"],
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if p.returncode or not p.stdout.strip():
        raise H3Error("私密输入已取消，未保存。")
    return p.stdout.strip()


@contextlib.contextmanager
def operation_lock(directory):
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / "operation.lock").open("a+b") as stream:
        if sys.platform == "win32":
            import msvcrt

            # msvcrt locks a byte range at the current position, which must exist.
            if stream.tell() == 0:
                stream.write(b"\0")
                stream.flush()
            stream.seek(0)
            try:
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise H3Error("另一个 leoliu-h3-cloud 操作正在进行，请等它结束。")
            try:
                yield
            finally:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            try:
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise H3Error("另一个 leoliu-h3-cloud 操作正在进行，请等它结束。")
            try:
                yield
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)


def process_options():
    if sys.platform == "win32":
        return {"creationflags": 0x08000000}  # CREATE_NO_WINDOW: force the askpass route.
    return {"start_new_session": True}


def ssh_executable():
    name = "ssh.exe" if sys.platform == "win32" else "ssh"
    path = None
    if sys.platform == "win32":
        for folder in ("System32", "Sysnative"):
            candidate = (
                Path(os.environ.get("SystemRoot", r"C:\Windows")) / folder / "OpenSSH/ssh.exe"
            )
            if candidate.is_file():
                path = str(candidate)
                break
    if not path:
        path = shutil.which(name)
    if not path:
        raise H3Error(
            "未找到 OpenSSH 客户端；Windows 请在系统“可选功能”安装 OpenSSH 客户端后重试。"
        )
    return path


def csharp_compiler():
    framework = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Microsoft.NET"
    for folder in ("Framework64", "Framework"):
        path = framework / folder / "v4.0.30319/csc.exe"
        if path.is_file():
            return str(path)
    raise H3Error(
        "未找到 Windows .NET Framework 4.x 编译器，无法准备 SSH 私密密码助手；请启用系统 .NET Framework 4.x。"
    )


def prepare_askpass(directory):
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    if sys.platform != "win32":
        path = directory / "askpass.sh"
        path.write_text(
            "#!/bin/sh\nexec "
            + shlex.quote(sys.executable)
            + " "
            + shlex.quote(str(SCRIPTS / "h3_cloud.py"))
            + " _askpass\n",
            encoding="utf-8",
        )
        path.chmod(0o700)
        return path
    source = SCRIPTS / "askpass.cs"
    version = hashlib.sha256(source.read_bytes()).hexdigest()[:16]
    path = directory / ("askpass-" + version + ".exe")
    if not path.is_file():
        temporary = path.with_suffix(".tmp.exe")
        p = subprocess.run(
            [csharp_compiler(), "/nologo", "/target:exe", "/out:" + str(temporary), str(source)],
            capture_output=True,
            **process_options(),
        )
        if p.returncode or not temporary.is_file():
            raise H3Error("SSH 私密密码助手编译失败；未连接实例或把密码写入文件。")
        temporary.replace(path)
    return path


def askpass_env(path):
    return dict(
        os.environ,
        SSH_ASKPASS=str(path),
        SSH_ASKPASS_REQUIRE="force",
        DISPLAY=":0",
        H3_PYTHON=sys.executable,
        H3_ENTRY=str(SCRIPTS / "h3_cloud.py"),
        PYTHONIOENCODING="utf-8",
        PYTHONUTF8="1",
    )


def local_check(directory):
    if sys.platform not in ("darwin", "win32"):
        raise H3Error("本机控制端支持 macOS 和原生 Windows 10/11；WSL/Linux 本机端尚未适配。")
    if sys.version_info < (3, 9):
        raise H3Error("本机需要 Python 3.9 或更高版本。")
    ssh = ssh_executable()
    if sys.platform == "win32":
        powershell()
    helper = prepare_askpass(directory)
    return {
        "platform": sys.platform,
        "python": sys.version.split()[0],
        "ssh": ssh,
        "askpass": str(helper),
        "credentials": credential_label(),
        "scope": "本机依赖检查；未读写凭据、连接云实例或验证显卡生成",
    }
