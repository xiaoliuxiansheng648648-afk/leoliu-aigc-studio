"""CPU-only synthetic first-frame, image and voice layout probe for the pinned T8 runtime."""

import argparse
import importlib
import json
import math
import sys
import types
from pathlib import Path


def validate_contract(record):
    origins = record.get("position_origins", {})
    first, target = origins.get("cond"), origins.get("video")
    if record.get("error") or record.get("route") != "native_concat":
        raise ValueError("混合布局契约未返回 native_concat，已停止提交。")
    if not all(type(value) in (int, float) and math.isfinite(value) for value in (first, target)):
        raise ValueError("混合布局缺少有效时间原点，已停止提交。")
    if not math.isclose(first, target, rel_tol=0, abs_tol=1e-6):
        raise ValueError("混合布局首帧和目标视频时间原点不一致，已停止提交。")


def probe(core):
    sys.path.insert(0, str(core))
    package = types.ModuleType("leoliu_t8_contract")
    package.__path__ = [str(core / "custom_nodes/comfyui-minimax-h3-audio-T8/h3_t8")]
    sys.modules[package.__name__] = package
    conditioning = importlib.import_module(package.__name__ + ".conditioning")
    import torch

    keyframe = {"resolved_frame_index": 0, "latent": torch.zeros(1, 24, 1, 2, 2)}
    refs = [
        {"kind": "image", "latent_h": 2, "latent_w": 2, "latent": torch.ones(1, 24, 1, 2, 2)},
        {"kind": "audio", "ref_audio_t": 100, "audio_latent": torch.ones(1, 1, 100)},
    ]
    result = {"route": conditioning.assert_hybrid_layout_contract(), "synthetic": True}
    layout = conditioning.build_packed_layout(10, 8, 2, 2, 200, keyframes=[keyframe], refs=refs, frame_count=124)
    result["position_origins"] = {kind: float(layout.position_ids[start, 0]) for start, _, kind in layout.segments}
    try:
        validate_contract(result)
    except ValueError as error:
        result["error"] = str(error)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--core", type=Path, required=True)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    # Comfy's argument parser also reads argv when its modules load.
    sys.argv = [sys.argv[0], "--cpu"]
    try:
        result = probe(args.core.resolve())
    except Exception as error:
        result = {"error": str(error), "synthetic": True}
    print(json.dumps(result))


if __name__ == "__main__":
    main()
