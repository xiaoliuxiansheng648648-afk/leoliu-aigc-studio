"""Register the two stable T8 nodes without loading unrelated experimental extensions."""

import hashlib
from common import H3Error, digest

UPSTREAM_INIT_SHA = "2e0e831b9d9ef97023240a73a1088b3e154cfecb291368f4b4563044e5631e9c"
ENTRYPOINT = '''from pathlib import Path
from comfy_api.latest import ComfyExtension

__path__ = [str(Path(__file__).parent / "h3_t8"), str(Path(__file__).parent)]
from .nodes import MiniMaxH3AudioConditioningT8, MiniMaxH3AVDecodeT8


class StudioT8Extension(ComfyExtension):
    async def get_node_list(self):
        return [MiniMaxH3AudioConditioningT8, MiniMaxH3AVDecodeT8]


def comfy_entrypoint():
    return StudioT8Extension()
'''


def configure_registration(target, before_replace):
    entrypoint = target / "__init__.py"
    expected = hashlib.sha256(ENTRYPOINT.encode()).hexdigest()
    actual = digest(entrypoint)
    if actual == expected:
        return
    if actual != UPSTREAM_INIT_SHA:
        raise H3Error("T8 注册入口被改动，停止覆盖。")
    before_replace()
    temporary = target / ".leoliu-init.tmp"
    temporary.write_text(ENTRYPOINT, encoding="utf-8")
    temporary.replace(entrypoint)
