"""Resumable, size/hash-locked downloads. Ordered domestic-first sources."""

import json
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from common import H3Error, digest, valid, say


def event(log, data):
    if log:
        p = Path(log)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(dict(at=time.time(), **data), ensure_ascii=False) + "\n")


def request(url, start=0, end=None, timeout=30):
    headers = {"User-Agent": "leoliu-h3-cloud/1", "Accept-Encoding": "identity"}
    if start or end is not None:
        headers["Range"] = f'bytes={start}-{end if end is not None else ""}'
    return urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout)


def probe(source, log):
    t = time.monotonic()
    try:
        with request(source["url"], end=1024 * 1024 - 1, timeout=20) as f:
            b = f.read(1024 * 1024)
        speed = len(b) / max(time.monotonic() - t, 0.001)
        event(
            log,
            dict(
                event="probe",
                source=source["name"],
                bytes_per_second=round(speed),
                elapsed=round(time.monotonic() - t, 2),
                ok=True,
            ),
        )
        return bool(b)
    except (OSError, TimeoutError, urllib.error.URLError):
        event(
            log,
            dict(
                event="probe",
                source=source["name"],
                ok=False,
                elapsed=round(time.monotonic() - t, 2),
            ),
        )
        return False


def fetch(row, target, log=None, dry_run=False, progress=True, probe_all=True):
    target = Path(target)
    if dry_run:
        say("预演：按国内源优先、断点续传、大小与 SHA-256 核对 " + row["filename"], mark="…")
        return "dry-run"
    if valid(target, row):
        if progress:
            say("大小和 SHA-256 通过，跳过：" + row["filename"])
        event(log, dict(event="skip", filename=row["filename"]))
        return "skipped"
    if target.exists():
        # Never silently repair or overwrite a final file of unknown origin.
        raise H3Error(
            "已有文件大小或 SHA-256 不符：" + row["filename"] + "；先移走错误文件再继续。"
        )
    target.parent.mkdir(parents=True, exist_ok=True)
    part = target.with_name(target.name + ".part")
    # Probe every declared source for an audit trail; successful sources keep policy order.
    sources = [s for s in row["sources"] if probe(s, log)] if probe_all else row["sources"]
    for source in sources:
        if not probe_all and not probe(source, log):
            continue
        for attempt in range(2):
            start = part.stat().st_size if part.exists() else 0
            if start > row["bytes"]:
                part.unlink()
                start = 0
            if start == row["bytes"]:
                if digest(part) == row["sha256"]:
                    part.replace(target)
                    return "downloaded"
                part.unlink()
                start = 0
            t = time.monotonic()
            try:
                with request(source["url"], start=start) as response:
                    if start:
                        content_range = response.headers.get("Content-Range", "")
                        if response.status != 206 or not re.fullmatch(
                            rf'bytes {start}-\d+/{row["bytes"]}', content_range
                        ):
                            # Do not append a whole-file response to a partial file.
                            part.unlink(missing_ok=True)
                            continue
                    event(
                        log,
                        dict(
                            event="selected",
                            filename=row["filename"],
                            source=source["name"],
                            offset=start,
                        ),
                    )
                    last = 0
                    with part.open("ab" if start else "wb") as f:
                        count = start
                        while True:
                            chunk = response.read(4 * 1024**2)
                            if not chunk:
                                break
                            f.write(chunk)
                            count += len(chunk)
                            if count > row["bytes"]:
                                raise H3Error("下载大小超出清单")
                            if progress and time.monotonic() - last >= 30:
                                say(
                                    f'下载 {row["role"]} {row["bytes"]/1e9:.2f}GB，{source["name"]}，已完成 {count*100//row["bytes"]}%',
                                    time.monotonic() - t,
                                    "…",
                                )
                                last = time.monotonic()
                if valid(part, row):
                    part.replace(target)
                    event(
                        log,
                        dict(
                            event="verified",
                            filename=row["filename"],
                            source=source["name"],
                            sha256=row["sha256"],
                        ),
                    )
                    if progress:
                        say("大小和 SHA-256 通过：" + row["filename"], time.monotonic() - t)
                    return "downloaded"
                if part.stat().st_size == row["bytes"]:
                    part.unlink()
                event(
                    log,
                    dict(
                        event="incomplete_or_hash_mismatch",
                        filename=row["filename"],
                        source=source["name"],
                    ),
                )
            except (OSError, TimeoutError, urllib.error.URLError, H3Error):
                event(
                    log,
                    dict(
                        event="retry",
                        filename=row["filename"],
                        source=source["name"],
                        attempt=attempt + 1,
                    ),
                )
    raise H3Error("下载失败或大小／SHA-256 不符：" + row["filename"] + "；已保留可恢复的下载进度。")
