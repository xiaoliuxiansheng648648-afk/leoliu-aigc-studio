#!/usr/bin/env python3
"""Linux-side deployment and service control; only the local CLI transports requests."""
import argparse
import base64
import ctypes
import importlib.metadata
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import tarfile
import time
import re
import tempfile
import urllib.request
import urllib.error
from pathlib import Path
from common import (
    ROOT,
    COMMIT,
    ARCHIVE_SHA,
    GIB,
    H3Error,
    NO_GPU,
    digest,
    models_for,
    valid,
    write_json,
    lora_filename,
)
from download import fetch

HOME_ROOT = Path.home() / ".local/share/leoliu-h3-cloud"
STATE = HOME_ROOT / "state.json"
FAST_HD_NODES = ("Comfyui_Minimax_h3_latent_Upscaler",)


def nearest(path):
    p = Path(path).expanduser()
    while not p.exists():
        p = p.parent
    return p


def choose_data(explicit=None):
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_absolute():
            raise H3Error("数据盘路径需要是绝对路径。")
        return p
    system_device = Path("/").stat().st_dev
    candidates = [Path(p) for p in ("/data", "/workspace", "/mnt/data", "/mnt/storage")]
    candidates += list(Path.home().glob("*-tmp"))
    available = [
        p
        for p in candidates
        if p.is_dir() and os.access(p, os.W_OK) and p.stat().st_dev != system_device
    ]
    if not available:
        raise H3Error("未识别到独立数据盘；请提供控制台显示的数据盘挂载路径。")
    return max(available, key=lambda p: shutil.disk_usage(p).free) / "leoliu-h3-cloud"


def space_plan(data, software=None, mode="standard", models_override=None):
    rows = models_override if models_override is not None else models_for(mode)
    missing = sum(
        (
            max(
                0,
                x["bytes"]
                - (data / "models" / x["relative_path"])
                .with_name(x["filename"] + ".part")
                .stat()
                .st_size,
            )
            if (data / "models" / x["relative_path"]).with_name(x["filename"] + ".part").exists()
            else x["bytes"]
        )
        for x in rows
        if not valid(data / "models" / x["relative_path"], x)
    )
    data_free = shutil.disk_usage(nearest(data)).free
    soft = Path(software).expanduser() if software else HOME_ROOT / "runtime"
    sys_free = shutil.disk_usage(nearest(soft)).free
    software_need = 16 * GIB if not (soft / "state/installed.json").exists() else GIB
    output_need = 8 * GIB
    if not software and sys_free < software_need:
        soft = data / "runtime"
    same = nearest(data).stat().st_dev == nearest(soft).stat().st_dev
    deficits = []
    if same:
        need = missing + output_need + software_need
        if data_free < need:
            deficits.append(("数据盘", need - data_free))
    else:
        if data_free < missing + output_need:
            deficits.append(("数据盘", missing + output_need - data_free))
        if sys_free < software_need:
            deficits.append(("软件盘", software_need - sys_free))
    if deficits:
        raise H3Error(
            "空间不足："
            + "；".join(f"{n}还缺 {v/GIB:.1f}GiB" for n, v in deficits)
            + "。已停止安装。"
        )
    return {
        "data": str(data),
        "software": str(soft),
        "data_free_gib": round(data_free / GIB, 1),
        "system_free_gib": round(sys_free / GIB, 1),
        "models_remaining_bytes": missing,
        "software_budget_gib": round(software_need / GIB),
        "same_filesystem": same,
    }


def check_base():
    if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
        raise H3Error("锁定运行库需要 Linux x86_64。")
    if sys.version_info[:2] != (3, 12):
        raise H3Error("这套散列锁需要 Python 3.12；请选带 Python 3.12 的 PyTorch 镜像。")
    libc = platform.libc_ver()[1]
    if libc and tuple(map(int, libc.split(".")[:2])) < (2, 28):
        raise H3Error("系统库版本过旧，请选较新的 Linux 镜像。")
    # The base image is deliberately not modified. Probe its declared CUDA version.
    r = subprocess.run(
        [sys.executable, "-c", 'import torch; print(torch.version.cuda or "none")'],
        capture_output=True,
        text=True,
        timeout=90,
    )
    if r.returncode or r.stdout.strip() == "none":
        raise H3Error("请使用包含 PyTorch 和 CUDA 的镜像。")
    try:
        version = tuple(map(int, r.stdout.strip().split(".")[:2]))
    except ValueError:
        raise H3Error("无法识别镜像 CUDA 版本。")
    if version < (12, 8):
        raise H3Error("镜像 CUDA 需要 12.8 以上。")


def events(message, **kw):
    print("@@EVENT@@" + json.dumps(dict(message=message, **kw), ensure_ascii=False), flush=True)


def run_logged(cmd, log, **kw):
    with Path(log).open("a") as f:
        p = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, **kw)
    if p.returncode:
        raise H3Error("步骤未通过；详细原因已写入实例日志。")


def safe_extract(archive, destination):
    destination = Path(destination)
    with tarfile.open(archive) as t:
        members = t.getmembers()
        for m in members:
            parts = Path(m.name).parts[1:]
            if ".." in parts or m.issym() or m.islnk() or not (m.isfile() or m.isdir()):
                raise H3Error("源码包包含不安全路径或文件。")
            if not parts:
                continue
            dst = destination.joinpath(*parts)
            if m.isdir():
                dst.mkdir(parents=True, exist_ok=True)
            elif m.isfile():
                dst.parent.mkdir(parents=True, exist_ok=True)
                with dst.open("wb") as f:
                    shutil.copyfileobj(t.extractfile(m), f)


def runtime_ready(soft, lock):
    """Check the installed runtime and live package versions, without pip or wheel reads."""
    soft = Path(soft)
    if not (soft / ".venv/bin/python").is_file() or not (soft / "ComfyUI/main.py").is_file():
        return False
    try:
        receipt = json.loads((soft / "state/installed.json").read_text())
        if receipt.get("commit") != COMMIT or receipt.get("archive_sha256") != ARCHIVE_SHA:
            return False
        expected = {
            row["filename"].split("-")[0].replace("_", "-"): row["filename"].split("-")[1]
            for row in lock
        }
        code = (
            "import importlib.metadata as m,json,sys; "
            "print(json.dumps({n:m.version(n) for n in json.loads(sys.argv[1])}))"
        )
        result = subprocess.run(
            [str(soft / ".venv/bin/python"), "-c", code, json.dumps(expected)],
            capture_output=True, text=True, timeout=30,
        )
        return result.returncode == 0 and json.loads(result.stdout) == expected
    except (OSError, ValueError, KeyError, subprocess.TimeoutExpired):
        return False


def install(request):
    check_base()
    data = choose_data(request.get("data_dir"))
    from studio_remote import model_rows

    rows = model_rows(request["studio_models"]) if request.get("studio_models") else None
    plan = space_plan(data, request.get("software_dir"), request.get("mode", "standard"), rows)
    soft = Path(plan["software"])
    if soft.exists() and any(soft.iterdir()) and not (soft / "state/owner.json").exists():
        raise H3Error("软件目录已有其他文件，请换一个新目录。")
    for d in ("state", "logs", "wheels", "tmp"):
        (soft / d).mkdir(parents=True, exist_ok=True)
    for d in ("models", "input", "output", "tmp", "user"):
        (data / d).mkdir(parents=True, exist_ok=True)
    write_json(soft / "state/owner.json", {"skill": "leoliu-h3-cloud", "commit": COMMIT})
    write_json(STATE, dict(plan, mode=request.get("mode", "standard")))
    events(
        f'空间检查通过：软件盘余 {plan["system_free_gib"]}GiB，数据盘余 {plan["data_free_gib"]}GiB'
    )
    log = soft / "logs/install.log"
    archive = ROOT / "assets/runtime/comfyui-source.tar.gz"
    if digest(archive) != ARCHIVE_SHA:
        raise H3Error("ComfyUI 源码包 SHA-256 不符。")
    # Keep source hashes to detect local changes before an idempotent re-run.
    source_lock = soft / "state/source-hashes.json"
    if source_lock.exists():
        for name, sha in json.loads(source_lock.read_text()).items():
            if not (soft / "ComfyUI" / name).is_file() or digest(soft / "ComfyUI" / name) != sha:
                raise H3Error("已安装源码被改动，请使用新软件目录。")
    else:
        safe_extract(archive, soft / "ComfyUI")
        write_json(
            source_lock,
            {
                str(p.relative_to(soft / "ComfyUI")): digest(p)
                for p in (soft / "ComfyUI").rglob("*")
                if p.is_file()
            },
        )
    vpython = soft / ".venv/bin/python"
    lock = json.loads((ROOT / "assets/locked-wheels.json").read_text())["wheels"]
    if runtime_ready(soft, lock):
        events("已复用现有运行环境，跳过运行库下载核对与重复安装")
        download_models(request)
        cpu_check(request)
        return dict(plan, installed=True, reused=True, cpu_only=not gpu_visible())
    if not vpython.exists():
        run_logged([sys.executable, "-m", "venv", str(soft / ".venv")], log)
    lines = []
    for i, row in enumerate(lock):
        wheel = dict(
            row,
            role="安装依赖",
            sources=[
                {
                    "name": (
                        "国内 Python 源"
                        if any(s in u for s in ("aliyun.com", "tuna.tsinghua"))
                        else "官方 Python 源"
                    ),
                    "url": u,
                }
                for u in row["urls"]
            ],
        )
        target = soft / "wheels" / row["filename"]
        fetch(wheel, target, soft / "logs/downloads.jsonl", progress=False, probe_all=False)
        lines.append(str(target) + " --hash=sha256:" + row["sha256"])
        if (i + 1) % 15 == 0 or i + 1 == len(lock):
            events(f"运行库下载核对 {i+1}/{len(lock)}")
    req = soft / "state/locked-requirements.txt"
    req.write_text("\n".join(lines) + "\n")
    run_logged(
        [
            str(vpython),
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            "--no-deps",
            "--no-index",
            "--require-hashes",
            "-r",
            str(req),
        ],
        log,
    )
    run_logged([str(vpython), "-m", "pip", "check"], log)
    result = subprocess.run(
        [str(vpython), "-m", "pip", "list", "--format=json"],
        capture_output=True,
        text=True,
        check=True,
    )
    write_json(
        soft / "state/installed.json",
        {"commit": COMMIT, "packages": json.loads(result.stdout), "archive_sha256": ARCHIVE_SHA},
    )
    events("ComfyUI 0.33.1（锁定），PyTorch 2.11.0＋cu130，运行库已核对")
    download_models(request)
    cpu_check(request)
    return dict(plan, installed=True, cpu_only=not gpu_visible())


def load_state():
    if not STATE.exists():
        raise H3Error("尚未安装，请先运行 install。")
    return json.loads(STATE.read_text())


def download_models(request):
    state = load_state()
    if request.get("studio_models"):
        from studio_remote import prepare_models

        return prepare_models({"models": request["studio_models"]}, state)
    mode = request.get("mode", state.get("mode", "standard"))
    data, soft = Path(state["data"]), Path(state["software"])
    space_plan(data, soft, mode)
    for row in models_for(mode):
        fetch(row, data / "models" / row["relative_path"], soft / "logs/downloads.jsonl")
    if mode == "fast-hd":
        install_nodes(soft)
    return {"models_verified": len(models_for(mode))}


def gpu_visible():
    return any(p.name[6:].isdigit() and p.exists() for p in Path("/dev").glob("nvidia[0-9]*"))


def memory_snapshot():
    values = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, rest = line.split(":", 1)
        values[key] = int(rest.strip().split()[0]) * 1024
    total, available = values["MemTotal"], values.get("MemAvailable", 0)
    pairs = [
        ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.current"),
        (
            "/sys/fs/cgroup/memory/memory.limit_in_bytes",
            "/sys/fs/cgroup/memory/memory.usage_in_bytes",
        ),
    ]
    for limit, current in pairs:
        try:
            value = Path(limit).read_text().strip()
            if value != "max":
                cap = int(value)
                total = min(total, cap)
                available = min(available, max(0, cap - int(Path(current).read_text())))
        except (OSError, ValueError):
            continue
    return total, available


def assess_gpu(data):
    if not data.get("gpu_visible"):
        raise H3Error(NO_GPU)
    if not data.get("kernel_check"):
        raise H3Error("CUDA 实际运算未通过，已停止生成。")
    if data.get("driver_major", 0) < 580:
        raise H3Error("锁定的 cu130 运行库需要 580 以上驱动；请更换符合条件的镜像或驱动。")
    if data.get("vram_bytes", 0) < 30 * GIB:
        raise H3Error("当前基线需要约 32GB 显存，已停止生成。")
    if data.get("ram_total", 0) < 48 * GIB or data.get("ram_available", 0) < 24 * GIB:
        raise H3Error("内存不足：需要总量至少 48GiB、可用至少 24GiB，已停止生成。")
    return data


def doctor(request):
    total, available = memory_snapshot()
    report = {"gpu_visible": gpu_visible(), "ram_total": total, "ram_available": available}
    if not report["gpu_visible"]:
        report.update(cpu_only=True, hint=NO_GPU)
        return report
    import torch

    packages = json.loads((ROOT / "assets/locked-wheels.json").read_text())["wheels"]
    for row in packages:
        name, version = row["filename"].split("-")[:2]
        if importlib.metadata.version(name.replace("_", "-")) != version:
            raise H3Error("已安装运行库与散列锁不符，已停止启动。")
    if torch.__version__ != "2.11.0+cu130":
        raise H3Error("PyTorch 与散列锁不符，已停止启动。")
    r = subprocess.run(
        ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
        capture_output=True,
        text=True,
        check=True,
    )
    report["driver_major"] = int(r.stdout.strip().splitlines()[0].split(".")[0])
    report["kernel_check"] = False
    if torch.cuda.is_available():
        t = torch.ones((8, 8), device="cuda") @ torch.ones((8, 8), device="cuda")
        torch.cuda.synchronize()
        report["kernel_check"] = t[0, 0].item() == 8
        report.update(
            gpu=torch.cuda.get_device_name(0),
            vram_bytes=torch.cuda.get_device_properties(0).total_memory,
            cuda=torch.version.cuda,
        )
        del t
        torch.cuda.empty_cache()
    assess_gpu(report)
    return report


def service_args(cpu=False):
    state = load_state()
    soft, data = Path(state["software"]), Path(state["data"])
    # Private service: no public bind or external API nodes.
    args = [
        str(soft / ".venv/bin/python"),
        "-B",
        str(soft / "ComfyUI/main.py"),
        "--listen",
        "127.0.0.1",
        "--port",
        "18188",
        "--disable-auto-launch",
        "--disable-api-nodes",
        "--cache-none",
        "--disable-pinned-memory",
        "--input-directory",
        str(data / "input"),
        "--output-directory",
        str(data / "output"),
        "--temp-directory",
        str(data / "tmp"),
        "--user-directory",
        str(data / "user"),
        "--database-url",
        f"sqlite:///{data}/user/comfyui.db",
        "--extra-model-paths-config",
        str(soft / "state/model-paths.yaml"),
        "--disable-all-custom-nodes",
        "--whitelist-custom-nodes",
        *FAST_HD_NODES,
    ]
    args += ["--cpu"] if cpu else ["--lowvram"]
    return args


def api(path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(
        "http://127.0.0.1:18188" + path, data=data, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=30) as f:
        return json.load(f)


def stop_service():
    state = load_state()
    soft = Path(state["software"])
    pidfile = soft / "state/service.json"
    if not pidfile.exists():
        return
    rec = json.loads(pidfile.read_text())
    pid = rec["pid"]
    proc = Path(f"/proc/{pid}/cmdline")
    if proc.exists():
        cmd = proc.read_bytes().replace(b"\x00", b" ")
        if str(soft / "ComfyUI/main.py").encode() not in cmd:
            raise H3Error("服务进程标识不匹配，停止操作。")
        os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            if not proc.exists():
                break
            time.sleep(1)
        if proc.exists():
            os.kill(pid, signal.SIGKILL)
    pidfile.unlink(missing_ok=True)


def start_service(cpu=False):
    state = load_state()
    soft, data = Path(state["software"]), Path(state["data"])
    try:
        api("/system_stats")
    except Exception:
        pass
    else:
        marker = soft / "state/service.json"
        if marker.exists():
            rec = json.loads(marker.read_text())
            proc = Path("/proc") / str(rec["pid"]) / "cmdline"
            if (
                proc.exists()
                and proc.read_bytes().rstrip(b"\x00").split(b"\x00")
                == [arg.encode() for arg in service_args(cpu)]
                and rec["cpu"] == cpu
            ):
                return
        raise H3Error("服务地址已被占用；先核对现有服务，未自动覆盖。")
    config = "h3_cloud:\n  base_path: " + json.dumps(str(data / "models")) + "\n"
    for name in (
        "diffusion_models",
        "text_encoders",
        "vae",
        "loras",
        "latent_upscale_models",
        "vae_approx",
    ):
        config += f"  {name}: {name}\n"
    (soft / "state/model-paths.yaml").write_text(config)
    with (soft / "logs/service.log").open("a") as log:
        p = subprocess.Popen(
            service_args(cpu),
            cwd=soft / "ComfyUI",
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    write_json(soft / "state/service.json", {"pid": p.pid, "cpu": cpu})
    deadline = time.monotonic() + 240
    while time.monotonic() < deadline:
        if p.poll() is not None:
            raise H3Error("ComfyUI 启动失败，请查看实例服务日志。")
        try:
            api("/system_stats")
            return
        except Exception:
            time.sleep(3)
    stop_service()
    raise H3Error("ComfyUI 启动超时。")


def cpu_check(request):
    start_service(cpu=True)
    try:
        info = api("/object_info")
        graphs = request.get("studio_graphs") or [
            json.loads((ROOT / "assets/workflows" / filename).read_text())
            for filename in ("t2v.api.json", "i2v.api.json")
        ]
        for wf in graphs:
            for n in wf.values():
                if n["class_type"] not in info:
                    raise H3Error("CPU 自检缺少官方节点：" + n["class_type"])
                spec = info[n["class_type"]].get("input", {})
                for k, v in n["inputs"].items():
                    if k in ("unet_name", "clip_name", "vae_name"):
                        option = spec.get("required", {}).get(
                            k, spec.get("optional", {}).get(k, [])
                        )
                        if not option or v not in option[0]:
                            raise H3Error("CPU 自检未发现模型：" + v)
        result = {"cpu_import_and_visibility": True, "gpu_generation_tested": False}
        write_json(Path(load_state()["software"]) / "state/cpu-check.json", result)
        events("CPU 节点和四模型可见性通过；尚未验证显卡生成")
        return result
    finally:
        stop_service()


def install_nodes(soft):
    manifest = json.loads((ROOT / "assets/nodes.json").read_text())
    manifest = [row for row in manifest if row["folder"] in FAST_HD_NODES]
    if {row["folder"] for row in manifest} != set(FAST_HD_NODES):
        raise H3Error("快速高清所需节点不在锁定清单中，停止安装。")
    for row in manifest:
        archive = soft / "tmp" / (row["folder"] + ".tar.gz")
        fetch(
            dict(row, filename=archive.name, role="可选节点源码"),
            archive,
            soft / "logs/downloads.jsonl",
            progress=False,
            probe_all=False,
        )
        target = soft / "ComfyUI/custom_nodes" / row["folder"]
        if target.exists():
            marker = target / ".leoliu-h3-cloud-commit"
            if not marker.exists() or marker.read_text() != row["commit"]:
                raise H3Error("可选节点目录已有其他版本，停止覆盖。")
        else:
            safe_extract(archive, target)
            (target / ".leoliu-h3-cloud-commit").write_text(row["commit"])
    # No unconstrained dependency installation: the runtime snapshot already contains the candidate dependencies.
    # CPU/API visibility is checked before generation; report missing imports instead of upgrading packages.
    events("仅安装快速高清所需的 H3 放大节点；启动白名单排除其他插件，依赖沿用锁定环境")


def receive_lora(request, source=None):
    name = lora_filename(request.get("name"))
    expected = request.get("sha256", "")
    size = request.get("bytes")
    if not re.fullmatch("[a-f0-9]{64}", expected) or type(size) is not int or size <= 0:
        raise H3Error("LoRA 大小或 SHA-256 无效。")
    data = Path(load_state()["data"]).resolve()
    folder = data / "models/loras"
    folder.mkdir(parents=True, exist_ok=True)
    if not folder.resolve().is_relative_to(data):
        raise H3Error("LoRA 目录不在当前数据盘内。")
    target = folder / name
    if target.is_symlink():
        raise H3Error("LoRA 目标是符号链接，未覆盖。")
    if target.exists():
        if not target.is_file() or target.stat().st_size != size or digest(target) != expected:
            raise H3Error("同名 LoRA 已存在且散列不同，未覆盖。")
        # Drain SSH stdin so a repeated verified upload completes without a broken pipe.
        source = source if source is not None else sys.stdin.buffer
        while source.read(4 * 1024**2):
            pass
        return {"sha256": expected, "bytes": size, "name": name, "skipped": True}
    source = source if source is not None else sys.stdin.buffer
    fd, part = tempfile.mkstemp(prefix="." + name + ".", suffix=".part", dir=folder)
    part = Path(part)
    try:
        with os.fdopen(fd, "wb") as output:
            count = 0
            while True:
                chunk = source.read(4 * 1024**2)
                if not chunk:
                    break
                count += len(chunk)
                if count > size:
                    raise H3Error("上传 LoRA 大小超出 manifest，未发布。")
                output.write(chunk)
        if count != size or digest(part) != expected:
            raise H3Error("远端 LoRA SHA-256 或大小不一致，未发布。")
        # Atomic no-clobber publication, even if another uploader creates the name meanwhile.
        try:
            os.link(part, target)
        except FileExistsError:
            raise H3Error("同名 LoRA 在上传期间出现，未覆盖。")
        return {
            "sha256": digest(target),
            "bytes": target.stat().st_size,
            "name": name,
            "skipped": False,
        }
    finally:
        part.unlink(missing_ok=True)


def dispatch(action, request):
    if action == "studio-input":
        from studio_remote import receive_input

        return receive_input(request, load_state())
    if action == "studio-models":
        from studio_remote import prepare_models

        return prepare_models(request, load_state())
    if action == "upload-lora":
        return receive_lora(request)
    if action == "install":
        return install(request)
    if action == "models":
        return download_models(request)
    if action == "cpu-check":
        return cpu_check(request)
    if action == "probe":
        uptime = float(Path("/proc/uptime").read_text().split()[0])
        # /proc/uptime can be the host's uptime. Subtract this container's init start time.
        init_fields = Path("/proc/1/stat").read_text().rsplit(")", 1)[1].split()
        container_age = max(0, uptime - int(init_fields[19]) / os.sysconf("SC_CLK_TCK"))
        return {"gpu_visible": gpu_visible(), "uptime_seconds": container_age}
    if action == "state":
        return load_state()
    if action == "shutdown-ready":
        state = load_state() if STATE.exists() else None
        soft = Path(state["software"]) if state else None
        try:
            q = api("/queue")
        except urllib.error.URLError as error:
            if isinstance(error.reason, ConnectionRefusedError):
                return {"queue_empty": True, "service_running": False}
            raise H3Error("无法确认队列，未关机；请在控制台核对。")
        except ConnectionRefusedError:
            return {"queue_empty": True, "service_running": False}
        if not isinstance(q.get("queue_running"), list) or not isinstance(
            q.get("queue_pending"), list
        ):
            raise H3Error("队列状态不明确，未关机。")
        if q["queue_running"] or q["queue_pending"]:
            raise H3Error("队列还有任务，未关机。")
        if soft is None or not (soft / "state/service.json").exists():
            raise H3Error("服务不属于当前 Skill，未关机。")
        stop_service()
        return {"queue_empty": True, "service_running": False}
    if action == "stop":
        stop_service()
        return {"stopped": True}
    if action == "start":
        report = doctor(request)
        if report.get("cpu_only"):
            raise H3Error(NO_GPU)
        start_service()
        return report
    if action == "restart":
        q = api("/queue")
        if q.get("queue_running") or q.get("queue_pending"):
            raise H3Error("队列还有任务，未重启服务。")
        stop_service()
        return dispatch("start", request)
    if action == "doctor":
        return doctor(request)
    if action == "hash":
        data = Path(load_state()["data"]) / "output"
        p = (data / request["relative"]).resolve()
        if not p.is_relative_to(data.resolve()) or not p.is_file():
            raise H3Error("输出路径不在当前项目内。")
        return {"sha256": digest(p), "bytes": p.stat().st_size}
    if action == "job":
        job = request["job"]
        if len(job) != 32 or not all(c in "0123456789abcdef" for c in job):
            raise H3Error("任务编号无效。")
        path = HOME_ROOT / "jobs" / job
        result = (
            json.loads(path.with_suffix(".json").read_text())
            if path.with_suffix(".json").exists()
            else {"running": True}
        )
        lines = (
            path.with_suffix(".log").read_text(errors="replace").splitlines()
            if path.with_suffix(".log").exists()
            else []
        )
        result["events"] = [
            json.loads(x[len("@@EVENT@@") :]) for x in lines if x.startswith("@@EVENT@@")
        ]
        return result
    raise H3Error("未知操作。")


def main():
    p = argparse.ArgumentParser(description="实例侧执行器；由本机 Skill 调用")
    p.add_argument("action")
    p.add_argument("--request-b64", default="e30=")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--background", action="store_true")
    p.add_argument("--job-id")
    a = p.parse_args()
    if a.dry_run:
        print(
            '… 预演：python3 "$PACKAGE/scripts/remote.py" '
            + a.action
            + " --request-b64 <参数>（0 秒）"
        )
        return 0
    os.environ["H3_REMOTE_EVENTS"] = "1"
    request = json.loads(base64.b64decode(a.request_b64))
    if a.background:
        import uuid

        job = uuid.uuid4().hex
        folder = HOME_ROOT / "jobs"
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / (job + ".log")).open("w") as log:
            subprocess.Popen(
                [
                    sys.executable,
                    str(Path(__file__)),
                    a.action,
                    "--request-b64",
                    a.request_b64,
                    "--job-id",
                    job,
                ],
                stdout=log,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        print("@@RESULT@@" + json.dumps({"job": job}))
        return 0
    try:
        if a.action in ("install", "models", "cpu-check", "studio-models"):
            import fcntl

            HOME_ROOT.mkdir(parents=True, exist_ok=True)
            with (HOME_ROOT / "operation.lock").open("a") as lock:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    raise H3Error("实例另一个准备任务仍在运行，请继续查询原任务。")
                result = {"ok": True, "value": dispatch(a.action, request)}
        else:
            result = {"ok": True, "value": dispatch(a.action, request)}
    except Exception as e:
        # Raw library errors can contain addresses. Keep them in the private instance log only.
        if isinstance(e, H3Error):
            message = str(e)
        else:
            import traceback

            traceback.print_exc(file=sys.stderr)
            message = "实例步骤失败，请查看实例日志。"
        result = {"ok": False, "error": message}
    if a.job_id:
        write_json(HOME_ROOT / "jobs" / (a.job_id + ".json"), result)
    print("@@RESULT@@" + json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
