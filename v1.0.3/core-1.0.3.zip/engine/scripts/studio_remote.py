"""Studio-only remote additions; existing lifecycle and credential handling stay in h3-cloud."""

import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from common import H3Error, digest, valid
from download import fetch


def model_rows(models):
    rows = []
    for model in models:
        relative = model["path"]
        if not re.fullmatch(
            r"(diffusion_models|text_encoders|vae|loras)/[A-Za-z0-9_.-]+", relative
        ):
            raise H3Error("模型清单路径不合法。")
        rows.append(
            dict(
                filename=Path(relative).name,
                relative_path=relative,
                bytes=model["size"],
                sha256=model["sha256"],
                sources=model["sources"],
                role="工作流模型",
                min_free=model.get("minFreeBytes", 0),
            )
        )
    return rows


def prepare_models(request, state):
    data, software = Path(state["data"]).resolve(), Path(state["software"])
    rows = model_rows(request["models"])
    missing = [row for row in rows if not valid(data / "models" / row["relative_path"], row)]
    required = max(
        [sum(row["bytes"] for row in missing) + 3_000_000_000]
        + [row["min_free"] for row in missing]
    )
    if missing and shutil.disk_usage(data).free < required:
        raise H3Error(
            f"数据盘空间不足，下载前至少需要 {required / 1e9:.2f} GB 可用空间；未下载模型。"
        )
    for row in rows:
        target = data / "models" / row["relative_path"]
        if not target.resolve().is_relative_to(data):
            raise H3Error("模型目录离开当前数据盘，未下载。")
        fetch(row, target, software / "logs/downloads.jsonl")
    return {"models_verified": len(rows)}


def receive_input(request, state, source=None):
    name, expected, size = request.get("name", ""), request.get("sha256", ""), request.get("size")
    if not re.fullmatch(r"[a-f0-9]{64}\.[a-z0-9]+", name) or not re.fullmatch(
        "[a-f0-9]{64}", expected
    ):
        raise H3Error("素材文件名或散列无效。")
    if not name.startswith(expected + ".") or type(size) is not int or size <= 0:
        raise H3Error("素材大小或内容散列命名无效。")
    data = Path(state["data"]).resolve()
    folder = data / "input"
    folder.mkdir(parents=True, exist_ok=True)
    if not folder.resolve().is_relative_to(data):
        raise H3Error("输入目录不在当前数据盘内。")
    target = folder / name
    if target.is_symlink():
        raise H3Error("素材目标是符号链接，未覆盖。")
    source = source or sys.stdin.buffer
    if target.exists():
        if target.stat().st_size != size or digest(target) != expected:
            raise H3Error("同名素材散列不一致，未覆盖。")
        while source.read(4 * 1024**2):
            pass
        return {"name": name, "sha256": expected, "size": size}
    descriptor, part_name = tempfile.mkstemp(prefix="." + name, suffix=".part", dir=folder)
    part = Path(part_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            count = 0
            while True:
                chunk = source.read(4 * 1024**2)
                if not chunk:
                    break
                count += len(chunk)
                if count > size:
                    raise H3Error("上传素材大于清单，未发布。")
                stream.write(chunk)
        if count != size or digest(part) != expected:
            raise H3Error("远端素材大小或散列不一致，未发布。")
        try:
            os.link(part, target)
        except FileExistsError as error:
            raise H3Error("上传期间出现同名素材，未覆盖。") from error
        return {"name": name, "sha256": expected, "size": size}
    finally:
        part.unlink(missing_ok=True)
