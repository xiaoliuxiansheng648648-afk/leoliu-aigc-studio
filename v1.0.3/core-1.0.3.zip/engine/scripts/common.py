"""Shared standard-library helpers. No credential storage in this module."""

import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
COMMIT = "72865f4f27eaf5396f8f36370e0a2be3a9a090ee"
ARCHIVE_SHA = "f27e166e9b9fbf4743669a1a492980a5f6f57c6697d6e460d3121c4131771047"
NO_GPU = "无卡模式只安装软件、下载模型和做 CPU 自检；请去控制台“关机 → 正常开机（带显卡）”，开好了再回来说一声。"
GIB = 1024**3
VERIFY_CACHE = Path.home() / ".local/share/leoliu-h3-cloud/verified-files"
VERIFY_CACHE_MIN_BYTES = 64 * 1024**2


class H3Error(Exception):
    pass


class OOM(H3Error):
    pass


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(8 * 1024**2), b""):
            h.update(b)
    return h.hexdigest()


def valid(path, row, force_hash=False):
    p = Path(path)
    if not p.is_file():
        return False
    before = p.stat()
    if before.st_size != row["bytes"]:
        return False

    def fingerprint(stat):
        return [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]

    # Cache only large, previously hashed files. Downloads/outputs still use digest().
    resolved = str(p.resolve())
    record = {"schemaVersion": 1, "path": resolved, "sha256": row["sha256"], "stat": fingerprint(before)}
    cache = VERIFY_CACHE / (hashlib.sha256(resolved.encode()).hexdigest() + ".json")
    use_cache = before.st_size >= VERIFY_CACHE_MIN_BYTES
    if use_cache and not force_hash:
        try:
            if json.loads(cache.read_text(encoding="utf-8")) == record:
                return True
        except (OSError, ValueError):
            pass
    if digest(p) != row["sha256"] or fingerprint(p.stat()) != fingerprint(before):
        return False
    if use_cache:
        try:
            write_json(cache, record)
        except OSError:
            pass  # A read-only cache must not prevent full verification.
    return True


def write_json(path, value):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")
    os.chmod(tmp, 0o600)
    tmp.replace(p)


def say(message, elapsed=0, mark="✓"):
    if os.environ.get("H3_REMOTE_EVENTS") == "1":
        print(
            "@@EVENT@@"
            + json.dumps(
                dict(message=message, elapsed=int(elapsed), mark=mark), ensure_ascii=False
            ),
            flush=True,
        )
    else:
        print(f"{mark} {message}（{int(elapsed)} 秒）", flush=True)


def models_for(mode="standard"):
    d = json.loads((ROOT / "assets/models.json").read_text(encoding="utf-8"))
    return d["models"] + [
        x
        for x in d.get("optional", [])
        if (mode in ("turbo", "fast-hd") and x["group"] == "turbo")
        or (mode == "fast-hd" and x["group"] == "fast-hd")
    ]


def frame_count(seconds):
    n = int(seconds * 24)
    return n + (5 - n % 17) % 17


def lora_filename(name):
    import re

    if not isinstance(name, str) or not re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9_.-]*\.safetensors", name
    ):
        raise H3Error("LoRA 文件名须为纯 ASCII 的 safetensors 文件名，不能含路径。")
    return name
