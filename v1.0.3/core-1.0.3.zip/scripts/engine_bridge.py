"""Generic graph submission built on the transplanted h3-cloud lifecycle."""

import base64
import copy
import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from studio_common import PACKAGE, StudioError, digest, now, safe_relative, write_json, read_json

sys.path.insert(0, str(PACKAGE / "engine/scripts"))
import h3_cloud as h3
import local_support


class StudioRemote(h3.Remote):
    def upload_file(self, path, request):
        payload = base64.b64encode(json.dumps(request).encode()).decode()
        command = self.python_command(
            self.package + "/scripts/remote.py", "studio-input", "--request-b64", payload
        )
        with Path(path).open("rb") as stream:
            try:
                result = subprocess.run(
                    self.argv() + [command],
                    stdin=stream,
                    capture_output=True,
                    env=self.env(),
                    timeout=1800,
                    **local_support.process_options(),
                )
            except subprocess.TimeoutExpired as error:
                raise StudioError("素材上传超时，未提交生成。") from error
        records = [
            line[len("@@RESULT@@") :]
            for line in result.stdout.decode(errors="replace").splitlines()
            if line.startswith("@@RESULT@@")
        ]
        if result.returncode or not records:
            raise StudioError("素材上传失败，未提交生成。")
        response = json.loads(records[-1])
        value = response.get("value", response)
        if (
            response.get("ok") is False
            or value.get("sha256") != request["sha256"]
            or value.get("size") != request["size"]
        ):
            raise StudioError("远端素材散列或大小不一致，未提交生成。")
        return value


def normalized_upload(project, run_folder, upload):
    source = safe_relative(project, upload["path"])
    if digest(source) != upload["sha256"] or source.stat().st_size != upload["size"]:
        raise StudioError("素材在编译后发生变化，请重新编译。")
    if upload["mediaType"] == "audio":
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg:
            converted = Path(run_folder) / (upload["sha256"] + "-32k.wav")
            process = subprocess.run(
                [
                    ffmpeg,
                    "-nostdin",
                    "-hide_banner",
                    "-loglevel",
                    "error",
                    "-y",
                    "-i",
                    str(source),
                    "-ar",
                    "32000",
                    "-ac",
                    "2",
                    "-c:a",
                    "pcm_s16le",
                    str(converted),
                ],
                capture_output=True,
                timeout=120,
            )
            if process.returncode:
                raise StudioError("声音转为 32 kHz 立体声失败，未上传。")
            source = converted
        else:
            print("警告：未找到 ffmpeg，声音将原样上传；建议安装后再跑坏头 WAV。")
    sha = digest(source)
    return source, {
        "name": sha + source.suffix.lower(),
        "sha256": sha,
        "size": source.stat().st_size,
    }


def download_outputs(comfy, remote, item, project, run_id, job_id):
    outputs = []
    files = [
        entry
        for node in item.get("outputs", {}).values()
        for values in node.values()
        if isinstance(values, list)
        for entry in values
        if isinstance(entry, dict)
        and entry.get("type", "output") == "output"
        and entry.get("filename", "").lower().endswith(".mp4")
    ]
    unique = {(row.get("subfolder", ""), row["filename"]): row for row in files}
    if not unique:
        raise StudioError("任务结束但没有找到 MP4，请核对远端历史记录。")
    for index, row in enumerate(unique.values()):
        relative = "/".join(part for part in (row.get("subfolder", ""), row["filename"]) if part)
        # h3.Comfy.download rejects escaping output paths; remote hash checks the resolved path again.
        metadata = remote.call("hash", {"relative": relative})
        local_path = f"runs/{run_id}/{job_id}-{index}.mp4"
        target = safe_relative(project, local_path)
        part = target.with_suffix(".part")
        comfy.download(relative, part)
        if digest(part) != metadata["sha256"] or part.stat().st_size != metadata["bytes"]:
            raise StudioError("视频下载散列不一致，未标记完成、未自动关机；请恢复下载。")
        part.replace(target)
        outputs.append(
            {
                "id": job_id + "-" + str(index),
                "status": "complete",
                "path": local_path,
                "sha256": metadata["sha256"],
                "updatedAt": now(),
            }
        )
    return outputs


def run_job(remote, project, run, job, on_state, resume=False, before_submit=None, models_ready=None):
    folder = Path(project) / "runs" / run["id"]
    record_path = folder / (job["id"] + ".engine.json")
    graph = read_json(safe_relative(project, job["graphPath"]))
    if record_path.exists():
        record = read_json(record_path)
        if record["target"] != remote.identity:
            raise StudioError("任务绑定的实例与当前凭据不同，禁止查询或重发。")
        if not resume:
            raise StudioError("任务已有提交记录，请使用 wait 恢复，禁止重发。")
    else:
        if resume:
            raise StudioError("该任务尚未提交，没有可恢复的记录。")
        record = {
            "target": remote.identity,
            "status": "prepared",
            "prompt_id": None,
            "attempts": [],
        }
    holder = {"tunnel": None, "comfy": None}

    def connect():
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
        holder["tunnel"] = h3.Tunnel(remote).__enter__()
        holder["comfy"] = h3.Comfy(holder["tunnel"])

    def restart():
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
            holder["tunnel"] = None
        remote.call("restart")
        connect()

    def attempt(size, index):
        comfy = holder["comfy"]
        h3.ensure_empty_queue(comfy)
        active_graph = copy.deepcopy(graph)
        if size.startswith("small-"):
            dimensions = (480, 864) if size == "small-portrait" else (864, 480)
            active_graph["9"]["inputs"].update(width=dimensions[0], height=dimensions[1])
        h3.validate_graph(comfy, active_graph)
        if before_submit:
            before_submit()
        record.update(status="submitting", prompt_id=None)
        record["attempts"].append({"index": index, "size": size, "graph": active_graph})
        write_json(record_path, record)
        on_state("unknown", "正在提交；收到编号前状态待核对。")
        response = comfy.call("/prompt", {"prompt": active_graph, "client_id": uuid.uuid4().hex})
        prompt_id = response.get("prompt_id")
        if not prompt_id:
            raise StudioError("提交没有返回任务编号，状态未知，禁止重发。")
        record.update(status="running", prompt_id=prompt_id)
        write_json(record_path, record)
        on_state("running")
        try:
            item = h3.poll(comfy, prompt_id)
        except h3.OOM:
            record["status"] = "oom"
            write_json(record_path, record)
            raise
        return download_outputs(comfy, remote, item, project, run["id"], job["id"])

    try:
        if not resume:
            # The batch's model check, this CUDA check, and input upload overlap.
            # No /prompt is sent until every prerequisite succeeds.
            with ThreadPoolExecutor(max_workers=1) as checks:
                gpu_ready = checks.submit(remote.call, "doctor")
                for upload in job["uploads"]:
                    source, request = normalized_upload(project, folder, upload)
                    remote.upload_file(source, request)
                    graph[upload["nodeId"]]["inputs"][
                        "audio" if upload["mediaType"] == "audio" else "image"
                    ] = request["name"]
                if models_ready is not None:
                    models_ready.result()
                report = gpu_ready.result()
            if report.get("cpu_only"):
                raise StudioError(h3.NO_GPU)
            remote.call("start")
        connect()
        if resume:
            if not record.get("prompt_id"):
                raise StudioError("提交状态未知，没有确定任务编号；请核对队列和历史，禁止重发。")
            item = h3.poll(holder["comfy"], record["prompt_id"])
            outputs = download_outputs(holder["comfy"], remote, item, project, run["id"], job["id"])
        else:
            size = (
                "portrait"
                if graph["9"]["inputs"]["height"] > graph["9"]["inputs"]["width"]
                else "landscape"
            )
            outputs = h3.oom_attempts(attempt, restart, size)
        record.update(status="complete", outputs=outputs)
        write_json(record_path, record)
        return outputs
    finally:
        if holder["tunnel"]:
            holder["tunnel"].__exit__()
