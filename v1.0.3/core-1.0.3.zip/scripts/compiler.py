import importlib.util
import uuid
from pathlib import Path
from studio_common import WORKFLOWS, StudioError, load_project, write_json, digest, now, manifest, workflow_folder
from validation import validate_project
from workflow_tools import shot_hash
from auto_reroll import effective


def adapter(workflow_id):
    manifest(workflow_id)
    path = workflow_folder(workflow_id) / "adapter.py"
    spec = importlib.util.spec_from_file_location(
        "studio_workflow_" + workflow_id.replace("-", "_"), path
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    for function in ("plan", "compile", "collect"):
        if not callable(getattr(module, function, None)):
            raise StudioError("工作流适配器缺少接口：" + function)
    return module


def compile_project(folder, shots=None, approved_only=False):
    project = load_project(folder)
    errors = validate_project(project)
    if errors:
        raise StudioError("\n".join(errors))
    # Approved shots the assistant rerolled under the page's switch compile in their new form.
    project = effective(project, folder)
    selected = set(shots or [])
    run_id = "run-" + uuid.uuid4().hex
    run_folder = Path(folder) / "runs" / run_id
    board_hash = digest(Path(folder) / "storyboard.json")
    jobs = []
    prepared = []
    found = set()
    for workflow_id in project["storyboard"]["workflows"]:
        plugin = adapter(workflow_id)
        for task in plugin.plan(project):
            shot = task["shot"]
            if selected and shot["id"] not in selected:
                continue
            found.add(shot["id"])
            if approved_only and shot["status"] != "approved":
                continue
            job_id = "job-" + uuid.uuid4().hex
            task["id"] = job_id
            compiled = plugin.compile(task)
            job = {
                "id": job_id,
                "projectId": project["studio"]["projectId"],
                "workflowId": workflow_id,
                "workflowVersion": task["workflow"]["version"],
                "shotId": shot["id"],
                "storyboardSha256": board_hash,
                "shotSha256": shot_hash(shot),
                "status": "prepared",
                "graphPath": f"runs/{run_id}/{job_id}.api.json",
                "promptPath": f"runs/{run_id}/{job_id}.prompt.txt",
                "uploads": compiled["uploads"],
            }
            jobs.append(job)
            prepared.append((job, compiled))
    if selected - found:
        raise StudioError("没有找到指定镜头：" + ", ".join(sorted(selected - found)))
    if not jobs:
        raise StudioError("没有可编译的镜头。请在页面采用草稿；开跑前还需要通过分镜。")
    # No partially compiled run is published if any earlier job failed validation.
    run_folder.mkdir(parents=True)
    for job, compiled in prepared:
        write_json(Path(folder) / job["graphPath"], compiled["graph"])
        (Path(folder) / job["promptPath"]).write_text(compiled["prompt"] + "\n", encoding="utf-8")
    run = {"schemaVersion": 1, "id": run_id, "createdAt": now(), "jobs": jobs}
    write_json(run_folder / "run.json", run)
    return run
