import re
from studio_common import StudioError, manifest, safe_relative, digest
from schema_check import document_errors

TOKEN = re.compile(r"\{\{(subject|picture|audio):([A-Za-z0-9][A-Za-z0-9_-]*)\}\}")


def binding_errors(shot, assets, workflow):
    errors = []
    bound = []
    for binding in shot["bindings"]:
        asset = assets.get(binding["assetId"])
        file = (
            next((f for f in asset["files"] if f["id"] == binding["fileId"]), None)
            if asset
            else None
        )
        if not file:
            errors.append("参考素材或文件已缺失，请重新绑定。")
            continue
        if asset["category"] not in workflow["assetCategories"]:
            errors.append("本工作流不支持该素材类别，请移除绑定。")
        bound.append((binding, asset, file))
    if len({b["assetId"] for b in shot["bindings"]}) != len(shot["bindings"]):
        errors.append("一个素材在同一镜头只能绑定一次，请移除重复项。")
    audio = [row for row in bound if row[1]["category"] == "voice"]
    images = [row for row in bound if row[1]["category"] != "voice"]
    limits = workflow["limits"]
    if len(images) > limits["images"]:
        errors.append(f"参考图最多 {limits['images']} 张，请移除多余图片。")
    if len(audio) > limits["audios"]:
        errors.append(f"参考音频最多 {limits['audios']} 段，请移除多余声音。")
    total = 0
    for _, asset, file in audio:
        duration = file.get("durationSeconds", 0)
        total += duration
        if duration < limits.get("audioMinSeconds", 0) or duration > limits.get(
            "audioMaxSeconds", float("inf")
        ):
            errors.append(
                f"@{asset['name']} 音频应为 {limits.get('audioMinSeconds')}–{limits.get('audioMaxSeconds')} 秒，请裁剪或更换。"
            )
    if total > limits.get("audioTotalSeconds", float("inf")):
        errors.append(f"音频合计不能超过 {limits['audioTotalSeconds']} 秒，请缩短音频。")
    frame = any(b["purpose"] in ("first_frame", "last_frame") for b in shot["bindings"])
    if frame and (len(bound) > 1 or "reference" in workflow["modes"]):
        errors.append("首帧和参考不能混用，请改成参考用途并使用多参考工作流。")
    if "first_frame" in workflow["modes"] and bound and not frame:
        errors.append("文生 / 首帧工作流只能绑定一张首帧，请修改用途或切到多参考。")
    if "last_frame" in [b["purpose"] for b in shot["bindings"]]:
        errors.append("v1 尚不支持尾帧，请移除尾帧或改用参考用途。")
    if shot["durationSeconds"] not in limits.get("durations", [shot["durationSeconds"]]):
        errors.append("当前执行器时长可选 5、10、15 秒，请修改镜头时长。")
    return errors


def compile_prompt(shot, assets, workflow):
    sections = workflow["promptSections"]
    prompt = shot["prompt"]
    if set(prompt) != set(sections) or any(not prompt.get(key, "").strip() for key in sections):
        raise StudioError("提示词段落不完整，请按当前工作流指南补齐。")
    body = "\n".join(prompt[key] for key in sections)
    if re.search(r"<(?:Subject|Picture|Audio)\s+\d+>", body) or "{{asset:" in body:
        raise StudioError("请使用 subject / picture / audio 令牌，不要手写编号或旧 asset 令牌。")
    tables = {"picture": {}, "audio": {}, "subject": {}}
    for binding in shot["bindings"]:
        aid = binding["assetId"]
        kind = "audio" if assets[aid]["category"] == "voice" else "picture"
        tables[kind][aid] = len(tables[kind]) + 1
    definitions = prompt.get("subject_definitions", "")
    subject_defs = list(re.finditer(r"\{\{subject:([A-Za-z0-9_-]+)\}\}", definitions))
    for index, match in enumerate(subject_defs):
        aid = match.group(1)
        end = subject_defs[index + 1].start() if index + 1 < len(subject_defs) else len(definitions)
        clause = definitions[match.end() : end].split("\n")[0]
        if aid not in tables["picture"] or "{{picture:" + aid + "}}" not in clause:
            raise StudioError("每个 Subject 必须在主体定义的同一行绑定对应 Picture：" + aid)
        if aid not in tables["subject"]:
            tables["subject"][aid] = len(tables["subject"]) + 1
    referenced = set()
    for match in TOKEN.finditer(body):
        kind, aid = match.groups()
        if aid not in tables[kind]:
            raise StudioError("正文引用了未接线、未定义或种类不符的素材：" + aid)
        if kind != "subject":
            referenced.add((kind, aid))
    for kind in ("picture", "audio"):
        for aid in tables[kind]:
            if (kind, aid) not in referenced:
                raise StudioError("素材已接线，但正文没有引用：" + aid)
            if (
                "reference" in workflow["modes"]
                and "{{" + kind + ":" + aid + "}}" not in definitions
            ):
                raise StudioError("素材已接线，但主体定义中没有说明其用途：" + aid)
    replaced = TOKEN.sub(lambda m: f"<{m[1].title()} {tables[m[1]][m[2]]}>", body)
    if "{{" in replaced or "}}" in replaced:
        raise StudioError("提示词含有未识别的素材令牌。")
    if "[Shot 1]" not in body:
        raise StudioError("画面提示词需要保留 [Shot 1]。")
    dialogue = "".join(re.findall(r"<d>\[Chinese\]\s*(.*?)</d>", body, re.S))
    if dialogue != shot["dialogue"]:
        raise StudioError("台词栏与提示词中的中文台词不一致，请让助手核对。")
    if body.count("<d>") != body.count("</d>"):
        raise StudioError("台词标签未闭合。")
    text = "\n".join(
        key + ": " + TOKEN.sub(lambda m: f"<{m[1].title()} {tables[m[1]][m[2]]}>", prompt[key])
        for key in sections
    )
    return text, tables


def validate_project(project, verify_files=True):
    errors = []
    for name in ("studio", "assets", "brief", "storyboard", "review", "results"):
        errors += document_errors(name, project[name])
    if errors:
        return errors
    assets = {a["id"]: a for a in project["assets"]["items"]}
    if len(assets) != len(project["assets"]["items"]):
        errors.append("素材 ID 重复，请为每个素材使用独立 ID。")
    if len({a["name"] for a in assets.values()}) != len(assets):
        errors.append("素材名字重复，请换一个 @ 名。")
    for brief in project["brief"]["workflows"].values():
        for aid in re.findall(r"@\[[^\]]*\]\(asset:([^)]*)\)", brief["text"]):
            if aid not in assets:
                errors.append("剧情引用的素材已缺失，请重新选择 @ 素材：" + aid)
    for asset in assets.values():
        if len({f["id"] for f in asset["files"]}) != len(asset["files"]):
            errors.append("素材文件 ID 重复。")
        for file in asset["files"]:
            try:
                path = safe_relative(project["path"], file["path"])
                if verify_files and (
                    not path.is_file()
                    or path.stat().st_size != file["size"]
                    or digest(path) != file["sha256"]
                ):
                    errors.append("原文件缺失或散列不一致：" + file["path"])
            except StudioError as error:
                errors.append(str(error))
    for workflow_id, board in project["storyboard"]["workflows"].items():
        workflow = manifest(workflow_id)
        if len({s["id"] for s in board["shots"]}) != len(board["shots"]):
            errors.append("镜头 ID 重复，请重新编号。")
        for shot in board["shots"]:
            issues = binding_errors(shot, assets, workflow)
            if not issues:
                try:
                    compile_prompt(shot, assets, workflow)
                except StudioError as error:
                    issues.append(str(error))
            errors += [shot["id"] + "：" + issue for issue in issues]
    return errors
