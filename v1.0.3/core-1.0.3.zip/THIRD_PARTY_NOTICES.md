# 第三方组件与字体许可

LeoLiu 的专有许可仅限自有内容，不覆盖以下组件；原有许可及权利保持不变。
以下依赖由本次生产构建实际包含的模块生成，不含仅开发使用的工具。

| 组件 | 版本 | 原许可 | 许可文件 |
| --- | --- | --- | --- |
| @xyflow/react | 12.12.1 | MIT | THIRD_PARTY_LICENSES/@xyflow__react/ |
| @xyflow/system | 0.0.84 | MIT | THIRD_PARTY_LICENSES/@xyflow__system/ |
| classcat | 5.0.5 | MIT | THIRD_PARTY_LICENSES/classcat/ |
| d3-color | 3.1.1 | ISC | THIRD_PARTY_LICENSES/d3-color/ |
| d3-dispatch | 3.0.2 | ISC | THIRD_PARTY_LICENSES/d3-dispatch/ |
| d3-drag | 3.0.1 | ISC | THIRD_PARTY_LICENSES/d3-drag/ |
| d3-ease | 3.0.2 | BSD-3-Clause | THIRD_PARTY_LICENSES/d3-ease/ |
| d3-interpolate | 3.0.2 | ISC | THIRD_PARTY_LICENSES/d3-interpolate/ |
| d3-selection | 3.0.1 | ISC | THIRD_PARTY_LICENSES/d3-selection/ |
| d3-timer | 3.0.2 | ISC | THIRD_PARTY_LICENSES/d3-timer/ |
| d3-transition | 3.0.2 | ISC | THIRD_PARTY_LICENSES/d3-transition/ |
| d3-zoom | 3.0.1 | ISC | THIRD_PARTY_LICENSES/d3-zoom/ |
| fflate | 0.8.3 | MIT | THIRD_PARTY_LICENSES/fflate/ |
| lucide-react | 0.575.0 | ISC | THIRD_PARTY_LICENSES/lucide-react/ |
| react | 19.2.1 | MIT | THIRD_PARTY_LICENSES/react/ |
| react-dom | 19.2.1 | MIT | THIRD_PARTY_LICENSES/react-dom/ |
| scheduler | 0.27.0 | MIT | THIRD_PARTY_LICENSES/scheduler/ |
| use-sync-external-store | 1.7.0 | MIT | THIRD_PARTY_LICENSES/use-sync-external-store/ |
| zustand | 4.5.7 | MIT | THIRD_PARTY_LICENSES/zustand/ |
| Inter | 内嵌字库 | OFL-1.1 | THIRD_PARTY_LICENSES/fonts/Inter-OFL.txt |
| JetBrains Mono | 内嵌字库 | OFL-1.1 | THIRD_PARTY_LICENSES/fonts/JetBrainsMono-OFL.txt |
| Noto Sans SC | 内嵌子集 | OFL-1.1 | THIRD_PARTY_LICENSES/fonts/NotoSansSC-OFL.txt |
| ComfyUI | 72865f4f27eaf5396f8f36370e0a2be3a9a090ee | GPL-3.0 | THIRD_PARTY_LICENSES/ComfyUI-LICENSE.txt |

ComfyUI 为独立执行的第三方引擎，原始源码与原许可完整保存在
`engine/assets/runtime/comfyui-source.tar.gz`；其目录和源码不属于工作台页面源码。
GPL 组件允许的修改、再分发等权利不受 LeoLiu 专有许可限制。
后续在云端下载的模型、Python wheels、节点并未作为二进制依赖打入本包；
其版本与来源见 engine/assets/ 中清单，安装与使用时仍须遵循各自原许可。
